# COSTAS32 CYCLE 0001 재현 자료

이 묶음은 2026-08-01 Work 실행에서 이미 생성된 연구 산출물을 보존·내보내기 위해 만들었다. 이 ZIP 생성 과정에서는 차수 32 연구 계산을 추가로 수행하지 않았다. 기존 역할 7·8 SHA-256 목록만 프로젝트 루트 기준으로 다시 검사했으며 모두 통과했다.

## 범위와 디렉터리

- `reports/COSTAS32_WORK_REPORT_2026-08-01.md`: 최종 연구 보고서.
- `work/role7/`: 역할 7의 전체 산출물. 독립 C++ 구현, JSON 결과, 보고서, 검증기 결과와 `MANIFEST.sha256`을 포함한다.
- `work/role8/`: 역할 8의 전체 산출물. 감사 코드·결과·보고서·재현 래퍼·로그와 `SHA256SUMS.txt`를 포함한다.
- `work/wave2_gf32_two/`, `work/wave2_w1p31_two/`, `work/wave2_w1p37_delete4/`: 세 제한 영역 완전 탐색의 주 C++ 구현과 저장 결과.
- `work/role3/`, `work/role7/crosscheck_counterexamples.py`, `work/role7/counterexample_crosschecks.json`, `work/role8/adversarial_audit.py`, `work/role8/adversarial_audit_results.json`: 삭제 유전성 및 전치 수리 반례의 생성·교차검사·감사 자료.
- `upload/`: 이번 실행에 제공된 기준 문맥과 검증기. 업로드 과정에서 붙은 `(1)`이 실제 파일명에 포함되어 있다.
- `ARTIFACT_FILE_LIST.txt`: ZIP 내부 파일 목록.
- `ARTIFACT_SHA256SUMS.txt`: 이 파일 자신을 제외한 ZIP 내부 모든 파일의 SHA-256.
- `MISSING_OR_INACCESSIBLE_FILES.txt`: 요구 자료의 누락·접근 불가 감사 결과.

모든 명령은 ZIP을 푼 최상위 `COSTAS32_CYCLE_0001_ARTIFACTS/`에서 실행한다.

## 빠른 무결성 검사

```bash
sha256sum -c ARTIFACT_SHA256SUMS.txt
sha256sum -c work/role7/MANIFEST.sha256
sha256sum -c work/role8/SHA256SUMS.txt
```

첫 명령은 `ARTIFACT_SHA256SUMS.txt` 자체만 제외하고 ZIP에 보존된 모든 파일을 검사한다. 역할 7·8 목록의 경로도 이 최상위 디렉터리를 기준으로 한다.

## 검증기 자체 시험

```bash
python3 'upload/reference_verifier(1).py' --self-test
python3 'upload/independent_verifier(1).py' --self-test
```

`test_verifiers(1).py`는 기준 모듈 이름을 import하므로 필요하면 임시 디렉터리에 심볼릭 링크를 만든 뒤 실행한다.

```bash
tmp_verifiers=$(mktemp -d)
ln -s "$PWD/upload/reference_verifier(1).py" "$tmp_verifiers/reference_verifier.py"
ln -s "$PWD/upload/independent_verifier(1).py" "$tmp_verifiers/independent_verifier.py"
PYTHONPATH="$tmp_verifiers" python3 'upload/test_verifiers(1).py' \
  --cases 'upload/test_cases(1).json'
```

## 세 완전 탐색의 통합 재현

다음 래퍼는 세 주 구현과 역할 7 독립 구현, 모두 네 C++ 소스를 새로 컴파일하고 저장 JSON과 의미 비교한다. 전체 제한 영역을 다시 소진하므로 환경에 따라 시간이 걸릴 수 있다.

```bash
python3 work/role8/reproduce_wave2.py
```

저장된 실제 실행 결과는 `work/role8/wave2_reproduction.json` 및 `.log`에 있다.

## C++ 수동 컴파일·실행

```bash
c++ -std=c++20 -O3 -DNDEBUG work/wave2_gf32_two/search.cpp \
  -o /tmp/costas32_gf32_two
/tmp/costas32_gf32_two /tmp/costas32_gf32_two.json

c++ -std=c++20 -O3 -DNDEBUG work/wave2_w1p31_two/search.cpp \
  -o /tmp/costas32_w1p31_two
/tmp/costas32_w1p31_two /tmp/costas32_w1p31_two.json

c++ -std=c++20 -O3 -DNDEBUG work/wave2_w1p37_delete4/search.cpp \
  -o /tmp/costas32_w1p37_delete4
/tmp/costas32_w1p37_delete4 /tmp/costas32_w1p37_delete4.json

c++ -std=c++20 -O3 -DNDEBUG -pthread \
  work/role7/independent_wave2_search.cpp \
  -o /tmp/costas32_independent_wave2
mkdir -p /tmp/costas32_independent_wave2_results
/tmp/costas32_independent_wave2 \
  --output-dir /tmp/costas32_independent_wave2_results --threads 4
```

역할 7의 초기 독립 정확 탐색은 다음과 같이 재현한다.

```bash
c++ -std=c++20 -O3 -DNDEBUG \
  work/role7/independent_exact_search.cpp \
  -o /tmp/costas32_independent_exact
/tmp/costas32_independent_exact \
  --output /tmp/costas32_independent_results.json
```

## 반례 및 적대적 감사

```bash
python3 work/role7/crosscheck_counterexamples.py
python3 work/role8/adversarial_audit.py
```

역할 3의 원 생성·교차검사 소스와 당시 결과·로그는 `work/role3/` 전체에 보존되어 있다. 위 두 명령은 확정 보고에 사용된 교차검사와 제3 구현 감사를 재실행한다.

## 환경 기록

- 저장된 실행: Python 3.12.13, g++/c++ 13.3.0, Linux x86_64.
- C++ 표준: C++20.
- 순열 위치와 값: 1-based.
- 세 완전 탐색은 제한된 매개변수 영역의 소진이며 전체 차수 32 순열 공간의 소진이 아니다.

