#!/usr/bin/env python3
"""Exact small-order audit for Costas-32 role 6.

The program performs no symmetry quotienting.  It fills columns from left to
right, tries every unused row, and rejects a new point exactly when one of its
new displacement vectors duplicates an old vector of the same horizontal
distance.  Thus every full Costas permutation is reached once and only once.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections.abc import Iterator, Sequence
from typing import Any


PUBLISHED_COUNTS = {
    1: 1,
    2: 2,
    3: 4,
    4: 12,
    5: 40,
    6: 116,
    7: 200,
    8: 444,
    9: 760,
    10: 2160,
    11: 4368,
    12: 7852,
}


def compact_hash(permutation: Sequence[int]) -> str:
    payload = json.dumps(list(permutation), separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def is_costas_pairwise(permutation: Sequence[int]) -> bool:
    n = len(permutation)
    seen: set[tuple[int, int]] = set()
    for left in range(n):
        for right in range(left + 1, n):
            vector = (right - left, permutation[right] - permutation[left])
            if vector in seen:
                return False
            seen.add(vector)
    return True


def generate_costas(order: int) -> Iterator[tuple[int, ...]]:
    prefix: list[int] = []
    differences_by_distance = [set() for _ in range(order)]

    def visit(used_rows: int) -> Iterator[tuple[int, ...]]:
        if len(prefix) == order:
            yield tuple(prefix)
            return

        for row in range(1, order + 1):
            row_bit = 1 << (row - 1)
            if used_rows & row_bit:
                continue

            new_differences: list[tuple[int, int]] = []
            for distance, old_row in enumerate(reversed(prefix), start=1):
                difference = row - old_row
                if difference in differences_by_distance[distance]:
                    break
                new_differences.append((distance, difference))
            else:
                prefix.append(row)
                for distance, difference in new_differences:
                    differences_by_distance[distance].add(difference)
                yield from visit(used_rows | row_bit)
                for distance, difference in new_differences:
                    differences_by_distance[distance].remove(difference)
                prefix.pop()

    yield from visit(0)


def inverse(permutation: Sequence[int]) -> tuple[int, ...]:
    result = [0] * len(permutation)
    for index, value in enumerate(permutation, start=1):
        result[value - 1] = index
    return tuple(result)


def dihedral_images(permutation: Sequence[int]) -> set[tuple[int, ...]]:
    n = len(permutation)
    p = tuple(permutation)
    four = {
        p,
        tuple(n + 1 - value for value in p),
        tuple(reversed(p)),
        tuple(n + 1 - value for value in reversed(p)),
    }
    return four | {inverse(image) for image in four}


def has_corner(permutation: Sequence[int]) -> bool:
    n = len(permutation)
    return permutation[0] in (1, n) or permutation[-1] in (1, n)


def has_empty_half_corner(permutation: Sequence[int]) -> bool:
    n = len(permutation)
    if n % 2:
        return False
    half = n // 2
    first_half_rows = set(permutation[:half])
    low = set(range(1, half + 1))
    high = set(range(half + 1, n + 1))
    return first_half_rows == low or first_half_rows == high


def lower_left_extension(core: Sequence[int]) -> tuple[int, ...]:
    return (1, *(value + 1 for value in core))


def extension_obstructions(core: Sequence[int]) -> list[dict[str, int]]:
    """Return every collision between the new corner and an old pair.

    For core sigma of order m, the new corner vector at distance d is
    (d, sigma[d]).  It collides exactly when sigma[j+d]-sigma[j]=sigma[d]
    for some zero-based j.  Output indices are converted to 1-based.
    """
    result: list[dict[str, int]] = []
    m = len(core)
    for distance in range(1, m + 1):
        new_vertical = core[distance - 1]
        for start in range(0, m - distance):
            if core[start + distance] - core[start] == new_vertical:
                result.append(
                    {
                        "distance": distance,
                        "new_vertical": new_vertical,
                        "core_pair_start": start + 1,
                    }
                )
    return result


def audit(max_order: int) -> dict[str, Any]:
    arrays_by_order: dict[int, list[tuple[int, ...]]] = {}
    rows: list[dict[str, Any]] = []
    first_corner_free: tuple[int, ...] | None = None
    first_corner_free_order: int | None = None
    near_threshold_half_block: tuple[int, ...] | None = None

    for order in range(1, max_order + 1):
        arrays = list(generate_costas(order))
        arrays_by_order[order] = arrays
        if order in PUBLISHED_COUNTS:
            assert len(arrays) == PUBLISHED_COUNTS[order]
        assert all(is_costas_pairwise(p) for p in arrays)

        corner_free = [p for p in arrays if not has_corner(p)]
        empty_half = [p for p in arrays if has_empty_half_corner(p)]
        lower_left = [p for p in arrays if p[0] == 1]

        if first_corner_free is None and corner_free:
            first_corner_free = corner_free[0]
            first_corner_free_order = order
        if order == 6 and empty_half:
            near_threshold_half_block = empty_half[0]

        # Both properties used for n=32 pruning are invariant under D4.
        for p in arrays:
            images = dihedral_images(p)
            assert all(is_costas_pairwise(image) for image in images)
            assert {has_corner(image) for image in images} == {has_corner(p)}
            if order % 2 == 0:
                assert {
                    has_empty_half_corner(image) for image in images
                } == {has_empty_half_corner(p)}

        extension_count = None
        if order >= 2:
            cores = arrays_by_order[order - 1]
            criterion_results = [not extension_obstructions(core) for core in cores]
            direct_results = [
                is_costas_pairwise(lower_left_extension(core)) for core in cores
            ]
            assert criterion_results == direct_results
            extension_count = sum(criterion_results)
            assert extension_count == len(lower_left)

        rows.append(
            {
                "order": order,
                "costas_count": len(arrays),
                "published_count_match": order in PUBLISHED_COUNTS,
                "corner_free_count": len(corner_free),
                "lower_left_corner_count": len(lower_left),
                "lower_left_extension_count_from_previous_order": extension_count,
                "empty_half_corner_count": len(empty_half) if order % 2 == 0 else None,
            }
        )

    assert first_corner_free is not None
    assert first_corner_free_order is not None
    assert near_threshold_half_block is not None

    return {
        "marker": "COSTAS_ROLE6_EXACT_AUDIT_V1",
        "method": "complete left-to-right backtracking without symmetry reduction",
        "max_order": max_order,
        "orders": rows,
        "minimum_corner_free_counterexample": {
            "order": first_corner_free_order,
            "permutation": list(first_corner_free),
            "sha256": compact_hash(first_corner_free),
        },
        "near_threshold_empty_half_counterexample": {
            "statement_refuted": "every even-order Costas permutation has all four half-size corner quadrants nonempty",
            "order": 6,
            "permutation": list(near_threshold_half_block),
            "sha256": compact_hash(near_threshold_half_block),
        },
        "symmetry_checks": "D4 preservation checked for every enumerated array",
        "extension_criterion_checks": "criterion and direct pairwise test agreed for every enumerated core",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-order", type=int, default=12)
    args = parser.parse_args()
    print(json.dumps(audit(args.max_order), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
