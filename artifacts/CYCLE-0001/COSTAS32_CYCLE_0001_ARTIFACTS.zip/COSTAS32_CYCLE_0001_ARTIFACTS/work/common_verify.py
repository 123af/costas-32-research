#!/usr/bin/env python3
"""Shared dual-verification and D4-normalization helper for this Work run."""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
from typing import Any, Callable

ROOT = Path(__file__).resolve().parents[1]
UPLOAD = ROOT / "upload"


def _load_verify(filename: str, module_name: str) -> Callable[[Any], dict[str, Any]]:
    path = UPLOAD / filename
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load verifier: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify_permutation


VERIFY_REFERENCE = _load_verify("reference_verifier(1).py", "costas_reference_v1")
VERIFY_INDEPENDENT = _load_verify("independent_verifier(1).py", "costas_independent_v1")


def _collision_key(report: dict[str, Any]) -> tuple[Any, ...]:
    rows = []
    for item in report["duplicate_vectors"]:
        pairs = tuple(
            sorted(tuple(tuple(point) for point in pair) for pair in item["point_pairs"])
        )
        rows.append((tuple(item["vector"]), item["multiplicity"], pairs))
    return tuple(sorted(rows))


def inverse(permutation: list[int]) -> list[int]:
    result = [0] * len(permutation)
    for column, value in enumerate(permutation, start=1):
        result[value - 1] = column
    return result


def d4_images(permutation: list[int]) -> list[list[int]]:
    n = len(permutation)
    complement = [n + 1 - value for value in permutation]
    reversed_columns = list(reversed(permutation))
    rotated = [n + 1 - value for value in reversed_columns]
    base = [permutation, complement, reversed_columns, rotated]
    return base + [inverse(item) for item in base]


def canonical(permutation: list[int]) -> list[int]:
    return list(min(tuple(item) for item in d4_images(permutation)))


def dual_verify(permutation: Any) -> dict[str, Any]:
    reference = VERIFY_REFERENCE(permutation)
    independent = VERIFY_INDEPENDENT(permutation)
    comparable = (
        "order",
        "valid_input",
        "is_permutation",
        "is_costas",
        "error_code",
        "duplicate_vector_count",
        "duplicate_pair_occurrence_excess",
        "permutation_sha256",
    )
    field_agreement = all(reference.get(key) == independent.get(key) for key in comparable)
    collision_agreement = _collision_key(reference) == _collision_key(independent)
    valid_permutation = reference["valid_input"] and reference["is_permutation"]
    return {
        "agreement": field_agreement and collision_agreement,
        "field_agreement": field_agreement,
        "collision_agreement": collision_agreement,
        "valid_costas_witness": bool(
            field_agreement
            and collision_agreement
            and valid_permutation
            and reference["is_costas"]
        ),
        "canonical": canonical(permutation) if valid_permutation else None,
        "reference": reference,
        "independent": independent,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--permutation", help="JSON array")
    group.add_argument("--input", type=Path, help="JSON array or object with permutation")
    args = parser.parse_args()
    if args.permutation is not None:
        candidate = json.loads(args.permutation)
    else:
        candidate = json.loads(args.input.read_text(encoding="utf-8"))
        if isinstance(candidate, dict) and "permutation" in candidate:
            candidate = candidate["permutation"]
    print(json.dumps(dual_verify(candidate), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
