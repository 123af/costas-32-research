#!/usr/bin/env python3
"""Compile the submitted C++ sources afresh and reproduce all wave-2 scans."""

from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import tempfile
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
OUT_JSON = Path(__file__).with_name("wave2_reproduction.json")
OUT_LOG = Path(__file__).with_name("wave2_reproduction.log")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=ROOT, check=True, text=True, capture_output=True)


def normalized(document: Any) -> Any:
    if isinstance(document, dict):
        return {
            key: normalized(value)
            for key, value in document.items()
            if key not in {"elapsed_seconds", "seconds", "threads"}
        }
    if isinstance(document, list):
        return [normalized(value) for value in document]
    return document


def main() -> int:
    compiler = "c++"
    sources = {
        "gf32": ROOT / "work/wave2_gf32_two/search.cpp",
        "w1p31": ROOT / "work/wave2_w1p31_two/search.cpp",
        "w1p37": ROOT / "work/wave2_w1p37_delete4/search.cpp",
        "role7": ROOT / "work/role7/independent_wave2_search.cpp",
    }
    stored = {
        "gf32": ROOT / "work/wave2_gf32_two/repair_result.json",
        "w1p31": ROOT / "work/wave2_w1p31_two/repair_result.json",
        "w1p37": ROOT / "work/wave2_w1p37_delete4/result.json",
    }
    logs: list[str] = []
    report: dict[str, Any] = {
        "marker": "COSTAS_ROLE8_WAVE2_REPRODUCTION_V1",
        "platform": platform.platform(),
        "compiler": run([compiler, "--version"]).stdout.splitlines()[0],
        "source_sha256": {name: sha256(path) for name, path in sources.items()},
        "runs": {},
    }
    with tempfile.TemporaryDirectory(prefix="costas_role8_") as temporary:
        temp = Path(temporary)
        executables: dict[str, Path] = {}
        for name, source in sources.items():
            executable = temp / name
            command = [compiler, "-std=c++20", "-O3", "-DNDEBUG"]
            if name == "role7":
                command.append("-pthread")
            command.extend([str(source), "-o", str(executable)])
            completed = run(command)
            logs.append("COMMAND " + " ".join(command))
            logs.append(completed.stdout)
            logs.append(completed.stderr)
            executables[name] = executable

        for name in ("gf32", "w1p31", "w1p37"):
            output = temp / f"{name}.json"
            command = [str(executables[name]), str(output)]
            completed = run(command)
            logs.append("COMMAND " + " ".join(command))
            logs.append(completed.stdout)
            logs.append(completed.stderr)
            observed = json.loads(output.read_text(encoding="utf-8"))
            expected = json.loads(stored[name].read_text(encoding="utf-8"))
            report["runs"][name] = {
                "command": command,
                "executable_sha256": sha256(executables[name]),
                "output_sha256": sha256(output),
                "semantic_match_ignoring_elapsed_time": normalized(observed) == normalized(expected),
                "result": observed,
            }

        role7_out = temp / "role7_results"
        role7_out.mkdir()
        command = [str(executables["role7"]), "--output-dir", str(role7_out), "--threads", "4"]
        completed = run(command)
        logs.append("COMMAND " + " ".join(command))
        logs.append(completed.stdout)
        logs.append(completed.stderr)
        comparisons = {}
        for observed_path in sorted(role7_out.glob("*.json")):
            expected_path = ROOT / "work/role7" / observed_path.name
            observed = json.loads(observed_path.read_text(encoding="utf-8"))
            expected = json.loads(expected_path.read_text(encoding="utf-8"))
            comparisons[observed_path.name] = {
                "semantic_match_ignoring_time_and_threads": normalized(observed) == normalized(expected),
                "observed_sha256": sha256(observed_path),
                "stored_sha256": sha256(expected_path),
            }
        report["runs"]["role7"] = {
            "command": command,
            "executable_sha256": sha256(executables["role7"]),
            "stdout": completed.stdout.strip().splitlines(),
            "artifact_comparisons": comparisons,
        }

    report["all_semantic_comparisons_pass"] = all(
        entry["semantic_match_ignoring_elapsed_time"]
        for name, entry in report["runs"].items()
        if name != "role7"
    ) and all(
        entry["semantic_match_ignoring_time_and_threads"]
        for entry in report["runs"]["role7"]["artifact_comparisons"].values()
    )
    OUT_JSON.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    OUT_LOG.write_text("\n".join(logs), encoding="utf-8")
    print(json.dumps({"status": "PASS" if report["all_semantic_comparisons_pass"] else "FAIL", "output": str(OUT_JSON)}, indent=2))
    return 0 if report["all_semantic_comparisons_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
