#!/usr/bin/env python3
"""Independent, adversarial audit for the Costas-32 wave-2 and small claims.

This program intentionally does not import any submitted search implementation.
Its core predicate stores signed displacement vectors produced by unordered
point pairs.  It also constructs GF(32) through a third irreducible polynomial,
x^5+x^2+1, and compares the resulting abstract G2 family with role 7's base
artifact.
"""

from __future__ import annotations

import hashlib
import importlib.util
import itertools
import json
import math
import random
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Callable


ROOT = Path(__file__).resolve().parents[2]
ROLE7 = ROOT / "work" / "role7"
OUTPUT = Path(__file__).with_name("adversarial_audit_results.json")
REFERENCE = ROOT / "upload" / "reference_verifier(1).py"
INDEPENDENT = ROOT / "upload" / "independent_verifier(1).py"
SEED = 0xC057A532


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_verifier(path: Path, name: str) -> Callable[[Any], dict[str, Any]]:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify_permutation


verify_reference = load_verifier(REFERENCE, "role8_reference")
verify_independent = load_verifier(INDEPENDENT, "role8_independent")


def vector_occurrences(p: tuple[int, ...]) -> dict[tuple[int, int], list[tuple[int, int]]]:
    result: dict[tuple[int, int], list[tuple[int, int]]] = {}
    for left, right in itertools.combinations(range(len(p)), 2):
        vector = (right - left, p[right] - p[left])
        result.setdefault(vector, []).append((left, right))
    return result


def is_permutation(p: tuple[int, ...]) -> bool:
    return sorted(p) == list(range(1, len(p) + 1))


def is_costas(p: tuple[int, ...]) -> bool:
    occurrences = vector_occurrences(p)
    return is_permutation(p) and all(len(pairs) == 1 for pairs in occurrences.values())


def duplicate_signature(p: tuple[int, ...]) -> dict[tuple[int, int], int]:
    return {
        vector: len(pairs)
        for vector, pairs in vector_occurrences(p).items()
        if len(pairs) > 1
    }


def exactly_one_collision(p: tuple[int, ...]) -> tuple[int, int] | None:
    duplicates = duplicate_signature(p)
    if len(duplicates) != 1:
        return None
    vector, multiplicity = next(iter(duplicates.items()))
    return vector if multiplicity == 2 else None


def delete_point(p: tuple[int, ...], column: int) -> tuple[int, ...]:
    removed = p[column]
    return tuple(value - int(value > removed) for i, value in enumerate(p) if i != column)


def primitive_roots(prime: int) -> list[int]:
    return [
        g
        for g in range(2, prime)
        if len({pow(g, exponent, prime) for exponent in range(prime - 1)}) == prime - 1
    ]


def w1_bases(prime: int) -> list[tuple[int, ...]]:
    return sorted(
        {
            tuple(pow(g, i + shift, prime) for i in range(prime - 1))
            for g in primitive_roots(prime)
            for shift in range(prime - 1)
        }
    )


# Third representation: x^5+x^2+1, bits 100101.  It differs from both wave-2
# implementations (x^5+x^3+1 and x^5+x^4+x^2+x+1).
GF32_MODULUS = 0b100101


def gf32_multiply(a: int, b: int) -> int:
    product = 0
    for bit in range(5):
        if (b >> bit) & 1:
            product ^= a << bit
    for degree in range(8, 4, -1):
        if (product >> degree) & 1:
            product ^= GF32_MODULUS << (degree - 5)
    return product & 31


def validate_gf32() -> bool:
    # A finite commutative ring with an inverse for every nonzero element is a
    # field.  The multiplication table checks closure and every inverse here;
    # polynomial arithmetic supplies associativity/distributivity.
    for a in range(1, 32):
        if sum(gf32_multiply(a, b) == 1 for b in range(1, 32)) != 1:
            return False
        if any(gf32_multiply(a, b) == 0 for b in range(1, 32)):
            return False
    return True


def gf32_primitive_elements() -> list[int]:
    result = []
    for value in range(2, 32):
        current = 1
        powers = set()
        for _ in range(31):
            current = gf32_multiply(current, value)
            powers.add(current)
        if current == 1 and len(powers) == 31:
            result.append(value)
    return result


def gf32_g2(alpha: int, beta: int) -> tuple[int, ...]:
    logarithm = [0] * 32
    current = 1
    for exponent in range(1, 31):
        current = gf32_multiply(current, alpha)
        logarithm[current] = exponent
    current = 1
    result = []
    for _ in range(1, 31):
        current = gf32_multiply(current, beta)
        target = current ^ 1
        if target == 0 or logarithm[target] == 0:
            raise AssertionError("invalid G2 logarithm")
        result.append(logarithm[target])
    return tuple(result)


def gf32_family() -> tuple[list[tuple[int, ...]], Counter[int], list[int]]:
    generators = gf32_primitive_elements()
    counts: Counter[tuple[int, ...]] = Counter(
        gf32_g2(alpha, beta) for alpha in generators for beta in generators
    )
    return sorted(counts), Counter(counts.values()), generators


def insertion_candidate(
    base: tuple[int, ...], columns: tuple[int, int], rows: tuple[int, int], matching: int
) -> tuple[int, ...]:
    n = len(base)
    size = n + 2
    old_columns = [x for x in range(1, size + 1) if x not in columns]
    old_rows = [y for y in range(1, size + 1) if y not in rows]
    candidate = [0] * size
    for old_column, old_value in enumerate(base):
        candidate[old_columns[old_column] - 1] = old_rows[old_value - 1]
    candidate[columns[0] - 1] = rows[matching]
    candidate[columns[1] - 1] = rows[1 - matching]
    return tuple(candidate)


def recover_two_point_insertion(
    candidate: tuple[int, ...], columns: tuple[int, int], rows: tuple[int, int]
) -> tuple[int, ...]:
    return tuple(
        value - int(value > rows[0]) - int(value > rows[1])
        for column, value in enumerate(candidate, start=1)
        if column not in columns
    )


def delete4_candidate(base: tuple[int, ...], deleted_columns: tuple[int, ...]) -> tuple[int, ...]:
    deleted_values = {base[column] for column in deleted_columns}
    return tuple(
        value - sum(removed < value for removed in deleted_values)
        for column, value in enumerate(base)
        if column not in deleted_columns
    )


def read_bases(filename: str) -> list[tuple[int, ...]]:
    document = json.loads((ROLE7 / filename).read_text(encoding="utf-8"))
    return [tuple(p) for p in document["bases_lexicographic"]]


def audit_base_families() -> dict[str, Any]:
    gf32, gf_multiplicity, gf_generators = gf32_family()
    role7_gf = read_bases("R7-W2-GF32-TWO-001_bases.json")
    w31 = w1_bases(31)
    role7_w31 = read_bases("R7-W2-W1P31-TWO-002_bases.json")
    w37 = w1_bases(37)
    role7_w37 = read_bases("R7-W2-W1P37-DEL4-003_bases.json")
    return {
        "third_gf_polynomial": "x^5+x^2+1",
        "third_gf_model_valid": validate_gf32(),
        "gf_primitive_elements": gf_generators,
        "gf_raw_parameter_count": len(gf_generators) ** 2,
        "gf_unique_bases": len(gf32),
        "gf_multiplicity_histogram": dict(sorted(gf_multiplicity.items())),
        "gf_set_equals_role7_artifact": gf32 == role7_gf,
        "gf_all_bases_are_costas": all(is_costas(p) for p in gf32),
        "w1p31_primitive_roots": primitive_roots(31),
        "w1p31_unique_bases": len(w31),
        "w1p31_set_equals_role7_artifact": w31 == role7_w31,
        "w1p31_all_bases_are_costas": all(is_costas(p) for p in w31),
        "w1p37_primitive_roots": primitive_roots(37),
        "w1p37_unique_bases": len(w37),
        "w1p37_set_equals_role7_artifact": w37 == role7_w37,
        "w1p37_all_bases_are_costas": all(is_costas(p) for p in w37),
    }


def audit_result_arithmetic() -> dict[str, Any]:
    expected_insertion_per_base = math.comb(32, 2) ** 2 * 2
    expected_delete4_per_base = math.comb(36, 4)
    paths = {
        "gf_primary": ROOT / "work/wave2_gf32_two/repair_result.json",
        "gf_role7": ROLE7 / "R7-W2-GF32-TWO-001_result.json",
        "w31_primary": ROOT / "work/wave2_w1p31_two/repair_result.json",
        "w31_role7": ROLE7 / "R7-W2-W1P31-TWO-002_result.json",
        "w37_primary": ROOT / "work/wave2_w1p37_delete4/result.json",
        "w37_role7": ROLE7 / "R7-W2-W1P37-DEL4-003_result.json",
    }
    documents = {name: json.loads(path.read_text(encoding="utf-8")) for name, path in paths.items()}
    checks = {
        "insertion_cases_per_base": expected_insertion_per_base,
        "delete4_cases_per_base": expected_delete4_per_base,
        "gf_expected_total": 180 * expected_insertion_per_base,
        "w31_expected_total": 240 * expected_insertion_per_base,
        "w37_expected_total": 432 * expected_delete4_per_base,
        "gf_primary_total_matches": documents["gf_primary"]["checked_cases"] == 180 * expected_insertion_per_base,
        "gf_role7_total_matches": documents["gf_role7"]["candidates_checked"] == 180 * expected_insertion_per_base,
        "w31_primary_total_matches": documents["w31_primary"]["checked_cases"] == 240 * expected_insertion_per_base,
        "w31_role7_total_matches": documents["w31_role7"]["candidates_checked"] == 240 * expected_insertion_per_base,
        "w37_primary_total_matches": documents["w37_primary"]["checked_cases"] == 432 * expected_delete4_per_base,
        "w37_role7_total_matches": documents["w37_role7"]["candidates_checked"] == 432 * expected_delete4_per_base,
        "all_report_zero_hits": all(
            document.get("witness_count", document.get("passing_candidates")) == 0
            for document in documents.values()
        ),
        "primary_insertion_one_collision_counts": {
            "gf32": documents["gf_primary"].get("one_collision_parameter_cases"),
            "w1p31": documents["w31_primary"].get("one_collision_parameter_cases"),
        },
        "role7_did_not_compute_one_collision_counts": all(
            "one_collision_parameter_cases" not in documents[name]
            for name in ("gf_role7", "w31_role7")
        ),
    }
    return checks


def audit_parameterization_regression() -> dict[str, Any]:
    # Tiny domain: every pair of designated columns/rows and both matchings must
    # recover the base after deletion and rank compression.
    bases = ((1, 3, 2), (2, 3, 1))
    cases = failures = nonpermutations = 0
    subsets = list(itertools.combinations(range(1, 6), 2))
    unique_candidates: set[tuple[int, ...]] = set()
    for base in bases:
        for columns in subsets:
            for rows in subsets:
                for matching in range(2):
                    cases += 1
                    candidate = insertion_candidate(base, columns, rows, matching)
                    unique_candidates.add(candidate)
                    nonpermutations += not is_permutation(candidate)
                    failures += recover_two_point_insertion(candidate, columns, rows) != base
    return {
        "source_order": 3,
        "target_order": 5,
        "base_count": len(bases),
        "expected_parameter_cases": len(bases) * math.comb(5, 2) ** 2 * 2,
        "parameter_cases": cases,
        "unique_candidates": len(unique_candidates),
        "permutation_failures": nonpermutations,
        "recovery_failures": failures,
    }


def audit_random_domain_samples(samples_per_domain: int = 4096) -> dict[str, Any]:
    rng = random.Random(SEED)
    gf_bases = read_bases("R7-W2-GF32-TWO-001_bases.json")
    w31_bases = read_bases("R7-W2-W1P31-TWO-002_bases.json")
    w37_bases = read_bases("R7-W2-W1P37-DEL4-003_bases.json")
    pairs32 = list(itertools.combinations(range(1, 33), 2))
    subsets36 = list(itertools.combinations(range(36), 4))
    digest = hashlib.sha256()
    report: dict[str, Any] = {"seed": SEED, "samples_per_domain": samples_per_domain}

    def check_candidate(candidate: tuple[int, ...]) -> tuple[bool, bool]:
        third = is_costas(candidate)
        reference = verify_reference(list(candidate))["is_costas"]
        independent = verify_independent(list(candidate))["is_costas"]
        if not (third == reference == independent):
            raise AssertionError("three-way verifier disagreement")
        digest.update(bytes(candidate))
        digest.update(b"1" if third else b"0")
        return third, exactly_one_collision(candidate) is not None

    for label, bases in (("gf32_two", gf_bases), ("w1p31_two", w31_bases)):
        hits = one_collision = recovery_failures = 0
        for _ in range(samples_per_domain):
            base = rng.choice(bases)
            columns = rng.choice(pairs32)
            rows = rng.choice(pairs32)
            matching = rng.randrange(2)
            candidate = insertion_candidate(base, columns, rows, matching)
            hit, one = check_candidate(candidate)
            hits += hit
            one_collision += one
            recovery_failures += recover_two_point_insertion(candidate, columns, rows) != base
        report[label] = {
            "costas_hits": hits,
            "exactly_one_collision_hits": one_collision,
            "recovery_failures": recovery_failures,
        }

    hits = permutation_failures = 0
    for _ in range(samples_per_domain):
        base = rng.choice(w37_bases)
        deleted = rng.choice(subsets36)
        candidate = delete4_candidate(base, deleted)
        hit, _ = check_candidate(candidate)
        hits += hit
        permutation_failures += not is_permutation(candidate)
    report["w1p37_delete4"] = {
        "costas_hits": hits,
        "permutation_failures": permutation_failures,
    }
    report["candidate_and_result_sha256"] = digest.hexdigest()
    return report


def audit_synthetic_verifier_regression() -> dict[str, Any]:
    cases = {
        "positive_signed_collision": ((1, 2, 3), False),
        "negative_signed_collision": ((3, 2, 1), False),
        "same_dy_different_dx_allowed": ((1, 2, 4, 3), True),
        "one_collision_counterexample": ((1, 3, 4, 5, 2, 6), False),
    }
    rows = {}
    for label, (candidate, expected) in cases.items():
        third = is_costas(candidate)
        reference = verify_reference(list(candidate))["is_costas"]
        independent = verify_independent(list(candidate))["is_costas"]
        rows[label] = {
            "expected": expected,
            "third": third,
            "reference": reference,
            "independent": independent,
            "pass": third == reference == independent == expected,
        }
    return rows


def audit_r2() -> dict[str, Any]:
    witness = (2, 1, 5, 7, 3, 6, 4)
    rows = []
    first_counterexample = None
    for n in range(2, 8):
        costas_count = no_deletable = 0
        for p in itertools.permutations(range(1, n + 1)):
            if not is_costas(p):
                continue
            costas_count += 1
            if not any(is_costas(delete_point(p, column)) for column in range(n)):
                no_deletable += 1
                if first_counterexample is None:
                    first_counterexample = p
        rows.append({"n": n, "costas_count": costas_count, "no_deletable_count": no_deletable})
    deletions = []
    for column in range(len(witness)):
        reduced = delete_point(witness, column)
        deletions.append(
            {
                "deleted_point_1_based": [column + 1, witness[column]],
                "reduced": list(reduced),
                "duplicate_vectors": {f"{dx},{dy}": count for (dx, dy), count in sorted(duplicate_signature(reduced).items())},
            }
        )
    return {
        "witness_is_costas": is_costas(witness),
        "all_witness_deletions_fail": all(not is_costas(delete_point(witness, k)) for k in range(7)),
        "first_lexicographic_counterexample": list(first_counterexample or ()),
        "orders": rows,
        "deletions": deletions,
    }


def r3_partition_criterion(p: tuple[int, ...], a: int, b: int) -> bool:
    swapped = list(p)
    swapped[a], swapped[b] = swapped[b], swapped[a]
    changed = {a, b}
    unaffected_vectors = []
    affected_vectors = []
    for left, right in itertools.combinations(range(len(p)), 2):
        if left in changed or right in changed:
            affected_vectors.append((right - left, swapped[right] - swapped[left]))
        else:
            unaffected_vectors.append((right - left, p[right] - p[left]))
    return (
        len(unaffected_vectors) == len(set(unaffected_vectors))
        and len(affected_vectors) == len(set(affected_vectors))
        and set(unaffected_vectors).isdisjoint(affected_vectors)
    )


def audit_r3() -> dict[str, Any]:
    claimed = (1, 3, 4, 5, 2, 6)
    rows = []
    first_nonrepairable = None
    shape_failures = criterion_failures = support_failures = outer_swap_repairs = 0
    for n in range(1, 7):
        one_collision = repairable = nonrepairable = total_repairs = 0
        for p in itertools.permutations(range(1, n + 1)):
            vector = exactly_one_collision(p)
            if vector is None:
                continue
            one_collision += 1
            occurrences = vector_occurrences(p)[vector]
            point_columns = set(occurrences[0] + occurrences[1])
            ordered = sorted(point_columns)
            shape_ok = (
                len(point_columns) == 3
                and ordered[1] - ordered[0] == ordered[2] - ordered[1] == vector[0]
                and p[ordered[1]] - p[ordered[0]] == p[ordered[2]] - p[ordered[1]] == vector[1]
            )
            shape_failures += not shape_ok
            repairs = []
            for a, b in itertools.combinations(range(n), 2):
                q = list(p)
                q[a], q[b] = q[b], q[a]
                actual = is_costas(tuple(q))
                predicted = r3_partition_criterion(p, a, b)
                criterion_failures += actual != predicted
                if actual:
                    repairs.append((a, b))
                    support_failures += not ({a, b} & point_columns)
                    outer_swap_repairs += shape_ok and {a, b} == {ordered[0], ordered[2]}
            total_repairs += len(repairs)
            repairable += bool(repairs)
            nonrepairable += not repairs
            if not repairs and first_nonrepairable is None:
                first_nonrepairable = p
        rows.append(
            {
                "n": n,
                "one_collision": one_collision,
                "repairable": repairable,
                "nonrepairable": nonrepairable,
                "repair_transpositions": total_repairs,
            }
        )
    return {
        "orders": rows,
        "first_lexicographic_nonrepairable": list(first_nonrepairable or ()),
        "claimed_counterexample_exactly_one_collision": list(exactly_one_collision(claimed) or ()),
        "claimed_counterexample_repair_count": sum(
            is_costas(claimed[:a] + (claimed[b],) + claimed[a + 1 : b] + (claimed[a],) + claimed[b + 1 :])
            for a, b in itertools.combinations(range(6), 2)
        ),
        "shape_failures": shape_failures,
        "partition_criterion_failures": criterion_failures,
        "repairs_not_touching_collision_columns": support_failures,
        "outer_endpoint_swap_repairs": outer_swap_repairs,
        "n32_allowed_swap_count": math.comb(32, 2) - math.comb(29, 2) - 1,
    }


def main() -> int:
    audited_files = [
        ROOT / "work/wave2_gf32_two/search.cpp",
        ROOT / "work/wave2_gf32_two/repair_result.json",
        ROOT / "work/wave2_w1p31_two/search.cpp",
        ROOT / "work/wave2_w1p31_two/repair_result.json",
        ROOT / "work/wave2_w1p37_delete4/search.cpp",
        ROOT / "work/wave2_w1p37_delete4/result.json",
        ROLE7 / "independent_wave2_search.cpp",
        ROLE7 / "R7-W2-GF32-TWO-001_result.json",
        ROLE7 / "R7-W2-W1P31-TWO-002_result.json",
        ROLE7 / "R7-W2-W1P37-DEL4-003_result.json",
        ROOT / "work/role2/ROLE2_REPORT.md",
        ROOT / "work/role2/analyze_structures.py",
        ROOT / "work/role3/role3_report.md",
        ROOT / "work/role3/enumerate_one_collision.py",
        ROOT / "work/role3/crosscheck_one_collision.py",
    ]
    result = {
        "marker": "COSTAS_ROLE8_ADVERSARIAL_AUDIT_V1",
        "python": sys.version,
        "indexing": "1-based externally; 0-based internal tuple positions",
        "difference": "signed integer (right-left, p[right]-p[left]); never modular",
        "source_sha256_before_run": file_sha256(Path(__file__)),
        "audited_file_sha256": {str(path.relative_to(ROOT)): file_sha256(path) for path in audited_files},
        "synthetic_verifier_regression": audit_synthetic_verifier_regression(),
        "base_families": audit_base_families(),
        "result_arithmetic": audit_result_arithmetic(),
        "small_parameterization_regression": audit_parameterization_regression(),
        "random_domain_samples": audit_random_domain_samples(),
        "R2_C1": audit_r2(),
        "R3_C1_C2": audit_r3(),
    }
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "output": str(OUTPUT)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
