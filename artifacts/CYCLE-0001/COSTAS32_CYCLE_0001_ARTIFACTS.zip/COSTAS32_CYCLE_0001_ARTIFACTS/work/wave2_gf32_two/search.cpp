#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <string>
#include <vector>

using Perm30 = std::array<std::uint8_t, 30>;
using Perm32 = std::array<std::uint8_t, 32>;

// GF(32) in GF(2)[x]/(x^5+x^3+1), deliberately different from role 1.
static std::uint8_t gf_mul(std::uint8_t a, std::uint8_t b) {
    std::uint8_t result = 0;
    while (b) {
        if (b & 1U) result ^= a;
        b >>= 1U;
        const bool carry = (a & 0x10U) != 0;
        a = static_cast<std::uint8_t>((a << 1U) & 0x1fU);
        if (carry) a ^= 0x09U; // x^3+1
    }
    return result;
}

static std::vector<Perm30> make_unique_g2_bases() {
    std::set<Perm30> unique;
    for (std::uint8_t alpha = 2; alpha < 32; ++alpha) {
        std::array<std::uint8_t, 32> log_alpha{};
        std::uint8_t power = 1;
        for (int exponent = 1; exponent <= 31; ++exponent) {
            power = gf_mul(power, alpha);
            if (exponent <= 30) log_alpha[power] = static_cast<std::uint8_t>(exponent);
        }
        if (power != 1) throw std::runtime_error("alpha does not have order 31");
        for (std::uint8_t beta = 2; beta < 32; ++beta) {
            Perm30 permutation{};
            std::uint8_t beta_power = 1;
            for (int i = 1; i <= 30; ++i) {
                beta_power = gf_mul(beta_power, beta);
                const std::uint8_t target = static_cast<std::uint8_t>(1U ^ beta_power);
                const std::uint8_t exponent = log_alpha[target];
                if (target == 0 || exponent == 0) {
                    throw std::runtime_error("invalid G2 logarithm");
                }
                permutation[static_cast<std::size_t>(i - 1)] = exponent;
            }
            unique.insert(permutation);
        }
    }
    return std::vector<Perm30>(unique.begin(), unique.end());
}

static bool is_costas(const Perm32& p) {
    for (int distance = 1; distance < 32; ++distance) {
        std::uint64_t used = 0;
        for (int start = 0; start + distance < 32; ++start) {
            const int difference = static_cast<int>(p[start + distance]) - static_cast<int>(p[start]);
            const unsigned bit = static_cast<unsigned>(difference + 31);
            const std::uint64_t mask = UINT64_C(1) << bit;
            if (used & mask) return false;
            used |= mask;
        }
    }
    return true;
}

struct CollisionSummary {
    int excess_capped_at_two = 0;
    std::array<int, 4> first_collision_columns{};
};

static CollisionSummary collision_summary(const Perm32& p) {
    CollisionSummary summary;
    for (int distance = 1; distance < 32; ++distance) {
        std::array<int, 63> first_start{};
        first_start.fill(-1);
        for (int start = 0; start + distance < 32; ++start) {
            const int difference = static_cast<int>(p[start + distance]) - static_cast<int>(p[start]);
            const int index = difference + 31;
            if (first_start[index] >= 0) {
                ++summary.excess_capped_at_two;
                if (summary.excess_capped_at_two == 1) {
                    summary.first_collision_columns = {
                        first_start[index], first_start[index] + distance,
                        start, start + distance
                    };
                }
                if (summary.excess_capped_at_two >= 2) return summary;
            } else {
                first_start[index] = start;
            }
        }
    }
    return summary;
}

static std::vector<std::array<int, 2>> pairs32() {
    std::vector<std::array<int, 2>> result;
    result.reserve(496);
    for (int a = 0; a < 32; ++a) {
        for (int b = a + 1; b < 32; ++b) result.push_back({a, b});
    }
    return result;
}

static std::array<std::uint8_t, 30> complement_map(const std::array<int, 2>& omitted) {
    std::array<std::uint8_t, 30> result{};
    int cursor = 0;
    for (int value = 0; value < 32; ++value) {
        if (value == omitted[0] || value == omitted[1]) continue;
        result[static_cast<std::size_t>(cursor++)] = static_cast<std::uint8_t>(value + 1);
    }
    return result;
}

static void emit_array(std::ostream& out, const Perm32& p) {
    out << '[';
    for (std::size_t i = 0; i < p.size(); ++i) {
        if (i) out << ',';
        out << static_cast<int>(p[i]);
    }
    out << ']';
}

int main(int argc, char** argv) {
    const std::string output_path = argc > 1 ? argv[1] : "result.json";
    const auto started = std::chrono::steady_clock::now();
    const auto bases = make_unique_g2_bases();
    const auto pairs = pairs32();
    std::vector<std::array<std::uint8_t, 30>> maps;
    maps.reserve(pairs.size());
    for (const auto& pair : pairs) maps.push_back(complement_map(pair));

    std::uint64_t checked = 0;
    std::uint64_t witnesses = 0;
    std::uint64_t one_collision_cases = 0;
    std::uint64_t repair_witnesses = 0;
    Perm32 first_witness{};
    std::size_t witness_base = 0;
    std::array<int, 2> witness_columns{};
    std::array<int, 2> witness_rows{};
    int witness_matching = -1;
    Perm32 first_repair_witness{};
    std::array<int, 2> first_repair_swap{};
    std::size_t first_repair_base = 0;
    std::array<int, 2> first_repair_columns{};
    std::array<int, 2> first_repair_rows{};
    int first_repair_matching = -1;

    for (std::size_t base_index = 0; base_index < bases.size(); ++base_index) {
        const auto& base = bases[base_index];
        for (std::size_t column_index = 0; column_index < pairs.size(); ++column_index) {
            const auto& columns = pairs[column_index];
            const auto& column_map = maps[column_index];
            for (std::size_t row_index = 0; row_index < pairs.size(); ++row_index) {
                const auto& rows = pairs[row_index];
                const auto& row_map = maps[row_index];
                Perm32 candidate{};
                for (int old_column = 0; old_column < 30; ++old_column) {
                    const int new_column = static_cast<int>(column_map[old_column]) - 1;
                    candidate[new_column] = row_map[base[old_column] - 1];
                }
                for (int matching = 0; matching < 2; ++matching) {
                    candidate[columns[0]] = static_cast<std::uint8_t>(rows[matching] + 1);
                    candidate[columns[1]] = static_cast<std::uint8_t>(rows[1 - matching] + 1);
                    ++checked;
                    const CollisionSummary collisions = collision_summary(candidate);
                    if (collisions.excess_capped_at_two == 0) {
                        ++witnesses;
                        if (witnesses == 1) {
                            first_witness = candidate;
                            witness_base = base_index;
                            witness_columns = columns;
                            witness_rows = rows;
                            witness_matching = matching;
                        }
                    } else if (collisions.excess_capped_at_two == 1) {
                        ++one_collision_cases;
                        std::set<std::array<int, 2>> eligible_swaps;
                        for (int collision_column : collisions.first_collision_columns) {
                            for (int other = 0; other < 32; ++other) {
                                if (collision_column == other) continue;
                                eligible_swaps.insert({
                                    std::min(collision_column, other),
                                    std::max(collision_column, other)
                                });
                            }
                        }
                        for (const auto& swap_pair : eligible_swaps) {
                            Perm32 repaired = candidate;
                            std::swap(repaired[swap_pair[0]], repaired[swap_pair[1]]);
                            if (!is_costas(repaired)) continue;
                            ++repair_witnesses;
                            if (repair_witnesses == 1) {
                                first_repair_witness = repaired;
                                first_repair_swap = swap_pair;
                                first_repair_base = base_index;
                                first_repair_columns = columns;
                                first_repair_rows = rows;
                                first_repair_matching = matching;
                            }
                        }
                    }
                }
            }
        }
        if ((base_index + 1) % 10 == 0 || base_index + 1 == bases.size()) {
            std::cerr << "bases " << (base_index + 1) << '/' << bases.size()
                      << " checked " << checked << " witnesses " << witnesses
                      << " one_collision " << one_collision_cases
                      << " repair_witnesses " << repair_witnesses << '\n';
        }
    }

    const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
    std::ofstream out(output_path);
    out << "{\n"
        << "  \"marker\": \"COSTAS_WAVE2_GF32_G2_TWO_INSERTIONS_V1\",\n"
        << "  \"field_polynomial\": \"x^5+x^3+1\",\n"
        << "  \"primitive_parameter_pairs\": 900,\n"
        << "  \"distinct_g2_bases\": " << bases.size() << ",\n"
        << "  \"column_pairs\": " << pairs.size() << ",\n"
        << "  \"row_pairs\": " << pairs.size() << ",\n"
        << "  \"matchings_per_pair\": 2,\n"
        << "  \"expected_cases_if_180_bases\": 88565760,\n"
        << "  \"checked_cases\": " << checked << ",\n"
        << "  \"witness_count\": " << witnesses << ",\n"
        << "  \"one_collision_parameter_cases\": " << one_collision_cases << ",\n"
        << "  \"repair_witness_count\": " << repair_witnesses << ",\n"
        << "  \"status\": \"" << ((witnesses || repair_witnesses) ? "witness_found" : "exhausted_in_domain") << "\",\n"
        << "  \"elapsed_seconds\": " << seconds << ",\n"
        << "  \"first_witness\": ";
    if (witnesses) {
        emit_array(out, first_witness);
        out << ",\n  \"first_witness_parameters\": {\"base_index\": " << witness_base
            << ", \"columns_1_based\": [" << witness_columns[0] + 1 << ',' << witness_columns[1] + 1
            << "], \"rows_1_based\": [" << witness_rows[0] + 1 << ',' << witness_rows[1] + 1
            << "], \"matching\": " << witness_matching << "},\n";
    } else {
        out << "null,\n";
    }
    out << "  \"first_repair_witness\": ";
    if (repair_witnesses) {
        emit_array(out, first_repair_witness);
        out << ",\n  \"first_repair_parameters\": {\"base_index\": " << first_repair_base
            << ", \"columns_1_based\": [" << first_repair_columns[0] + 1 << ',' << first_repair_columns[1] + 1
            << "], \"rows_1_based\": [" << first_repair_rows[0] + 1 << ',' << first_repair_rows[1] + 1
            << "], \"matching\": " << first_repair_matching
            << ", \"swap_columns_1_based\": [" << first_repair_swap[0] + 1 << ',' << first_repair_swap[1] + 1 << "]}\n";
    } else {
        out << "null\n";
    }
    out << "}\n";
    std::cerr << "completed in " << seconds << " seconds\n";
    return 0;
}
