#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

using Perm36 = std::array<std::uint8_t, 36>;
using Perm32 = std::array<std::uint8_t, 32>;

static int mod_pow(int base, int exponent) {
    int result = 1;
    while (exponent--) result = (result * base) % 37;
    return result;
}

static std::vector<Perm36> make_bases(int& root_count) {
    std::set<Perm36> unique;
    root_count = 0;
    for (int root = 2; root < 37; ++root) {
        std::set<int> values;
        for (int exponent = 0; exponent < 36; ++exponent) values.insert(mod_pow(root, exponent));
        if (values.size() != 36) continue;
        ++root_count;
        for (int shift = 0; shift < 36; ++shift) {
            Perm36 permutation{};
            for (int i = 0; i < 36; ++i) permutation[i] = mod_pow(root, i + shift);
            unique.insert(permutation);
        }
    }
    return std::vector<Perm36>(unique.begin(), unique.end());
}

static bool is_costas(const Perm32& permutation) {
    for (int distance = 1; distance < 32; ++distance) {
        std::uint64_t used = 0;
        for (int start = 0; start + distance < 32; ++start) {
            const int difference = static_cast<int>(permutation[start + distance]) - permutation[start];
            const std::uint64_t bit = UINT64_C(1) << static_cast<unsigned>(difference + 31);
            if (used & bit) return false;
            used |= bit;
        }
    }
    return true;
}

static void write_permutation(std::ostream& output, const Perm32& permutation) {
    output << '[';
    for (std::size_t i = 0; i < permutation.size(); ++i) {
        if (i) output << ',';
        output << static_cast<int>(permutation[i]);
    }
    output << ']';
}

int main(int argc, char** argv) {
    const std::string output_path = argc > 1 ? argv[1] : "result.json";
    const auto started = std::chrono::steady_clock::now();
    int root_count = 0;
    const auto bases = make_bases(root_count);
    std::uint64_t checked = 0;
    std::uint64_t witnesses = 0;
    Perm32 first_witness{};
    std::size_t first_base = 0;
    std::array<int, 4> first_deleted{};

    for (std::size_t base_index = 0; base_index < bases.size(); ++base_index) {
        const auto& base = bases[base_index];
        for (int a = 0; a < 33; ++a) {
            for (int b = a + 1; b < 34; ++b) {
                for (int c = b + 1; c < 35; ++c) {
                    for (int d = c + 1; d < 36; ++d) {
                        const std::array<int, 4> deleted_columns{a, b, c, d};
                        std::array<int, 4> deleted_values{
                            base[a], base[b], base[c], base[d]
                        };
                        Perm32 candidate{};
                        int new_column = 0;
                        for (int old_column = 0; old_column < 36; ++old_column) {
                            if (old_column == a || old_column == b || old_column == c || old_column == d) continue;
                            int compressed_value = base[old_column];
                            for (int removed : deleted_values) {
                                if (removed < base[old_column]) --compressed_value;
                            }
                            candidate[new_column++] = compressed_value;
                        }
                        ++checked;
                        if (is_costas(candidate)) {
                            ++witnesses;
                            if (witnesses == 1) {
                                first_witness = candidate;
                                first_base = base_index;
                                first_deleted = deleted_columns;
                            }
                        }
                    }
                }
            }
        }
        if ((base_index + 1) % 36 == 0 || base_index + 1 == bases.size()) {
            std::cerr << "bases " << base_index + 1 << '/' << bases.size()
                      << " checked " << checked << " witnesses " << witnesses << '\n';
        }
    }

    const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
    std::ofstream output(output_path);
    output << "{\n  \"marker\": \"COSTAS_WAVE2_W1P37_DELETE4_V1\",\n"
           << "  \"prime\": 37,\n  \"primitive_roots\": " << root_count
           << ",\n  \"shifts_per_root\": 36,\n  \"distinct_w1_bases\": " << bases.size()
           << ",\n  \"deletion_subsets_per_base\": 58905,\n  \"checked_cases\": " << checked
           << ",\n  \"witness_count\": " << witnesses
           << ",\n  \"status\": \"" << (witnesses ? "witness_found" : "exhausted_in_domain")
           << "\",\n  \"elapsed_seconds\": " << seconds << ",\n  \"first_witness\": ";
    if (witnesses) {
        write_permutation(output, first_witness);
        output << ",\n  \"first_witness_parameters\": {\"base_index\": " << first_base
               << ", \"deleted_columns_1_based\": [" << first_deleted[0] + 1 << ','
               << first_deleted[1] + 1 << ',' << first_deleted[2] + 1 << ','
               << first_deleted[3] + 1 << "]}\n";
    } else {
        output << "null\n";
    }
    output << "}\n";
    std::cerr << "completed in " << seconds << " seconds\n";
}
