#!/usr/bin/env python3
"""Independent difference-triangle cross-check for role-3 enumeration.

This implementation does not import enumerate_one_collision.py.  It processes
one horizontal distance at a time and represents a transposition by tuple
slicing/list conversion, providing a different implementation of the core
collision test.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path


def collision_excess_and_vector(p: tuple[int, ...]) -> tuple[int, tuple[int, int] | None]:
    excess = 0
    unique_duplicate = None
    n = len(p)
    for d in range(1, n):
        locations: dict[int, int] = {}
        for i in range(n - d):
            dy = p[i + d] - p[i]
            old = locations.get(dy, 0)
            locations[dy] = old + 1
        for dy, multiplicity in locations.items():
            if multiplicity > 1:
                excess += multiplicity - 1
                if excess == 1 and multiplicity == 2:
                    unique_duplicate = (d, dy)
                else:
                    unique_duplicate = None
                if excess > 1:
                    return excess, None
    return excess, unique_duplicate


def triangle_is_costas(p: tuple[int, ...]) -> bool:
    n = len(p)
    for d in range(1, n):
        row = [p[i + d] - p[i] for i in range(n - d)]
        if len(row) != len(set(row)):
            return False
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-order", type=int, default=9)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = []
    for n in range(1, args.max_order + 1):
        count = repairable = nonrepairable = total_repairs = 0
        shape_failures = 0
        repair_support_failures = 0
        outer_endpoint_swap_repairs = 0
        membership_digest = hashlib.sha256()
        repair_digest = hashlib.sha256()
        for p in itertools.permutations(range(1, n + 1)):
            excess, vector = collision_excess_and_vector(p)
            if excess != 1 or vector is None:
                continue
            count += 1
            d, dy = vector
            starts = [i for i in range(n - d) if p[i + d] - p[i] == dy]
            is_three_term_progression = (
                len(starts) == 2
                and starts[1] == starts[0] + d
                and p[starts[0] + d] == p[starts[0]] + dy
                and p[starts[0] + 2 * d] == p[starts[0]] + 2 * dy
            )
            if not is_three_term_progression:
                shape_failures += 1
            collision_columns = (
                {starts[0], starts[0] + d, starts[0] + 2 * d}
                if is_three_term_progression
                else set()
            )
            repairs = []
            for a, b in itertools.combinations(range(n), 2):
                q = list(p)
                q[a], q[b] = q[b], q[a]
                if triangle_is_costas(tuple(q)):
                    repairs.append([a + 1, b + 1])
                    if not ({a, b} & collision_columns):
                        repair_support_failures += 1
                    if is_three_term_progression and {a, b} == {
                        starts[0], starts[0] + 2 * d
                    }:
                        outer_endpoint_swap_repairs += 1
            membership_digest.update((",".join(map(str, p)) + "\n").encode("ascii"))
            repair_digest.update(
                (
                    ",".join(map(str, p))
                    + ":"
                    + ";".join(f"{a},{b}" for a, b in repairs)
                    + "\n"
                ).encode("ascii")
            )
            total_repairs += len(repairs)
            repairable += bool(repairs)
            nonrepairable += not repairs
        row = {
            "order": n,
            "exactly_one_collision": count,
            "repairable_by_a_transposition": repairable,
            "nonrepairable_by_any_transposition": nonrepairable,
            "total_repairing_transpositions": total_repairs,
            "shape_failures": shape_failures,
            "repair_support_failures": repair_support_failures,
            "outer_endpoint_swap_repairs": outer_endpoint_swap_repairs,
            "one_collision_membership_sha256": membership_digest.hexdigest(),
            "repair_relation_sha256": repair_digest.hexdigest(),
        }
        rows.append(row)
        print(json.dumps(row, separators=(",", ":")), flush=True)
    args.output.write_text(
        json.dumps({"marker": "COSTAS_ROLE3_ONE_COLLISION_CROSSCHECK_V1", "by_order": rows}, indent=2)
        + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
