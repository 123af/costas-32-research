#!/usr/bin/env python3
"""Audit explicit role-3 success/failure cases with both supplied verifiers."""

from __future__ import annotations

import hashlib
import importlib.util
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


ref = load("role3_ref", ROOT / "upload/reference_verifier(1).py")
ind = load("role3_ind", ROOT / "upload/independent_verifier(1).py")


def reports(p: list[int]) -> dict:
    a = ref.verify_permutation(p)
    b = ind.verify_permutation(p)
    comparable = [
        "order",
        "valid_input",
        "is_permutation",
        "is_costas",
        "duplicate_vector_count",
        "duplicate_pair_occurrence_excess",
        "duplicate_vectors",
        "permutation_sha256",
    ]
    assert all(a[k] == b[k] for k in comparable)
    return {"reference": a, "independent": b, "agree": True}


def vec(p: list[int], i: int, j: int) -> list[int]:
    return [j - i, p[j] - p[i]]


def swap_audit(p: list[int], a: int, b: int) -> dict:
    q = p[:]
    q[a], q[b] = q[b], q[a]
    affected = []
    unaffected = []
    for i, j in itertools.combinations(range(len(p)), 2):
        record = {
            "point_columns_1_based": [i + 1, j + 1],
            "old_vector": vec(p, i, j),
            "new_vector": vec(q, i, j),
        }
        if i in (a, b) or j in (a, b):
            affected.append(record)
        else:
            assert record["old_vector"] == record["new_vector"]
            unaffected.append(record)
    return {
        "source": p,
        "swap_positions_1_based": [a + 1, b + 1],
        "result": q,
        "affected_pair_count": len(affected),
        "affected_pairs_all": affected,
        "unaffected_pair_count": len(unaffected),
        "verification": reports(q),
    }


def main() -> int:
    success_source = [1, 2, 4, 6, 5, 3]
    failure_source = [1, 3, 4, 5, 2, 6]
    failure_swaps = []
    for a, b in itertools.combinations(range(6), 2):
        item = swap_audit(failure_source, a, b)
        failure_swaps.append(
            {
                "swap_positions_1_based": item["swap_positions_1_based"],
                "result": item["result"],
                "is_costas": item["verification"]["reference"]["is_costas"],
                "duplicate_vectors": item["verification"]["reference"]["duplicate_vectors"],
            }
        )
    assert all(not item["is_costas"] for item in failure_swaps)
    output = {
        "marker": "COSTAS_ROLE3_EXPLICIT_AUDIT_V1",
        "success": {
            "source_verification": reports(success_source),
            "transformation": swap_audit(success_source, 0, 3),
        },
        "minimal_transposition_counterexample": {
            "source_verification": reports(failure_source),
            "all_15_transpositions": failure_swaps,
        },
    }
    target = Path(__file__).with_name("explicit_cases_audit.json")
    target.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": "PASS",
        "output": str(target),
        "output_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
