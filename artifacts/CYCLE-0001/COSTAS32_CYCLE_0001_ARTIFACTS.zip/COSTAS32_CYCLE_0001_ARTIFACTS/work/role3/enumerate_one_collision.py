#!/usr/bin/env python3
"""Complete small-order classification of exactly-one-collision permutations.

Definitions are the project definitions: for each pair i<j, use the signed
displacement vector (j-i, p[j]-p[i]).  A permutation has exactly one collision
when precisely one vector has multiplicity two and every other vector has
multiplicity one (duplicate occurrence excess = 1).

For each such permutation, exhaustively test every value transposition.  This
is intentionally self-contained and does not import either project verifier.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import platform
import sys
import time
from pathlib import Path


def vector_multiplicities(p: tuple[int, ...]) -> dict[tuple[int, int], int]:
    n = len(p)
    counts: dict[tuple[int, int], int] = {}
    for i in range(n - 1):
        pi = p[i]
        for j in range(i + 1, n):
            v = (j - i, p[j] - pi)
            counts[v] = counts.get(v, 0) + 1
    return counts


def exactly_one_collision(p: tuple[int, ...]) -> tuple[int, int] | None:
    repeated: tuple[int, int] | None = None
    for vector, count in vector_multiplicities(p).items():
        if count == 1:
            continue
        if count != 2 or repeated is not None:
            return None
        repeated = vector
    return repeated


def is_costas(p: list[int]) -> bool:
    n = len(p)
    seen: set[tuple[int, int]] = set()
    for i in range(n - 1):
        pi = p[i]
        for j in range(i + 1, n):
            v = (j - i, p[j] - pi)
            if v in seen:
                return False
            seen.add(v)
    return True


def collision_pairs(p: tuple[int, ...], target: tuple[int, int]) -> list[list[list[int]]]:
    n = len(p)
    out: list[list[list[int]]] = []
    for i in range(n - 1):
        for j in range(i + 1, n):
            if (j - i, p[j] - p[i]) == target:
                out.append([[i + 1, p[i]], [j + 1, p[j]]])
    return out


def repairing_transpositions(p: tuple[int, ...]) -> list[list[int]]:
    q = list(p)
    repairs: list[list[int]] = []
    for a in range(len(q) - 1):
        for b in range(a + 1, len(q)):
            q[a], q[b] = q[b], q[a]
            if is_costas(q):
                repairs.append([a + 1, b + 1])
            q[a], q[b] = q[b], q[a]
    return repairs


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-order", type=int, default=9)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    started = time.monotonic()
    by_order = []
    first_nonrepairable = None
    for n in range(1, args.max_order + 1):
        total = 0
        one_collision = 0
        repairable = 0
        nonrepairable = 0
        total_repairs = 0
        examples_success = []
        examples_failure = []
        membership_digest = hashlib.sha256()
        repair_digest = hashlib.sha256()
        t0 = time.monotonic()
        for p in itertools.permutations(range(1, n + 1)):
            total += 1
            vector = exactly_one_collision(p)
            if vector is None:
                continue
            one_collision += 1
            repairs = repairing_transpositions(p)
            membership_digest.update(
                (",".join(map(str, p)) + "\n").encode("ascii")
            )
            repair_digest.update(
                (
                    ",".join(map(str, p))
                    + ":"
                    + ";".join(f"{a},{b}" for a, b in repairs)
                    + "\n"
                ).encode("ascii")
            )
            total_repairs += len(repairs)
            record = {
                "permutation": list(p),
                "collision_vector": list(vector),
                "collision_point_pairs": collision_pairs(p, vector),
                "repairing_transpositions": repairs,
            }
            if repairs:
                repairable += 1
                if len(examples_success) < 3:
                    examples_success.append(record)
            else:
                nonrepairable += 1
                if len(examples_failure) < 3:
                    examples_failure.append(record)
                if first_nonrepairable is None:
                    first_nonrepairable = {"order": n, **record}
        by_order.append(
            {
                "order": n,
                "permutations_checked": total,
                "exactly_one_collision": one_collision,
                "repairable_by_a_transposition": repairable,
                "nonrepairable_by_any_transposition": nonrepairable,
                "total_repairing_transpositions": total_repairs,
                "one_collision_membership_sha256": membership_digest.hexdigest(),
                "repair_relation_sha256": repair_digest.hexdigest(),
                "success_examples": examples_success,
                "failure_examples": examples_failure,
                "elapsed_seconds": time.monotonic() - t0,
            }
        )
        print(json.dumps(by_order[-1], separators=(",", ":")), flush=True)

    source_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result = {
        "marker": "COSTAS_ROLE3_ONE_COLLISION_ENUM_V1",
        "definition": "exactly one displacement vector has multiplicity 2; all others multiplicity 1",
        "transformation_domain": "all unordered transpositions of two permutation positions",
        "indexing": "1-based",
        "complete_orders": [1, args.max_order],
        "by_order": by_order,
        "minimal_nonrepairable_by_order": first_nonrepairable,
        "environment": {
            "python": sys.version,
            "platform": platform.platform(),
            "script_sha256": source_hash,
            "elapsed_seconds": time.monotonic() - started,
        },
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
