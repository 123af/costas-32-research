#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <mutex>
#include <numeric>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

using Clock = std::chrono::steady_clock;

static std::string permutation_key(const std::vector<int>& p) {
    std::string key;
    key.reserve(p.size());
    for (int value : p) key.push_back(static_cast<char>(value));
    return key;
}

static std::string vector_json(const std::vector<int>& values) {
    std::ostringstream out;
    out << '[';
    for (std::size_t i = 0; i < values.size(); ++i) {
        if (i) out << ',';
        out << values[i];
    }
    out << ']';
    return out.str();
}

static bool is_permutation(const std::vector<int>& p) {
    std::array<bool, 37> used{};
    for (int value : p) {
        if (value < 1 || value > static_cast<int>(p.size()) || used[value]) return false;
        used[value] = true;
    }
    return !p.empty();
}

// Primary independent condition checker.  Every unordered pair of points is
// visited explicitly and its signed (dx,dy) displacement occupies one cell.
// Pairs are ordered by dx only to make rejection fast; the criterion remains
// pair-displacement uniqueness and shares no code with supplied verifiers.
class PointPairChecker {
  public:
    bool is_costas(const std::uint8_t* p, int n) {
        ++generation_;
        if (generation_ == 0) {
            seen_.fill(0);
            generation_ = 1;
        }
        for (int dx = 1; dx < n; ++dx) {
            for (int left = 0; left + dx < n; ++left) {
                const int dy = static_cast<int>(p[left + dx]) - static_cast<int>(p[left]);
                const int key = dx * 73 + (dy + 36);
                if (seen_[key] == generation_) return false;
                seen_[key] = generation_;
            }
        }
        return true;
    }

    bool is_costas(const std::vector<int>& p) {
        std::array<std::uint8_t, 36> compact{};
        for (int i = 0; i < static_cast<int>(p.size()); ++i) compact[i] = static_cast<std::uint8_t>(p[i]);
        return is_costas(compact.data(), static_cast<int>(p.size()));
    }

  private:
    std::array<std::uint32_t, 37 * 73> seen_{};
    std::uint32_t generation_ = 0;
};

static int modular_power(int base, int exponent, int prime) {
    int result = 1;
    while (exponent) {
        if (exponent & 1) result = result * base % prime;
        base = base * base % prime;
        exponent >>= 1;
    }
    return result;
}

static std::vector<int> primitive_roots_prime(int prime, const std::vector<int>& prime_divisors_of_phi) {
    std::vector<int> roots;
    const int phi = prime - 1;
    for (int g = 2; g < prime; ++g) {
        bool primitive = true;
        for (int divisor : prime_divisors_of_phi) {
            if (modular_power(g, phi / divisor, prime) == 1) primitive = false;
        }
        if (primitive) roots.push_back(g);
    }
    return roots;
}

static std::vector<std::vector<int>> generate_w1_bases(int prime, const std::vector<int>& primitive_roots) {
    std::vector<std::vector<int>> bases;
    for (int g : primitive_roots) {
        for (int shift = 0; shift < prime - 1; ++shift) {
            std::vector<int> p(prime - 1);
            int current = modular_power(g, shift, prime);
            for (int i = 0; i < prime - 1; ++i) {
                p[i] = current;
                current = current * g % prime;
            }
            bases.push_back(std::move(p));
        }
    }
    return bases;
}

// Independent GF(32): GF(2)[x]/(x^5+x^4+x^2+x+1), with carryless
// convolution followed by a separate polynomial long-division pass.
constexpr std::uint32_t GF32_MODULUS = 0b110111;

static int gf32_multiply(int a, int b) {
    std::uint32_t product = 0;
    for (int bit = 0; bit < 5; ++bit) {
        if ((b >> bit) & 1) product ^= static_cast<std::uint32_t>(a) << bit;
    }
    for (int degree = 8; degree >= 5; --degree) {
        if ((product >> degree) & 1U) product ^= GF32_MODULUS << (degree - 5);
    }
    return static_cast<int>(product & 31U);
}

static int gf32_power(int base, int exponent) {
    int result = 1;
    while (exponent) {
        if (exponent & 1) result = gf32_multiply(result, base);
        base = gf32_multiply(base, base);
        exponent >>= 1;
    }
    return result;
}

static bool validate_gf32() {
    for (int a = 1; a < 32; ++a) {
        if (gf32_power(a, 31) != 1) return false;
        int inverses = 0;
        for (int b = 1; b < 32; ++b) {
            if (gf32_multiply(a, b) == 0) return false;
            if (gf32_multiply(a, b) == 1) ++inverses;
        }
        if (inverses != 1) return false;
    }
    return true;
}

static std::vector<int> gf32_primitive_elements() {
    std::vector<int> elements;
    for (int value = 2; value < 32; ++value) {
        std::array<bool, 32> seen{};
        int current = 1;
        for (int exponent = 1; exponent <= 31; ++exponent) {
            current = gf32_multiply(current, value);
            seen[current] = true;
        }
        if (current == 1 && std::count(seen.begin() + 1, seen.end(), true) == 31) elements.push_back(value);
    }
    return elements;
}

static std::vector<int> gf32_g2(int alpha, int beta) {
    std::array<int, 32> log_alpha{};
    int power = 1;
    for (int exponent = 1; exponent <= 30; ++exponent) {
        power = gf32_multiply(power, alpha);
        log_alpha[power] = exponent;
    }
    std::vector<int> p;
    p.reserve(30);
    power = 1;
    for (int i = 1; i <= 30; ++i) {
        power = gf32_multiply(power, beta);
        const int target = power ^ 1;
        if (target == 0 || log_alpha[target] == 0) throw std::runtime_error("GF32 G2 log failure");
        p.push_back(log_alpha[target]);
    }
    return p;
}

struct BaseFamily {
    std::string request_id;
    std::string description;
    std::string generation;
    std::vector<int> generators;
    std::uint64_t raw_parameter_count = 0;
    std::vector<std::vector<int>> bases;
    std::map<int, std::uint64_t> base_multiplicity_histogram;
    std::uint64_t invalid_bases = 0;
};

static BaseFamily make_gf32_family() {
    BaseFamily family;
    family.request_id = "R7-W2-GF32-TWO-001";
    family.description = "all distinct order-30 GF(32) G2 bases, followed by every relative-order-preserving two-point insertion into order 32";
    family.generation = "GF(2)[x]/(x^5+x^4+x^2+x+1); carryless convolution and polynomial long division";
    if (!validate_gf32()) throw std::runtime_error("GF32 field validation failed");
    family.generators = gf32_primitive_elements();
    if (family.generators.size() != 30) throw std::runtime_error("GF32 primitive-element count is not 30");
    std::map<std::string, std::pair<std::vector<int>, int>> unique;
    for (int alpha : family.generators) {
        for (int beta : family.generators) {
            ++family.raw_parameter_count;
            std::vector<int> base = gf32_g2(alpha, beta);
            auto [it, inserted] = unique.emplace(permutation_key(base), std::make_pair(base, 0));
            ++it->second.second;
        }
    }
    PointPairChecker checker;
    for (auto& [key, item] : unique) {
        (void)key;
        if (!is_permutation(item.first) || !checker.is_costas(item.first)) ++family.invalid_bases;
        ++family.base_multiplicity_histogram[item.second];
        family.bases.push_back(std::move(item.first));
    }
    std::sort(family.bases.begin(), family.bases.end());
    return family;
}

static BaseFamily make_w1_p31_family() {
    BaseFamily family;
    family.request_id = "R7-W2-W1P31-TWO-002";
    family.description = "all W1(p=31) bases, followed by every relative-order-preserving two-point insertion into order 32";
    family.generation = "W1 pi(i)=g^(i-1+c) mod 31, all primitive roots and shifts";
    family.generators = primitive_roots_prime(31, {2, 3, 5});
    const auto raw = generate_w1_bases(31, family.generators);
    family.raw_parameter_count = raw.size();
    std::map<std::string, std::pair<std::vector<int>, int>> unique;
    for (const auto& base : raw) {
        auto [it, inserted] = unique.emplace(permutation_key(base), std::make_pair(base, 0));
        ++it->second.second;
    }
    PointPairChecker checker;
    for (auto& [key, item] : unique) {
        (void)key;
        if (!is_permutation(item.first) || !checker.is_costas(item.first)) ++family.invalid_bases;
        ++family.base_multiplicity_histogram[item.second];
        family.bases.push_back(std::move(item.first));
    }
    std::sort(family.bases.begin(), family.bases.end());
    return family;
}

struct TwoSubset {
    int first = 0;
    int second = 0;
    std::array<std::uint8_t, 30> complement{};
};

static std::vector<TwoSubset> all_two_subsets_32() {
    std::vector<TwoSubset> subsets;
    subsets.reserve(496);
    for (int a = 1; a <= 32; ++a) {
        for (int b = a + 1; b <= 32; ++b) {
            TwoSubset item;
            item.first = a;
            item.second = b;
            int at = 0;
            for (int value = 1; value <= 32; ++value) {
                if (value != a && value != b) item.complement[at++] = static_cast<std::uint8_t>(value);
            }
            if (at != 30) throw std::runtime_error("two-subset complement error");
            subsets.push_back(item);
        }
    }
    return subsets;
}

struct Witness {
    bool found = false;
    int base_index = -1;
    int a1 = 0;
    int a2 = 0;
    int b1 = 0;
    int b2 = 0;
    int matching = 0;
    std::vector<int> base;
    std::vector<int> permutation;
};

struct InsertionSearchResult {
    std::string request_id;
    std::string description;
    std::string generation;
    double seconds = 0;
    int threads = 0;
    std::uint64_t raw_parameter_count = 0;
    std::uint64_t unique_bases = 0;
    std::uint64_t invalid_bases = 0;
    std::vector<int> generators;
    std::map<int, std::uint64_t> base_multiplicity_histogram;
    std::uint64_t subsets_a = 496;
    std::uint64_t subsets_b = 496;
    std::uint64_t bijections = 2;
    std::uint64_t expected_candidates = 0;
    std::uint64_t candidates_checked = 0;
    std::uint64_t passing_candidates = 0;
    std::uint64_t bases_completed = 0;
    std::uint64_t minimum_cases_per_completed_base = 0;
    std::uint64_t maximum_cases_per_completed_base = 0;
    Witness witness;
};

static InsertionSearchResult search_two_point_insertions(const BaseFamily& family, int thread_count) {
    const auto start = Clock::now();
    const auto subsets = all_two_subsets_32();
    InsertionSearchResult result;
    result.request_id = family.request_id;
    result.description = family.description;
    result.generation = family.generation;
    result.threads = thread_count;
    result.raw_parameter_count = family.raw_parameter_count;
    result.unique_bases = family.bases.size();
    result.invalid_bases = family.invalid_bases;
    result.generators = family.generators;
    result.base_multiplicity_histogram = family.base_multiplicity_histogram;
    result.expected_candidates = family.bases.size() * 492032ULL;
    if (family.invalid_bases != 0) throw std::runtime_error("invalid source base before insertion search");

    std::atomic<std::size_t> next_base{0};
    std::atomic<bool> stop{false};
    std::mutex witness_mutex;
    std::vector<std::uint64_t> per_base_cases(family.bases.size(), 0);
    std::vector<std::uint64_t> per_thread_hits(thread_count, 0);

    auto worker = [&](int thread_id) {
        PointPairChecker checker;
        while (!stop.load(std::memory_order_relaxed)) {
            const std::size_t base_index = next_base.fetch_add(1, std::memory_order_relaxed);
            if (base_index >= family.bases.size()) break;
            const auto& base = family.bases[base_index];
            std::array<std::array<std::uint8_t, 30>, 496> mapped_rows{};
            for (std::size_t bi = 0; bi < subsets.size(); ++bi) {
                for (int i = 0; i < 30; ++i) {
                    mapped_rows[bi][i] = subsets[bi].complement[base[i] - 1];
                }
            }
            std::uint64_t local_cases = 0;
            std::array<std::uint8_t, 32> candidate{};
            for (std::size_t ai = 0; ai < subsets.size() && !stop.load(std::memory_order_relaxed); ++ai) {
                const auto& columns = subsets[ai];
                for (std::size_t bi = 0; bi < subsets.size(); ++bi) {
                    const auto& rows = subsets[bi];
                    for (int i = 0; i < 30; ++i) candidate[columns.complement[i] - 1] = mapped_rows[bi][i];
                    candidate[columns.first - 1] = static_cast<std::uint8_t>(rows.first);
                    candidate[columns.second - 1] = static_cast<std::uint8_t>(rows.second);
                    ++local_cases;
                    if (checker.is_costas(candidate.data(), 32)) {
                        ++per_thread_hits[thread_id];
                        std::lock_guard<std::mutex> lock(witness_mutex);
                        if (!result.witness.found) {
                            result.witness.found = true;
                            result.witness.base_index = static_cast<int>(base_index);
                            result.witness.a1 = columns.first;
                            result.witness.a2 = columns.second;
                            result.witness.b1 = rows.first;
                            result.witness.b2 = rows.second;
                            result.witness.matching = 0;
                            result.witness.base = base;
                            result.witness.permutation.assign(candidate.begin(), candidate.end());
                        }
                        stop.store(true, std::memory_order_relaxed);
                        break;
                    }
                    candidate[columns.first - 1] = static_cast<std::uint8_t>(rows.second);
                    candidate[columns.second - 1] = static_cast<std::uint8_t>(rows.first);
                    ++local_cases;
                    if (checker.is_costas(candidate.data(), 32)) {
                        ++per_thread_hits[thread_id];
                        std::lock_guard<std::mutex> lock(witness_mutex);
                        if (!result.witness.found) {
                            result.witness.found = true;
                            result.witness.base_index = static_cast<int>(base_index);
                            result.witness.a1 = columns.first;
                            result.witness.a2 = columns.second;
                            result.witness.b1 = rows.first;
                            result.witness.b2 = rows.second;
                            result.witness.matching = 1;
                            result.witness.base = base;
                            result.witness.permutation.assign(candidate.begin(), candidate.end());
                        }
                        stop.store(true, std::memory_order_relaxed);
                        break;
                    }
                }
            }
            per_base_cases[base_index] = local_cases;
            if (local_cases == 492032ULL) {
                const std::size_t done = std::count(per_base_cases.begin(), per_base_cases.end(), 492032ULL);
                if (done % 20 == 0 || done == family.bases.size()) {
                    std::cerr << family.request_id << " progress completed_bases=" << done << '/' << family.bases.size() << '\n';
                }
            }
        }
    };

    std::vector<std::thread> threads;
    for (int id = 0; id < thread_count; ++id) threads.emplace_back(worker, id);
    for (auto& thread : threads) thread.join();

    result.candidates_checked = std::accumulate(per_base_cases.begin(), per_base_cases.end(), 0ULL);
    result.passing_candidates = std::accumulate(per_thread_hits.begin(), per_thread_hits.end(), 0ULL);
    result.bases_completed = std::count(per_base_cases.begin(), per_base_cases.end(), 492032ULL);
    result.minimum_cases_per_completed_base = result.bases_completed ? 492032ULL : 0;
    result.maximum_cases_per_completed_base = *std::max_element(per_base_cases.begin(), per_base_cases.end());
    result.seconds = std::chrono::duration<double>(Clock::now() - start).count();
    return result;
}

static std::string map_json(const std::map<int, std::uint64_t>& values) {
    std::ostringstream out;
    out << '{';
    bool first = true;
    for (const auto& [key, value] : values) {
        if (!first) out << ',';
        first = false;
        out << '"' << key << "\":" << value;
    }
    out << '}';
    return out.str();
}

static void write_bases(const BaseFamily& family, const std::string& path) {
    std::ofstream out(path);
    if (!out) throw std::runtime_error("cannot write base artifact");
    out << "{\n  \"request_id\": \"" << family.request_id << "\",\n";
    out << "  \"generation\": \"" << family.generation << "\",\n";
    out << "  \"raw_parameter_count\": " << family.raw_parameter_count << ",\n";
    out << "  \"unique_base_count\": " << family.bases.size() << ",\n";
    out << "  \"bases_lexicographic\": [\n";
    for (std::size_t i = 0; i < family.bases.size(); ++i) {
        out << "    " << vector_json(family.bases[i]);
        out << (i + 1 == family.bases.size() ? "\n" : ",\n");
    }
    out << "  ]\n}\n";
}

static void write_insertion_result(const InsertionSearchResult& result, const std::string& path) {
    std::ofstream out(path);
    if (!out) throw std::runtime_error("cannot write insertion result");
    out << std::fixed << std::setprecision(9);
    const bool exhausted = !result.witness.found && result.candidates_checked == result.expected_candidates && result.bases_completed == result.unique_bases;
    out << "{\n";
    out << "  \"marker\": \"COSTAS_ROLE7_INDEPENDENT_WAVE2_INSERTION_V1\",\n";
    out << "  \"request_id\": \"" << result.request_id << "\",\n";
    out << "  \"status\": \"" << (result.witness.found ? "witness_found" : (exhausted ? "exhausted_in_domain" : "no_result_within_budget")) << "\",\n";
    out << "  \"description\": \"" << result.description << "\",\n";
    out << "  \"source_generation\": \"" << result.generation << "\",\n";
    out << "  \"primary_checker\": \"explicit unordered point-pair signed-displacement occupancy, early duplicate rejection\",\n";
    out << "  \"symmetry_normalization\": \"none\",\n";
    out << "  \"seconds\": " << result.seconds << ",\n";
    out << "  \"threads\": " << result.threads << ",\n";
    out << "  \"generators\": " << vector_json(result.generators) << ",\n";
    out << "  \"raw_base_parameter_count\": " << result.raw_parameter_count << ",\n";
    out << "  \"unique_bases\": " << result.unique_bases << ",\n";
    out << "  \"invalid_bases\": " << result.invalid_bases << ",\n";
    out << "  \"base_multiplicity_histogram\": " << map_json(result.base_multiplicity_histogram) << ",\n";
    out << "  \"A_subsets\": " << result.subsets_a << ",\n";
    out << "  \"B_subsets\": " << result.subsets_b << ",\n";
    out << "  \"bijections_per_A_B\": " << result.bijections << ",\n";
    out << "  \"expected_candidates\": " << result.expected_candidates << ",\n";
    out << "  \"candidates_checked\": " << result.candidates_checked << ",\n";
    out << "  \"passing_candidates\": " << result.passing_candidates << ",\n";
    out << "  \"bases_completed\": " << result.bases_completed << ",\n";
    out << "  \"minimum_cases_per_completed_base\": " << result.minimum_cases_per_completed_base << ",\n";
    out << "  \"maximum_cases_per_completed_base\": " << result.maximum_cases_per_completed_base << ",\n";
    if (result.witness.found) {
        out << "  \"witness\": {\"base_index\":" << result.witness.base_index
            << ",\"A\":[" << result.witness.a1 << ',' << result.witness.a2 << "]"
            << ",\"B\":[" << result.witness.b1 << ',' << result.witness.b2 << "]"
            << ",\"matching\":\"" << (result.witness.matching == 0 ? "parallel" : "cross") << "\""
            << ",\"base\":" << vector_json(result.witness.base)
            << ",\"permutation\":" << vector_json(result.witness.permutation) << "},\n";
    } else {
        out << "  \"witness\": null,\n";
    }
    out << "  \"unsearched_scope\": \"Other order-30 bases, other source families, insertions changing old-point relative order, and general order-32 permutations.\"\n";
    out << "}\n";
}

struct Delete4Result {
    double seconds = 0;
    int threads = 0;
    std::vector<int> primitive_roots;
    std::uint64_t raw_base_parameters = 0;
    std::uint64_t unique_bases = 0;
    std::uint64_t invalid_bases = 0;
    std::uint64_t deletion_subsets_per_base = 58905;
    std::uint64_t expected_candidates = 0;
    std::uint64_t candidates_checked = 0;
    std::uint64_t passing_candidates = 0;
    std::uint64_t bases_completed = 0;
    Witness witness;
};

static Delete4Result search_w1_p37_delete4(int thread_count, std::vector<std::vector<int>>& unique_bases_out) {
    const auto start = Clock::now();
    Delete4Result result;
    result.threads = thread_count;
    result.primitive_roots = primitive_roots_prime(37, {2, 3});
    const auto raw = generate_w1_bases(37, result.primitive_roots);
    result.raw_base_parameters = raw.size();
    std::map<std::string, std::vector<int>> unique;
    for (const auto& base : raw) unique.emplace(permutation_key(base), base);
    PointPairChecker base_checker;
    for (auto& [key, base] : unique) {
        (void)key;
        if (!is_permutation(base) || !base_checker.is_costas(base)) ++result.invalid_bases;
        unique_bases_out.push_back(std::move(base));
    }
    std::sort(unique_bases_out.begin(), unique_bases_out.end());
    result.unique_bases = unique_bases_out.size();
    result.expected_candidates = result.unique_bases * result.deletion_subsets_per_base;
    if (result.invalid_bases) throw std::runtime_error("invalid W1(p=37) source base");

    std::atomic<std::size_t> next_base{0};
    std::atomic<bool> stop{false};
    std::mutex witness_mutex;
    std::vector<std::uint64_t> per_base_cases(unique_bases_out.size(), 0);
    std::vector<std::uint64_t> per_thread_hits(thread_count, 0);

    auto worker = [&](int thread_id) {
        PointPairChecker checker;
        while (!stop.load(std::memory_order_relaxed)) {
            const std::size_t base_index = next_base.fetch_add(1, std::memory_order_relaxed);
            if (base_index >= unique_bases_out.size()) break;
            const auto& base = unique_bases_out[base_index];
            std::uint64_t local_cases = 0;
            std::array<std::uint8_t, 32> candidate{};
            std::array<bool, 36> deleted_column{};
            std::array<bool, 37> deleted_value{};
            for (int a = 0; a < 33 && !stop.load(std::memory_order_relaxed); ++a) {
                for (int b = a + 1; b < 34; ++b) {
                    for (int c = b + 1; c < 35; ++c) {
                        for (int d = c + 1; d < 36; ++d) {
                            deleted_column.fill(false);
                            deleted_value.fill(false);
                            deleted_column[a] = deleted_column[b] = deleted_column[c] = deleted_column[d] = true;
                            deleted_value[base[a]] = deleted_value[base[b]] = deleted_value[base[c]] = deleted_value[base[d]] = true;
                            int output_column = 0;
                            for (int source_column = 0; source_column < 36; ++source_column) {
                                if (deleted_column[source_column]) continue;
                                const int value = base[source_column];
                                int compressed = value;
                                for (int removed = 1; removed < value; ++removed) {
                                    if (deleted_value[removed]) --compressed;
                                }
                                candidate[output_column++] = static_cast<std::uint8_t>(compressed);
                            }
                            if (output_column != 32) throw std::runtime_error("delete4 construction length error");
                            ++local_cases;
                            if (checker.is_costas(candidate.data(), 32)) {
                                ++per_thread_hits[thread_id];
                                std::lock_guard<std::mutex> lock(witness_mutex);
                                if (!result.witness.found) {
                                    result.witness.found = true;
                                    result.witness.base_index = static_cast<int>(base_index);
                                    result.witness.a1 = a + 1;
                                    result.witness.a2 = b + 1;
                                    result.witness.b1 = c + 1;
                                    result.witness.b2 = d + 1;
                                    result.witness.base = base;
                                    result.witness.permutation.assign(candidate.begin(), candidate.end());
                                }
                                stop.store(true, std::memory_order_relaxed);
                                break;
                            }
                        }
                    }
                }
            }
            per_base_cases[base_index] = local_cases;
            if (local_cases == result.deletion_subsets_per_base) {
                const std::size_t done = std::count(per_base_cases.begin(), per_base_cases.end(), result.deletion_subsets_per_base);
                if (done % 40 == 0 || done == unique_bases_out.size()) {
                    std::cerr << "R7-W2-W1P37-DEL4-003 progress completed_bases=" << done << '/' << unique_bases_out.size() << '\n';
                }
            }
        }
    };

    std::vector<std::thread> threads;
    for (int id = 0; id < thread_count; ++id) threads.emplace_back(worker, id);
    for (auto& thread : threads) thread.join();
    result.candidates_checked = std::accumulate(per_base_cases.begin(), per_base_cases.end(), 0ULL);
    result.passing_candidates = std::accumulate(per_thread_hits.begin(), per_thread_hits.end(), 0ULL);
    result.bases_completed = std::count(per_base_cases.begin(), per_base_cases.end(), result.deletion_subsets_per_base);
    result.seconds = std::chrono::duration<double>(Clock::now() - start).count();
    return result;
}

static void write_plain_bases(const std::string& request_id, const std::string& generation,
                              const std::vector<std::vector<int>>& bases, const std::string& path) {
    std::ofstream out(path);
    if (!out) throw std::runtime_error("cannot write plain bases");
    out << "{\n  \"request_id\": \"" << request_id << "\",\n";
    out << "  \"generation\": \"" << generation << "\",\n";
    out << "  \"unique_base_count\": " << bases.size() << ",\n";
    out << "  \"bases_lexicographic\": [\n";
    for (std::size_t i = 0; i < bases.size(); ++i) {
        out << "    " << vector_json(bases[i]) << (i + 1 == bases.size() ? "\n" : ",\n");
    }
    out << "  ]\n}\n";
}

static void write_delete4_result(const Delete4Result& result, const std::string& path) {
    std::ofstream out(path);
    if (!out) throw std::runtime_error("cannot write delete4 result");
    const bool exhausted = !result.witness.found && result.candidates_checked == result.expected_candidates && result.bases_completed == result.unique_bases;
    out << std::fixed << std::setprecision(9);
    out << "{\n";
    out << "  \"marker\": \"COSTAS_ROLE7_INDEPENDENT_WAVE2_DELETE4_V1\",\n";
    out << "  \"request_id\": \"R7-W2-W1P37-DEL4-003\",\n";
    out << "  \"status\": \"" << (result.witness.found ? "witness_found" : (exhausted ? "exhausted_in_domain" : "no_result_within_budget")) << "\",\n";
    out << "  \"scope\": \"all W1(p=37) primitive roots and shifts; delete any four source points and their rows/columns, then rank-compress\",\n";
    out << "  \"primary_checker\": \"explicit unordered point-pair signed-displacement occupancy, early duplicate rejection\",\n";
    out << "  \"symmetry_normalization\": \"none\",\n";
    out << "  \"seconds\": " << result.seconds << ",\n";
    out << "  \"threads\": " << result.threads << ",\n";
    out << "  \"primitive_roots_mod_37\": " << vector_json(result.primitive_roots) << ",\n";
    out << "  \"raw_base_parameters\": " << result.raw_base_parameters << ",\n";
    out << "  \"unique_bases\": " << result.unique_bases << ",\n";
    out << "  \"invalid_bases\": " << result.invalid_bases << ",\n";
    out << "  \"deletion_subsets_per_base\": " << result.deletion_subsets_per_base << ",\n";
    out << "  \"expected_candidates\": " << result.expected_candidates << ",\n";
    out << "  \"candidates_checked\": " << result.candidates_checked << ",\n";
    out << "  \"passing_candidates\": " << result.passing_candidates << ",\n";
    out << "  \"bases_completed\": " << result.bases_completed << ",\n";
    if (result.witness.found) {
        out << "  \"witness\": {\"base_index\":" << result.witness.base_index
            << ",\"deleted_source_columns\":[" << result.witness.a1 << ',' << result.witness.a2 << ',' << result.witness.b1 << ',' << result.witness.b2 << ']'
            << ",\"base\":" << vector_json(result.witness.base)
            << ",\"permutation\":" << vector_json(result.witness.permutation) << "},\n";
    } else {
        out << "  \"witness\": null,\n";
    }
    out << "  \"unsearched_scope\": \"Non-W1(p=37) sources, deletion of other numbers of points, and general order-32 permutations.\"\n";
    out << "}\n";
}

int main(int argc, char** argv) {
    try {
        std::string output_dir = "work/role7";
        int thread_count = static_cast<int>(std::thread::hardware_concurrency());
        if (thread_count < 1) thread_count = 1;
        for (int i = 1; i < argc; ++i) {
            const std::string arg = argv[i];
            if (arg == "--output-dir" && i + 1 < argc) output_dir = argv[++i];
            else if (arg == "--threads" && i + 1 < argc) thread_count = std::stoi(argv[++i]);
            else throw std::runtime_error("usage: independent_wave2_search [--output-dir DIR] [--threads N]");
        }

        const BaseFamily gf32 = make_gf32_family();
        write_bases(gf32, output_dir + "/R7-W2-GF32-TWO-001_bases.json");
        std::cerr << "starting R7-W2-GF32-TWO-001 bases=" << gf32.bases.size() << " threads=" << thread_count << '\n';
        const InsertionSearchResult gf32_result = search_two_point_insertions(gf32, thread_count);
        write_insertion_result(gf32_result, output_dir + "/R7-W2-GF32-TWO-001_result.json");
        std::cout << gf32_result.request_id << " checked=" << gf32_result.candidates_checked << " hits=" << gf32_result.passing_candidates << " seconds=" << gf32_result.seconds << '\n';
        if (gf32_result.witness.found) return 10;

        const BaseFamily w1p31 = make_w1_p31_family();
        write_bases(w1p31, output_dir + "/R7-W2-W1P31-TWO-002_bases.json");
        std::cerr << "starting R7-W2-W1P31-TWO-002 bases=" << w1p31.bases.size() << " threads=" << thread_count << '\n';
        const InsertionSearchResult w1p31_result = search_two_point_insertions(w1p31, thread_count);
        write_insertion_result(w1p31_result, output_dir + "/R7-W2-W1P31-TWO-002_result.json");
        std::cout << w1p31_result.request_id << " checked=" << w1p31_result.candidates_checked << " hits=" << w1p31_result.passing_candidates << " seconds=" << w1p31_result.seconds << '\n';
        if (w1p31_result.witness.found) return 10;

        std::vector<std::vector<int>> w1p37_bases;
        std::cerr << "starting R7-W2-W1P37-DEL4-003 threads=" << thread_count << '\n';
        const Delete4Result delete4 = search_w1_p37_delete4(thread_count, w1p37_bases);
        write_plain_bases("R7-W2-W1P37-DEL4-003", "W1 pi(i)=g^(i-1+c) mod 37, all primitive roots and shifts", w1p37_bases,
                          output_dir + "/R7-W2-W1P37-DEL4-003_bases.json");
        write_delete4_result(delete4, output_dir + "/R7-W2-W1P37-DEL4-003_result.json");
        std::cout << "R7-W2-W1P37-DEL4-003 checked=" << delete4.candidates_checked << " hits=" << delete4.passing_candidates << " seconds=" << delete4.seconds << '\n';
        return delete4.witness.found ? 10 : 0;
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 1;
    }
}
