#!/usr/bin/env python3
"""Cross-check Role 7's explicit counterexamples with both supplied verifiers.

The exhaustive searches live in independent C++ code.  This script is only a
post-search audit of the concrete counterexamples and representative failures.
"""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from typing import Any, Callable


ROOT = Path(__file__).resolve().parents[2]
ROLE7 = ROOT / "work" / "role7"


def load_verify(path: Path, module_name: str) -> Callable[[Any], dict[str, Any]]:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify_permutation


REFERENCE = load_verify(ROOT / "upload" / "reference_verifier(1).py", "role7_reference")
INDEPENDENT = load_verify(ROOT / "upload" / "independent_verifier(1).py", "role7_independent")


def normalized_collisions(report: dict[str, Any]) -> list[tuple[Any, ...]]:
    normalized = []
    for item in report["duplicate_vectors"]:
        pairs = tuple(sorted(tuple(tuple(point) for point in pair) for pair in item["point_pairs"]))
        normalized.append((tuple(item["vector"]), item["multiplicity"], pairs))
    return sorted(normalized)


def both(permutation: list[int]) -> dict[str, Any]:
    reference = REFERENCE(permutation)
    independent = INDEPENDENT(permutation)
    comparable = (
        "order",
        "valid_input",
        "is_permutation",
        "is_costas",
        "error_code",
        "duplicate_vector_count",
        "duplicate_pair_occurrence_excess",
        "permutation_sha256",
    )
    agreement = all(reference[key] == independent[key] for key in comparable)
    agreement = agreement and normalized_collisions(reference) == normalized_collisions(independent)
    return {
        "permutation": permutation,
        "agreement": agreement,
        "reference": reference,
        "independent": independent,
    }


def main() -> None:
    result = json.loads((ROLE7 / "independent_results.json").read_text(encoding="utf-8"))

    r2 = result["R2-REQ-001"]
    r2_source = both(r2["first_counterexample"])
    r2_deletions = [both(permutation) for permutation in r2["deletion_results"]]

    r3_permutation = result["R3-C2"]["minimum_counterexample"]
    r3_source = both(r3_permutation)
    r3_swaps = []
    for left in range(len(r3_permutation)):
        for right in range(left + 1, len(r3_permutation)):
            swapped = r3_permutation.copy()
            swapped[left], swapped[right] = swapped[right], swapped[left]
            audit = both(swapped)
            audit["transposition_1_based"] = [left + 1, right + 1]
            r3_swaps.append(audit)

    gf32_failure = both(result["R1-G0-GF32-INDEPENDENT-001"]["best_example"]["extension"])
    r4_failure = both(result["R7-ROLE4-TWO-001"]["best_example"]["extension"])

    document = {
        "marker": "COSTAS_ROLE7_SUPPLIED_VERIFIER_CROSSCHECK_V1",
        "purpose": "post-search cross-check only; not the primary exhaustive-search logic",
        "R2-REQ-001": {
            "source": r2_source,
            "deletions": r2_deletions,
            "all_agree": r2_source["agreement"] and all(item["agreement"] for item in r2_deletions),
            "source_is_costas": r2_source["reference"]["is_costas"],
            "all_deletions_non_costas": all(not item["reference"]["is_costas"] for item in r2_deletions),
        },
        "R3-C2": {
            "source": r3_source,
            "transpositions": r3_swaps,
            "all_agree": r3_source["agreement"] and all(item["agreement"] for item in r3_swaps),
            "source_exactly_one_duplicate_vector_with_multiplicity_two": (
                r3_source["reference"]["duplicate_vector_count"] == 1
                and r3_source["reference"]["duplicate_vectors"][0]["multiplicity"] == 2
            ),
            "all_15_transpositions_non_costas": len(r3_swaps) == 15
            and all(not item["reference"]["is_costas"] for item in r3_swaps),
        },
        "R1-G0-GF32-INDEPENDENT-001_representative_failure": gf32_failure,
        "R7-ROLE4-TWO-001_representative_failure": r4_failure,
        "global_agreement": (
            r2_source["agreement"]
            and all(item["agreement"] for item in r2_deletions)
            and r3_source["agreement"]
            and all(item["agreement"] for item in r3_swaps)
            and gf32_failure["agreement"]
            and r4_failure["agreement"]
        ),
    }
    (ROLE7 / "counterexample_crosschecks.json").write_text(
        json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "output": str(ROLE7 / "counterexample_crosschecks.json"),
                "global_agreement": document["global_agreement"],
                "r2_all_deletions_non_costas": document["R2-REQ-001"]["all_deletions_non_costas"],
                "r3_all_15_transpositions_non_costas": document["R3-C2"]["all_15_transpositions_non_costas"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
