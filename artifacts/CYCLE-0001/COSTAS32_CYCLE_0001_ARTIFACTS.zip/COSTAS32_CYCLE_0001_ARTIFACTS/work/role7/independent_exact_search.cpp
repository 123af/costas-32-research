#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_set>
#include <utility>
#include <vector>

using Clock = std::chrono::steady_clock;

static std::string vector_json(const std::vector<int>& values) {
    std::ostringstream out;
    out << '[';
    for (std::size_t i = 0; i < values.size(); ++i) {
        if (i) out << ',';
        out << values[i];
    }
    out << ']';
    return out.str();
}

static std::string map_json(const std::map<int, std::uint64_t>& values) {
    std::ostringstream out;
    out << '{';
    bool first = true;
    for (const auto& [key, value] : values) {
        if (!first) out << ',';
        first = false;
        out << '"' << key << "\":" << value;
    }
    out << '}';
    return out.str();
}

static std::string encode_permutation(const std::vector<int>& p) {
    std::string result;
    result.reserve(p.size());
    for (int value : p) result.push_back(static_cast<char>(value));
    return result;
}

struct DisplacementStats {
    bool is_costas = false;
    int duplicate_vector_count = 0;
    int duplicate_occurrence_excess = 0;
    int first_duplicate_dx = 0;
    std::vector<std::array<int, 3>> duplicate_vectors;  // dx, dy, multiplicity
};

// Independent primary checker: enumerate unordered point pairs and place each
// signed displacement in a fixed coordinate-indexed array.  It does not use
// difference-triangle rows or either supplied verifier.
static DisplacementStats displacement_stats(const std::vector<int>& p) {
    const int n = static_cast<int>(p.size());
    constexpr int stride = 65;
    std::array<std::uint8_t, 33 * stride> counts{};
    for (int left = 0; left < n; ++left) {
        for (int right = left + 1; right < n; ++right) {
            const int dx = right - left;
            const int dy = p[right] - p[left];
            ++counts[dx * stride + (dy + 32)];
        }
    }

    DisplacementStats result;
    for (int dx = 1; dx < n; ++dx) {
        for (int dy = -(n - 1); dy <= n - 1; ++dy) {
            const int count = counts[dx * stride + (dy + 32)];
            if (count > 1) {
                if (result.first_duplicate_dx == 0) result.first_duplicate_dx = dx;
                ++result.duplicate_vector_count;
                result.duplicate_occurrence_excess += count - 1;
                result.duplicate_vectors.push_back({dx, dy, count});
            }
        }
    }
    result.is_costas = result.duplicate_vector_count == 0;
    return result;
}

class FastPointPairChecker {
  public:
    bool is_costas(const std::vector<int>& p) {
        ++generation_;
        if (generation_ == 0) {
            seen_.fill(0);
            generation_ = 1;
        }
        const int n = static_cast<int>(p.size());
        for (int left = 0; left < n; ++left) {
            for (int right = left + 1; right < n; ++right) {
                const int key = (right - left) * 65 + (p[right] - p[left] + 32);
                if (seen_[key] == generation_) return false;
                seen_[key] = generation_;
            }
        }
        return true;
    }

  private:
    std::array<std::uint32_t, 33 * 65> seen_{};
    std::uint32_t generation_ = 0;
};

static bool is_permutation_1_based(const std::vector<int>& p) {
    std::vector<int> sorted = p;
    std::sort(sorted.begin(), sorted.end());
    for (int i = 0; i < static_cast<int>(sorted.size()); ++i) {
        if (sorted[i] != i + 1) return false;
    }
    return !p.empty();
}

static std::vector<int> inverse_permutation(const std::vector<int>& p) {
    std::vector<int> inverse(p.size());
    for (int i = 0; i < static_cast<int>(p.size()); ++i) inverse[p[i] - 1] = i + 1;
    return inverse;
}

static std::vector<int> d4_canonical(const std::vector<int>& p) {
    const int n = static_cast<int>(p.size());
    std::vector<std::vector<int>> images;
    images.push_back(p);
    std::vector<int> vertical = p;
    for (int& value : vertical) value = n + 1 - value;
    images.push_back(vertical);
    std::vector<int> horizontal(p.rbegin(), p.rend());
    images.push_back(horizontal);
    std::vector<int> both(horizontal);
    for (int& value : both) value = n + 1 - value;
    images.push_back(both);
    const int original_count = static_cast<int>(images.size());
    for (int i = 0; i < original_count; ++i) images.push_back(inverse_permutation(images[i]));
    return *std::min_element(images.begin(), images.end());
}

static std::vector<int> delete_point(const std::vector<int>& p, int column_zero_based) {
    const int removed_value = p[column_zero_based];
    std::vector<int> result;
    result.reserve(p.size() - 1);
    for (int i = 0; i < static_cast<int>(p.size()); ++i) {
        if (i == column_zero_based) continue;
        result.push_back(p[i] - (p[i] > removed_value ? 1 : 0));
    }
    return result;
}

struct R2OrderResult {
    int n = 0;
    std::uint64_t permutations_scanned = 0;
    std::uint64_t costas_count = 0;
    std::uint64_t no_deletable_count = 0;
    std::uint64_t no_deletable_d4_classes = 0;
};

struct R2Result {
    double seconds = 0;
    std::vector<R2OrderResult> orders;
    std::vector<int> first_counterexample;
    std::vector<int> canonical_counterexample;
    std::vector<std::vector<int>> deletion_results;
};

static R2Result run_r2_deletion() {
    const auto start = Clock::now();
    R2Result result;
    FastPointPairChecker checker;

    for (int n = 2; n <= 7; ++n) {
        R2OrderResult row;
        row.n = n;
        std::vector<int> p(n);
        for (int i = 0; i < n; ++i) p[i] = i + 1;
        std::set<std::string> bad_classes;
        do {
            ++row.permutations_scanned;
            if (!checker.is_costas(p)) continue;
            ++row.costas_count;
            bool has_deletable = false;
            std::vector<std::vector<int>> deletions;
            for (int k = 0; k < n; ++k) {
                std::vector<int> reduced = delete_point(p, k);
                deletions.push_back(reduced);
                if (checker.is_costas(reduced)) has_deletable = true;
            }
            if (!has_deletable) {
                ++row.no_deletable_count;
                const auto canonical = d4_canonical(p);
                bad_classes.insert(encode_permutation(canonical));
                if (result.first_counterexample.empty()) {
                    result.first_counterexample = p;
                    result.canonical_counterexample = canonical;
                    result.deletion_results = deletions;
                }
            }
        } while (std::next_permutation(p.begin(), p.end()));
        row.no_deletable_d4_classes = bad_classes.size();
        result.orders.push_back(row);
    }
    result.seconds = std::chrono::duration<double>(Clock::now() - start).count();
    return result;
}

struct OneCollisionInfo {
    bool exactly_one = false;
    int dx = 0;
    int dy = 0;
    std::vector<std::pair<int, int>> realizing_pairs;
};

static OneCollisionInfo one_collision_info(const std::vector<int>& p) {
    const int n = static_cast<int>(p.size());
    constexpr int stride = 65;
    std::array<std::uint8_t, 33 * stride> counts{};
    std::array<std::array<std::pair<std::uint8_t, std::uint8_t>, 3>, 33 * stride> pairs{};
    for (int left = 0; left < n; ++left) {
        for (int right = left + 1; right < n; ++right) {
            const int key = (right - left) * stride + (p[right] - p[left] + 32);
            if (counts[key] < 3) pairs[key][counts[key]] = {static_cast<std::uint8_t>(left), static_cast<std::uint8_t>(right)};
            if (counts[key] < 255) ++counts[key];
        }
    }
    int duplicate_keys = 0;
    int duplicate_key = -1;
    for (int dx = 1; dx < n; ++dx) {
        for (int dy = -(n - 1); dy <= n - 1; ++dy) {
            const int key = dx * stride + (dy + 32);
            if (counts[key] > 1) {
                ++duplicate_keys;
                duplicate_key = key;
                if (counts[key] != 2) return {};
            }
        }
    }
    if (duplicate_keys != 1) return {};
    OneCollisionInfo result;
    result.exactly_one = true;
    result.dx = duplicate_key / stride;
    result.dy = duplicate_key % stride - 32;
    for (int i = 0; i < 2; ++i) {
        result.realizing_pairs.emplace_back(pairs[duplicate_key][i].first, pairs[duplicate_key][i].second);
    }
    return result;
}

struct R3OrderResult {
    int n = 0;
    std::uint64_t permutations_scanned = 0;
    std::uint64_t one_collision = 0;
    std::uint64_t repairable = 0;
    std::uint64_t unrepairable = 0;
    std::uint64_t repair_transpositions = 0;
    std::uint64_t transpositions_checked = 0;
    std::uint64_t three_term_structure_violations = 0;
};

struct R3Result {
    double seconds = 0;
    std::vector<R3OrderResult> orders;
    std::vector<int> minimum_counterexample;
    std::vector<std::array<int, 3>> minimum_counterexample_duplicates;
};

static bool is_three_term_collision(const OneCollisionInfo& info) {
    const auto [a, b] = info.realizing_pairs[0];
    const auto [c, d] = info.realizing_pairs[1];
    return (b == c && b - a == d - c) || (d == a && d - c == b - a);
}

static R3Result run_r3_transposition() {
    const auto start = Clock::now();
    R3Result result;
    FastPointPairChecker checker;
    for (int n = 1; n <= 10; ++n) {
        R3OrderResult row;
        row.n = n;
        std::vector<int> p(n);
        for (int i = 0; i < n; ++i) p[i] = i + 1;
        do {
            ++row.permutations_scanned;
            const OneCollisionInfo collision = one_collision_info(p);
            if (!collision.exactly_one) continue;
            ++row.one_collision;
            if (!is_three_term_collision(collision)) ++row.three_term_structure_violations;
            std::uint64_t repairs = 0;
            for (int a = 0; a < n; ++a) {
                for (int b = a + 1; b < n; ++b) {
                    ++row.transpositions_checked;
                    std::swap(p[a], p[b]);
                    if (checker.is_costas(p)) ++repairs;
                    std::swap(p[a], p[b]);
                }
            }
            row.repair_transpositions += repairs;
            if (repairs) {
                ++row.repairable;
            } else {
                ++row.unrepairable;
                if (result.minimum_counterexample.empty()) {
                    result.minimum_counterexample = p;
                    const DisplacementStats stats = displacement_stats(p);
                    result.minimum_counterexample_duplicates = stats.duplicate_vectors;
                }
            }
        } while (std::next_permutation(p.begin(), p.end()));
        result.orders.push_back(row);
    }
    result.seconds = std::chrono::duration<double>(Clock::now() - start).count();
    return result;
}

// Alternative GF(32) model: polynomial basis modulo
// x^5 + x^4 + x^2 + x + 1 (0b110111), not x^5 + x^2 + 1.
constexpr std::uint32_t GF32_MODULUS = 0b110111;

static int gf32_multiply(int a, int b) {
    std::uint32_t product = 0;
    for (int bit = 0; bit < 5; ++bit) {
        if ((b >> bit) & 1) product ^= static_cast<std::uint32_t>(a) << bit;
    }
    for (int degree = 8; degree >= 5; --degree) {
        if ((product >> degree) & 1U) product ^= GF32_MODULUS << (degree - 5);
    }
    return static_cast<int>(product & 31U);
}

static int gf32_power(int base, int exponent) {
    int result = 1;
    while (exponent) {
        if (exponent & 1) result = gf32_multiply(result, base);
        base = gf32_multiply(base, base);
        exponent >>= 1;
    }
    return result;
}

static bool gf32_model_is_field() {
    for (int a = 1; a < 32; ++a) {
        if (gf32_power(a, 31) != 1) return false;
        bool has_inverse = false;
        for (int b = 1; b < 32; ++b) {
            if (gf32_multiply(a, b) == 1) has_inverse = true;
            if (gf32_multiply(a, b) == 0) return false;
        }
        if (!has_inverse) return false;
    }
    return true;
}

static std::vector<int> gf32_primitive_elements() {
    std::vector<int> result;
    for (int a = 2; a < 32; ++a) {
        std::array<bool, 32> seen{};
        int current = 1;
        bool okay = true;
        for (int exponent = 1; exponent <= 31; ++exponent) {
            current = gf32_multiply(current, a);
            if (seen[current]) okay = false;
            seen[current] = true;
        }
        if (okay && current == 1 && std::count(seen.begin() + 1, seen.end(), true) == 31) result.push_back(a);
    }
    return result;
}

static std::vector<int> g2_permutation(int alpha, int beta) {
    std::array<int, 32> alpha_log{};
    int current = 1;
    for (int exponent = 1; exponent <= 30; ++exponent) {
        current = gf32_multiply(current, alpha);
        alpha_log[current] = exponent;
    }
    std::vector<int> p;
    p.reserve(30);
    current = 1;
    for (int i = 1; i <= 30; ++i) {
        current = gf32_multiply(current, beta);
        const int target = 1 ^ current;
        const int exponent = alpha_log[target];
        if (target == 0 || exponent == 0) throw std::runtime_error("G2 logarithm lookup failed");
        p.push_back(exponent);
    }
    return p;
}

struct R1Gf32Result {
    double seconds = 0;
    bool field_model_valid = false;
    std::vector<int> primitive_elements;
    std::uint64_t primitive_pairs = 0;
    std::uint64_t base_invalid = 0;
    std::uint64_t distinct_bases = 0;
    std::uint64_t extensions = 0;
    std::uint64_t passing_extensions = 0;
    std::map<int, std::uint64_t> excess_histogram;
    std::map<int, std::uint64_t> first_duplicate_dx_histogram;
    int best_alpha = 0;
    int best_beta = 0;
    int best_orientation = 0;
    int minimum_excess = 0;
    int minimum_duplicate_vectors = 0;
    std::vector<int> best_base;
    std::vector<int> best_extension;
};

static R1Gf32Result run_r1_gf32() {
    const auto start = Clock::now();
    R1Gf32Result result;
    result.field_model_valid = gf32_model_is_field();
    result.primitive_elements = gf32_primitive_elements();
    if (!result.field_model_valid || result.primitive_elements.size() != 30) {
        throw std::runtime_error("alternative GF(32) representation validation failed");
    }
    std::unordered_set<std::string> distinct_bases;
    bool have_best = false;
    FastPointPairChecker checker;
    for (int alpha : result.primitive_elements) {
        for (int beta : result.primitive_elements) {
            ++result.primitive_pairs;
            const std::vector<int> base = g2_permutation(alpha, beta);
            if (!is_permutation_1_based(base) || !checker.is_costas(base)) ++result.base_invalid;
            distinct_bases.insert(encode_permutation(base));
            for (int orientation = 0; orientation < 2; ++orientation) {
                std::vector<int> extension;
                extension.reserve(32);
                extension.push_back(orientation == 0 ? 1 : 32);
                for (int value : base) extension.push_back(value + 1);
                extension.push_back(orientation == 0 ? 32 : 1);
                ++result.extensions;
                const DisplacementStats stats = displacement_stats(extension);
                if (stats.is_costas) ++result.passing_extensions;
                ++result.excess_histogram[stats.duplicate_occurrence_excess];
                ++result.first_duplicate_dx_histogram[stats.first_duplicate_dx];
                const bool better = !have_best ||
                    stats.duplicate_occurrence_excess < result.minimum_excess ||
                    (stats.duplicate_occurrence_excess == result.minimum_excess &&
                     (stats.duplicate_vector_count < result.minimum_duplicate_vectors ||
                      (stats.duplicate_vector_count == result.minimum_duplicate_vectors && extension < result.best_extension)));
                if (better) {
                    have_best = true;
                    result.minimum_excess = stats.duplicate_occurrence_excess;
                    result.minimum_duplicate_vectors = stats.duplicate_vector_count;
                    result.best_alpha = alpha;
                    result.best_beta = beta;
                    result.best_orientation = orientation;
                    result.best_base = base;
                    result.best_extension = extension;
                }
            }
        }
    }
    result.distinct_bases = distinct_bases.size();
    result.seconds = std::chrono::duration<double>(Clock::now() - start).count();
    return result;
}

struct CombinationPair {
    int first;
    int second;
    std::array<int, 30> complement;
};

static std::vector<CombinationPair> two_subsets_32() {
    std::vector<CombinationPair> result;
    result.reserve(496);
    for (int a = 1; a <= 32; ++a) {
        for (int b = a + 1; b <= 32; ++b) {
            CombinationPair item{a, b, {}};
            int index = 0;
            for (int value = 1; value <= 32; ++value) {
                if (value != a && value != b) item.complement[index++] = value;
            }
            if (index != 30) throw std::runtime_error("bad complement");
            result.push_back(item);
        }
    }
    return result;
}

struct R4Result {
    double seconds = 0;
    std::uint64_t column_subsets = 0;
    std::uint64_t row_subsets = 0;
    std::uint64_t bijections_per_pair = 2;
    std::uint64_t parameter_tuples = 0;
    std::uint64_t permutation_failures = 0;
    std::uint64_t recovery_audit_failures = 0;
    std::uint64_t passing_extensions = 0;
    std::map<int, std::uint64_t> excess_histogram;
    int minimum_excess = 0;
    int minimum_duplicate_vectors = 0;
    int best_a1 = 0;
    int best_a2 = 0;
    int best_b1 = 0;
    int best_b2 = 0;
    int best_matching = 0;
    std::vector<int> best_extension;
};

static R4Result run_r4_two_point() {
    const auto start = Clock::now();
    const std::vector<int> source = {1,3,9,27,19,26,16,17,20,29,25,13,8,24,10,30,28,22,4,12,5,15,14,11,2,6,18,23,7,21};
    if (!is_permutation_1_based(source) || !displacement_stats(source).is_costas) {
        throw std::runtime_error("KA-014 source is invalid");
    }
    const auto pairs = two_subsets_32();
    R4Result result;
    result.column_subsets = pairs.size();
    result.row_subsets = pairs.size();
    bool have_best = false;
    for (const auto& columns : pairs) {
        for (const auto& rows : pairs) {
            for (int matching = 0; matching < 2; ++matching) {
                ++result.parameter_tuples;
                std::vector<int> extension(32, 0);
                for (int i = 0; i < 30; ++i) {
                    const int x = columns.complement[i];
                    const int y = rows.complement[source[i] - 1];
                    extension[x - 1] = y;
                }
                extension[columns.first - 1] = matching == 0 ? rows.first : rows.second;
                extension[columns.second - 1] = matching == 0 ? rows.second : rows.first;
                if (!is_permutation_1_based(extension)) ++result.permutation_failures;

                // Audit the claimed domain parameterization by deleting the two
                // designated new columns/rows and recompressing back to source.
                std::vector<int> recovered;
                recovered.reserve(30);
                for (int x = 1; x <= 32; ++x) {
                    if (x == columns.first || x == columns.second) continue;
                    const int y = extension[x - 1];
                    const int compressed = y - (y > rows.first ? 1 : 0) - (y > rows.second ? 1 : 0);
                    recovered.push_back(compressed);
                }
                if (recovered != source) ++result.recovery_audit_failures;

                const DisplacementStats stats = displacement_stats(extension);
                if (stats.is_costas) ++result.passing_extensions;
                ++result.excess_histogram[stats.duplicate_occurrence_excess];
                const bool better = !have_best ||
                    stats.duplicate_occurrence_excess < result.minimum_excess ||
                    (stats.duplicate_occurrence_excess == result.minimum_excess &&
                     (stats.duplicate_vector_count < result.minimum_duplicate_vectors ||
                      (stats.duplicate_vector_count == result.minimum_duplicate_vectors && extension < result.best_extension)));
                if (better) {
                    have_best = true;
                    result.minimum_excess = stats.duplicate_occurrence_excess;
                    result.minimum_duplicate_vectors = stats.duplicate_vector_count;
                    result.best_a1 = columns.first;
                    result.best_a2 = columns.second;
                    result.best_b1 = rows.first;
                    result.best_b2 = rows.second;
                    result.best_matching = matching;
                    result.best_extension = extension;
                }
            }
        }
    }
    result.seconds = std::chrono::duration<double>(Clock::now() - start).count();
    return result;
}

static std::vector<int> primitive_roots_mod_37() {
    std::vector<int> roots;
    auto mod_pow = [](int base, int exponent) {
        int result = 1;
        while (exponent) {
            if (exponent & 1) result = result * base % 37;
            base = base * base % 37;
            exponent >>= 1;
        }
        return result;
    };
    for (int g = 2; g < 37; ++g) {
        if (mod_pow(g, 18) != 1 && mod_pow(g, 12) != 1) roots.push_back(g);
    }
    return roots;
}

struct W1CropResult {
    double seconds = 0;
    std::vector<int> primitive_roots;
    std::uint64_t tuples = 0;
    std::uint64_t passing_crops = 0;
    int maximum_overlap = 0;
    std::map<int, std::uint64_t> overlap_histogram;
    int best_g = 0;
    int best_c = 0;
    int best_a = 0;
    int best_b = 0;
    std::vector<int> best_retained_values;
};

static W1CropResult run_w1_crop() {
    const auto start = Clock::now();
    W1CropResult result;
    result.primitive_roots = primitive_roots_mod_37();
    for (int g : result.primitive_roots) {
        for (int c = 0; c <= 35; ++c) {
            std::vector<int> welch(36);
            int current = 1;
            for (int i = 0; i < c; ++i) current = current * g % 37;
            for (int i = 0; i < 36; ++i) {
                welch[i] = current;
                current = current * g % 37;
            }
            for (int a = 0; a <= 4; ++a) {
                std::vector<int> retained(welch.begin() + a, welch.begin() + a + 32);
                for (int b = 0; b <= 4; ++b) {
                    ++result.tuples;
                    int overlap = 0;
                    for (int value : retained) {
                        if (value >= b + 1 && value <= b + 32) ++overlap;
                    }
                    ++result.overlap_histogram[overlap];
                    if (overlap == 32) ++result.passing_crops;
                    if (overlap > result.maximum_overlap) {
                        result.maximum_overlap = overlap;
                        result.best_g = g;
                        result.best_c = c;
                        result.best_a = a;
                        result.best_b = b;
                        result.best_retained_values = retained;
                    }
                }
            }
        }
    }
    result.seconds = std::chrono::duration<double>(Clock::now() - start).count();
    return result;
}

static void write_results(const std::string& path,
                          const R1Gf32Result& gf,
                          const R4Result& r4,
                          const R2Result& r2,
                          const R3Result& r3,
                          const W1CropResult& crop,
                          double total_seconds) {
    std::ofstream out(path);
    if (!out) throw std::runtime_error("cannot open output file");
    out << std::fixed << std::setprecision(9);
    out << "{\n";
    out << "  \"marker\": \"COSTAS_ROLE7_INDEPENDENT_EXACT_SEARCH_V1\",\n";
    out << "  \"primary_algorithm\": \"unordered point-pair signed displacement occupancy\",\n";
    out << "  \"indexing\": \"1-based externally, 0-based internal arrays\",\n";
    out << "  \"total_seconds\": " << total_seconds << ",\n";

    out << "  \"R1-G0-GF32-INDEPENDENT-001\": {\n";
    out << "    \"status\": \"exhausted_in_domain\",\n";
    out << "    \"seconds\": " << gf.seconds << ",\n";
    out << "    \"gf_representation\": \"GF(2)[x]/(x^5+x^4+x^2+x+1)\",\n";
    out << "    \"gf_modulus_bits_decimal\": " << GF32_MODULUS << ",\n";
    out << "    \"multiplication\": \"carryless coefficient convolution followed by polynomial long division\",\n";
    out << "    \"field_model_valid\": " << (gf.field_model_valid ? "true" : "false") << ",\n";
    out << "    \"primitive_elements\": " << vector_json(gf.primitive_elements) << ",\n";
    out << "    \"primitive_pairs\": " << gf.primitive_pairs << ",\n";
    out << "    \"base_invalid\": " << gf.base_invalid << ",\n";
    out << "    \"distinct_g2_base_permutations\": " << gf.distinct_bases << ",\n";
    out << "    \"extensions_checked\": " << gf.extensions << ",\n";
    out << "    \"passing_extensions\": " << gf.passing_extensions << ",\n";
    out << "    \"duplicate_occurrence_excess_histogram\": " << map_json(gf.excess_histogram) << ",\n";
    out << "    \"first_duplicate_dx_histogram\": " << map_json(gf.first_duplicate_dx_histogram) << ",\n";
    out << "    \"minimum_excess\": " << gf.minimum_excess << ",\n";
    out << "    \"minimum_duplicate_vectors\": " << gf.minimum_duplicate_vectors << ",\n";
    out << "    \"best_example\": {\"alpha\":" << gf.best_alpha << ",\"beta\":" << gf.best_beta
        << ",\"orientation\":\"" << (gf.best_orientation == 0 ? "ascending" : "descending")
        << "\",\"base\":" << vector_json(gf.best_base) << ",\"extension\":" << vector_json(gf.best_extension) << "},\n";
    out << "    \"unsearched_scope\": \"All order-32 permutations outside the two standard diagonal-corner extensions of GF(32) G2 bases.\"\n";
    out << "  },\n";

    out << "  \"R7-ROLE4-TWO-001\": {\n";
    out << "    \"claim_alias\": \"R4-C2\",\n";
    out << "    \"status\": \"exhausted_in_domain\",\n";
    out << "    \"seconds\": " << r4.seconds << ",\n";
    out << "    \"source_id\": \"KA-014-N30-W1-P31-G3-C0\",\n";
    out << "    \"column_subsets\": " << r4.column_subsets << ",\n";
    out << "    \"row_subsets\": " << r4.row_subsets << ",\n";
    out << "    \"bijections_per_subset_pair\": " << r4.bijections_per_pair << ",\n";
    out << "    \"parameter_tuples\": " << r4.parameter_tuples << ",\n";
    out << "    \"permutation_failures\": " << r4.permutation_failures << ",\n";
    out << "    \"recovery_audit_failures\": " << r4.recovery_audit_failures << ",\n";
    out << "    \"passing_extensions\": " << r4.passing_extensions << ",\n";
    out << "    \"duplicate_occurrence_excess_histogram\": " << map_json(r4.excess_histogram) << ",\n";
    out << "    \"minimum_excess\": " << r4.minimum_excess << ",\n";
    out << "    \"minimum_duplicate_vectors\": " << r4.minimum_duplicate_vectors << ",\n";
    out << "    \"best_example\": {\"A\":[" << r4.best_a1 << ',' << r4.best_a2 << "],\"B\":[" << r4.best_b1 << ',' << r4.best_b2
        << "],\"matching\":\"" << (r4.best_matching == 0 ? "parallel" : "cross") << "\",\"extension\":" << vector_json(r4.best_extension) << "},\n";
    out << "    \"unsearched_scope\": \"Two-point insertions from any order-30 base other than KA-014, or transformations that change the old-point relative orders.\"\n";
    out << "  },\n";

    out << "  \"R2-REQ-001\": {\n";
    out << "    \"status\": \"counterexample_found\",\n";
    out << "    \"lower_orders_status\": \"exhausted_in_domain\",\n";
    out << "    \"seconds\": " << r2.seconds << ",\n";
    out << "    \"orders\": [\n";
    for (std::size_t i = 0; i < r2.orders.size(); ++i) {
        const auto& row = r2.orders[i];
        out << "      {\"n\":" << row.n << ",\"permutations_scanned\":" << row.permutations_scanned
            << ",\"costas_count\":" << row.costas_count << ",\"no_deletable_count\":" << row.no_deletable_count
            << ",\"no_deletable_d4_classes\":" << row.no_deletable_d4_classes << '}';
        out << (i + 1 == r2.orders.size() ? "\n" : ",\n");
    }
    out << "    ],\n";
    out << "    \"first_counterexample\": " << vector_json(r2.first_counterexample) << ",\n";
    out << "    \"canonical_counterexample\": " << vector_json(r2.canonical_counterexample) << ",\n";
    out << "    \"deletion_results\": [";
    for (std::size_t i = 0; i < r2.deletion_results.size(); ++i) {
        if (i) out << ',';
        out << vector_json(r2.deletion_results[i]);
    }
    out << "],\n";
    out << "    \"unsearched_scope\": \"Orders above 7 for minimum-order determination; their behavior is irrelevant once an order-7 counterexample and complete lower-order exhaustion are established.\"\n";
    out << "  },\n";

    out << "  \"R3-C2\": {\n";
    out << "    \"request_alias\": \"role3 one-collision transposition classification\",\n";
    out << "    \"status\": \"counterexample_found\",\n";
    out << "    \"complete_domain_status\": \"exhausted_in_domain\",\n";
    out << "    \"seconds\": " << r3.seconds << ",\n";
    out << "    \"orders\": [\n";
    for (std::size_t i = 0; i < r3.orders.size(); ++i) {
        const auto& row = r3.orders[i];
        out << "      {\"n\":" << row.n << ",\"permutations_scanned\":" << row.permutations_scanned
            << ",\"one_collision\":" << row.one_collision << ",\"repairable\":" << row.repairable
            << ",\"unrepairable\":" << row.unrepairable << ",\"repair_transpositions\":" << row.repair_transpositions
            << ",\"transpositions_checked\":" << row.transpositions_checked
            << ",\"three_term_structure_violations\":" << row.three_term_structure_violations << '}';
        out << (i + 1 == r3.orders.size() ? "\n" : ",\n");
    }
    out << "    ],\n";
    out << "    \"minimum_counterexample\": " << vector_json(r3.minimum_counterexample) << ",\n";
    out << "    \"minimum_counterexample_duplicate_vectors\": [";
    for (std::size_t i = 0; i < r3.minimum_counterexample_duplicates.size(); ++i) {
        if (i) out << ',';
        const auto& item = r3.minimum_counterexample_duplicates[i];
        out << '[' << item[0] << ',' << item[1] << ',' << item[2] << ']';
    }
    out << "],\n";
    out << "    \"unsearched_scope\": \"Orders above 10; no inference is made about their classification or guaranteed repairability.\"\n";
    out << "  },\n";

    out << "  \"R1-W1-P37-CROP-INDEPENDENT-002\": {\n";
    out << "    \"status\": \"exhausted_in_domain\",\n";
    out << "    \"seconds\": " << crop.seconds << ",\n";
    out << "    \"primitive_roots_mod_37\": " << vector_json(crop.primitive_roots) << ",\n";
    out << "    \"tuples\": " << crop.tuples << ",\n";
    out << "    \"passing_crops\": " << crop.passing_crops << ",\n";
    out << "    \"maximum_overlap\": " << crop.maximum_overlap << ",\n";
    out << "    \"overlap_histogram\": " << map_json(crop.overlap_histogram) << ",\n";
    out << "    \"first_best_example\": {\"g\":" << crop.best_g << ",\"c\":" << crop.best_c << ",\"a\":" << crop.best_a << ",\"b\":" << crop.best_b
        << ",\"retained_values\":" << vector_json(crop.best_retained_values) << "},\n";
    out << "    \"unsearched_scope\": \"Non-contiguous crops, internal compression, other source primes, and non-W1 families.\"\n";
    out << "  }\n";
    out << "}\n";
}

int main(int argc, char** argv) {
    try {
        std::string output = "work/role7/independent_results.json";
        if (argc == 3 && std::string(argv[1]) == "--output") output = argv[2];
        else if (argc != 1) {
            std::cerr << "usage: " << argv[0] << " [--output PATH]\n";
            return 2;
        }

        if (!displacement_stats({1, 3, 2}).is_costas || displacement_stats({1, 2, 3}).is_costas) {
            throw std::runtime_error("primary checker regression test failed");
        }
        const auto total_start = Clock::now();
        const R1Gf32Result gf = run_r1_gf32();
        const R4Result r4 = run_r4_two_point();
        const R2Result r2 = run_r2_deletion();
        const R3Result r3 = run_r3_transposition();
        const W1CropResult crop = run_w1_crop();
        const double total_seconds = std::chrono::duration<double>(Clock::now() - total_start).count();
        write_results(output, gf, r4, r2, r3, crop, total_seconds);
        std::cout << "wrote " << output << "\n";
        std::cout << std::fixed << std::setprecision(6)
                  << "total_seconds=" << total_seconds
                  << " gf32_hits=" << gf.passing_extensions
                  << " r4_hits=" << r4.passing_extensions
                  << " r2_counterexample=" << vector_json(r2.first_counterexample)
                  << " r3_counterexample=" << vector_json(r3.minimum_counterexample)
                  << " crop_hits=" << crop.passing_crops << '\n';
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 1;
    }
}
