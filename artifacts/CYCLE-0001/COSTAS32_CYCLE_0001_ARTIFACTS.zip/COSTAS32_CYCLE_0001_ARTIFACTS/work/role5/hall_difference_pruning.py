#!/usr/bin/env python3
"""Exact experiments for a Hall-SDR pruning rule for Costas prefixes.

The search assigns a permutation from left to right.  The baseline check stores
the vertical differences already used at each horizontal distance.  The Hall
check additionally asks whether every still-open difference slot at each fixed
distance can receive a distinct integer difference from its current relaxed
domain.  The relaxation deliberately ignores coupling between slots, so a
failed matching is a safe pruning certificate while a successful matching is
not a completion certificate.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import time
from dataclasses import asdict, dataclass
from typing import Iterable

from independent_verifier import verify_permutation as verify_independent
from reference_verifier import verify_permutation as verify_reference


@dataclass
class SearchMetrics:
    order: int
    use_hall: bool
    nodes: int
    locally_consistent_children: int
    hall_checks: int
    hall_prunes: int
    solutions: int
    solution_sha256: str
    elapsed_seconds: float


def extend_used_differences(
    prefix: list[int], used: list[set[int]], value: int
) -> list[tuple[int, int]] | None:
    """Return newly inserted (distance,difference) entries, or None on collision."""
    new_index = len(prefix)
    inserted: list[tuple[int, int]] = []
    for old_index, old_value in enumerate(prefix):
        distance = new_index - old_index
        difference = value - old_value
        if difference in used[distance]:
            return None
        inserted.append((distance, difference))
    return inserted


def _difference_domain(
    left: int,
    right: int,
    prefix: tuple[int, ...],
    remaining: tuple[int, ...],
    forbidden: set[int],
) -> set[int]:
    left_values: Iterable[int] = (prefix[left],) if left < len(prefix) else remaining
    right_values: Iterable[int] = (
        (prefix[right],) if right < len(prefix) else remaining
    )
    domain: set[int] = set()
    for a in left_values:
        for b in right_values:
            if a != b:
                difference = b - a
                if difference not in forbidden:
                    domain.add(difference)
    return domain


def _has_system_of_distinct_representatives(domains: list[set[int]]) -> bool:
    """Bipartite augmenting-path test; exact for the relaxed slot domains."""
    if not domains:
        return True
    ordered = sorted(domains, key=lambda domain: (len(domain), tuple(sorted(domain))))
    owner: dict[int, int] = {}

    def augment(slot: int, seen: set[int]) -> bool:
        for difference in sorted(ordered[slot]):
            if difference in seen:
                continue
            seen.add(difference)
            prior = owner.get(difference)
            if prior is None or augment(prior, seen):
                owner[difference] = slot
                return True
        return False

    return all(augment(slot, set()) for slot in range(len(ordered)))


def hall_feasible(prefix_list: list[int], order: int) -> tuple[bool, dict | None]:
    """Check every horizontal distance; return a failing-distance certificate."""
    prefix = tuple(prefix_list)
    assigned = set(prefix)
    remaining = tuple(value for value in range(1, order + 1) if value not in assigned)
    length = len(prefix)

    for distance in range(1, order):
        used: set[int] = set()
        for start in range(max(0, length - distance)):
            difference = prefix[start + distance] - prefix[start]
            if difference in used:
                return False, {
                    "kind": "already_realized_collision",
                    "distance": distance,
                    "difference": difference,
                }
            used.add(difference)

        domains: list[set[int]] = []
        slots: list[tuple[int, int]] = []
        for start in range(order - distance):
            end = start + distance
            if end < length:  # This realized slot is represented in `used`.
                continue
            domain = _difference_domain(start, end, prefix, remaining, used)
            slots.append((start + 1, end + 1))
            domains.append(domain)

        if not _has_system_of_distinct_representatives(domains):
            return False, {
                "kind": "no_difference_sdr",
                "distance": distance,
                "used_differences": sorted(used),
                "open_slots": [list(slot) for slot in slots],
                "domains": [sorted(domain) for domain in domains],
                "maximum_matching_size": maximum_matching_size(domains),
                "required_matching_size": len(domains),
            }
    return True, None


def maximum_matching_size(domains: list[set[int]]) -> int:
    ordered = sorted(domains, key=lambda domain: (len(domain), tuple(sorted(domain))))
    owner: dict[int, int] = {}

    def augment(slot: int, seen: set[int]) -> bool:
        for difference in sorted(ordered[slot]):
            if difference in seen:
                continue
            seen.add(difference)
            prior = owner.get(difference)
            if prior is None or augment(prior, seen):
                owner[difference] = slot
                return True
        return False

    matched = 0
    for slot in range(len(ordered)):
        if augment(slot, set()):
            matched += 1
    return matched


def enumerate_costas(order: int, use_hall: bool) -> tuple[SearchMetrics, list[tuple[int, ...]]]:
    prefix: list[int] = []
    available = [True] * (order + 1)
    used_differences = [set() for _ in range(order)]
    solutions: list[tuple[int, ...]] = []
    nodes = 0
    locally_consistent_children = 0
    hall_checks = 0
    hall_prunes = 0
    started = time.perf_counter()

    def visit() -> None:
        nonlocal nodes, locally_consistent_children, hall_checks, hall_prunes
        nodes += 1
        if use_hall:
            hall_checks += 1
            feasible, _ = hall_feasible(prefix, order)
            if not feasible:
                hall_prunes += 1
                return
        if len(prefix) == order:
            solutions.append(tuple(prefix))
            return

        for value in range(1, order + 1):
            if not available[value]:
                continue
            inserted = extend_used_differences(prefix, used_differences, value)
            if inserted is None:
                continue
            locally_consistent_children += 1
            prefix.append(value)
            available[value] = False
            for distance, difference in inserted:
                used_differences[distance].add(difference)
            visit()
            for distance, difference in inserted:
                used_differences[distance].remove(difference)
            available[value] = True
            prefix.pop()

    visit()
    canonical = json.dumps(sorted(solutions), separators=(",", ":")).encode("utf-8")
    metrics = SearchMetrics(
        order=order,
        use_hall=use_hall,
        nodes=nodes,
        locally_consistent_children=locally_consistent_children,
        hall_checks=hall_checks,
        hall_prunes=hall_prunes,
        solutions=len(solutions),
        solution_sha256=hashlib.sha256(canonical).hexdigest(),
        elapsed_seconds=time.perf_counter() - started,
    )
    return metrics, solutions


def is_locally_costas(prefix: tuple[int, ...]) -> bool:
    for distance in range(1, len(prefix)):
        differences = [
            prefix[start + distance] - prefix[start]
            for start in range(len(prefix) - distance)
        ]
        if len(differences) != len(set(differences)):
            return False
    return True


def find_minimal_sufficiency_failure(max_order: int) -> dict | None:
    """Find the first Hall-feasible prefix with no Costas completion."""
    for order in range(1, max_order + 1):
        _, solutions = enumerate_costas(order, use_hall=False)
        live_prefixes = {
            solution[:length]
            for solution in solutions
            for length in range(order + 1)
        }
        for length in range(order):
            for prefix in itertools.permutations(range(1, order + 1), length):
                if not is_locally_costas(prefix):
                    continue
                feasible, _ = hall_feasible(list(prefix), order)
                if feasible and prefix not in live_prefixes:
                    return {
                        "minimality_order": "smallest order searched",
                        "minimality_prefix_length": "smallest length at that order",
                        "minimality_lexicographic": "first lexicographic prefix at that order and length",
                        "order": order,
                        "prefix": list(prefix),
                        "locally_costas": True,
                        "hall_feasible_at_every_distance": True,
                        "has_costas_completion": False,
                    }
    return None


def direct_bruteforce_counts(max_order: int) -> dict[str, int]:
    """Independent finite check through the public difference-triangle verifier."""
    counts: dict[str, int] = {}
    for order in range(1, max_order + 1):
        count = 0
        for permutation in itertools.permutations(range(1, order + 1)):
            if verify_independent(list(permutation))["is_costas"]:
                count += 1
        counts[str(order)] = count
    return counts


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-order", type=int, default=10)
    parser.add_argument("--bruteforce-max-order", type=int, default=8)
    parser.add_argument("--failure-max-order", type=int, default=8)
    args = parser.parse_args()

    all_metrics: list[dict] = []
    verifier_disagreements: list[dict] = []
    paired_solution_sets_equal = True
    for order in range(1, args.max_order + 1):
        baseline, baseline_solutions = enumerate_costas(order, use_hall=False)
        hall, hall_solutions = enumerate_costas(order, use_hall=True)
        paired_solution_sets_equal &= set(baseline_solutions) == set(hall_solutions)
        for solution in hall_solutions:
            reference = verify_reference(list(solution))
            independent = verify_independent(list(solution))
            if (
                not reference["is_costas"]
                or not independent["is_costas"]
                or reference["permutation_sha256"]
                != independent["permutation_sha256"]
            ):
                verifier_disagreements.append(
                    {"order": order, "permutation": list(solution)}
                )
        all_metrics.extend([asdict(baseline), asdict(hall)])

    report = {
        "marker": "COSTAS_ROLE5_HALL_EXPERIMENT_V1",
        "indexing": "1-based",
        "max_order": args.max_order,
        "bruteforce_max_order": args.bruteforce_max_order,
        "metrics": all_metrics,
        "paired_solution_sets_equal": paired_solution_sets_equal,
        "direct_bruteforce_counts": direct_bruteforce_counts(
            args.bruteforce_max_order
        ),
        "verifier_disagreements": verifier_disagreements,
        "minimal_sufficiency_failure": find_minimal_sufficiency_failure(
            args.failure_max_order
        ),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
