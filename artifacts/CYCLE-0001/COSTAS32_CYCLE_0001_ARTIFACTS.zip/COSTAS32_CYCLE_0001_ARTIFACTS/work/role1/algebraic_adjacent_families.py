#!/usr/bin/env python3
"""Exact finite checks for two algebraic routes adjacent to order 32.

Domains:
1. Every G2 parameter pair over GF(32), followed by either diagonal
   two-corner extension from order 30 to order 32.
2. Every W1(p=37) parameter pair (primitive root, shift), followed by every
   boundary-only 32x32 contiguous crop of its 36x36 permutation square.

The uploaded verifier modules are loaded by path and are not modified.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path
from types import ModuleType
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
UPLOAD = ROOT / "upload"
REFERENCE_PATH = UPLOAD / "reference_verifier(1).py"
INDEPENDENT_PATH = UPLOAD / "independent_verifier(1).py"


def load_module(name: str, path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


REFERENCE = load_module("costas_reference_uploaded", REFERENCE_PATH)
INDEPENDENT = load_module("costas_independent_uploaded", INDEPENDENT_PATH)


def compact_hash(value: Any) -> str:
    payload = json.dumps(value, separators=(",", ":"), sort_keys=True).encode()
    return hashlib.sha256(payload).hexdigest()


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def collision_key(report: dict[str, Any]) -> list[tuple[Any, ...]]:
    normalized = []
    for item in report["duplicate_vectors"]:
        pairs = tuple(
            sorted(tuple(tuple(point) for point in pair) for pair in item["point_pairs"])
        )
        normalized.append((tuple(item["vector"]), item["multiplicity"], pairs))
    return sorted(normalized)


def cross_verify(permutation: list[int]) -> tuple[dict[str, Any], dict[str, Any]]:
    reference = REFERENCE.verify_permutation(permutation)
    independent = INDEPENDENT.verify_permutation(permutation)
    comparable = (
        "order",
        "valid_input",
        "is_permutation",
        "is_costas",
        "error_code",
        "duplicate_vector_count",
        "duplicate_pair_occurrence_excess",
        "permutation_sha256",
    )
    for field in comparable:
        if reference[field] != independent[field]:
            raise AssertionError((field, reference[field], independent[field]))
    if collision_key(reference) != collision_key(independent):
        raise AssertionError("verifier collision reports disagree")
    return reference, independent


# GF(32) represented in the polynomial basis modulo x^5+x^2+1 (0b100101).
GF32_MODULUS = 0b100101


def gf32_mul(a: int, b: int) -> int:
    result = 0
    while b:
        if b & 1:
            result ^= a
        b >>= 1
        a <<= 1
        if a & 0b100000:
            a ^= GF32_MODULUS
    return result


def gf32_pow(a: int, exponent: int) -> int:
    result = 1
    while exponent:
        if exponent & 1:
            result = gf32_mul(result, a)
        a = gf32_mul(a, a)
        exponent >>= 1
    return result


def gf32_primitives() -> list[int]:
    # |GF(32)^*|=31 is prime, so every nonidentity element is primitive.
    primitives = []
    for element in range(2, 32):
        powers = {gf32_pow(element, exponent) for exponent in range(1, 32)}
        if len(powers) == 31 and powers == set(range(1, 32)):
            primitives.append(element)
    if primitives != list(range(2, 32)):
        raise AssertionError("GF(32) primitive-element audit failed")
    return primitives


def g2_permutation(alpha: int, beta: int) -> list[int]:
    # pi(i)=j iff alpha^j + beta^i = 1; + is XOR in characteristic two.
    alpha_log = {gf32_pow(alpha, j): j for j in range(1, 31)}
    permutation = []
    for i in range(1, 31):
        target = 1 ^ gf32_pow(beta, i)
        permutation.append(alpha_log[target])
    if sorted(permutation) != list(range(1, 31)):
        raise AssertionError("G2 formula did not produce a permutation")
    return permutation


def corner_criterion(base: list[int], rising: bool) -> tuple[bool, dict[str, Any] | None]:
    """Exact two-corner extension criterion, evaluated without a verifier.

    rising=True means [1, base+1, n+2].  For falling orientation, reflect
    the completed array vertically first, reducing it to the rising formula.
    """
    n = len(base)
    working = base if rising else [n + 1 - value for value in base]
    for distance in range(1, n + 1):
        old = {
            working[start + distance] - working[start]
            for start in range(0, n - distance)
        }
        from_left = working[distance - 1]
        from_right = n + 1 - working[n - distance]
        if from_left == from_right or from_left in old or from_right in old:
            return False, {
                "distance": distance,
                "from_left": from_left,
                "from_right": from_right,
                "old_contains_left": from_left in old,
                "old_contains_right": from_right in old,
                "corners_collide": from_left == from_right,
            }
    return True, None


def run_g2_g0() -> dict[str, Any]:
    primitives = gf32_primitives()
    bases: dict[tuple[int, ...], list[list[int]]] = {}
    extension_count = 0
    passing: list[dict[str, Any]] = []
    excess_histogram: Counter[int] = Counter()
    vector_count_histogram: Counter[int] = Counter()
    first_failure_distance_histogram: Counter[int] = Counter()
    closest: dict[str, Any] | None = None

    for alpha in primitives:
        for beta in primitives:
            base = g2_permutation(alpha, beta)
            bases.setdefault(tuple(base), []).append([alpha, beta])
            base_reference, _ = cross_verify(base)
            if not base_reference["is_costas"]:
                raise AssertionError((alpha, beta, "G2 base failed"))

            for orientation in ("rising", "falling"):
                rising = orientation == "rising"
                extension = (
                    [1] + [value + 1 for value in base] + [32]
                    if rising
                    else [32] + [value + 1 for value in base] + [1]
                )
                reference, independent = cross_verify(extension)
                criterion_ok, failure = corner_criterion(base, rising)
                if criterion_ok != reference["is_costas"]:
                    raise AssertionError("corner criterion and verifier disagree")
                extension_count += 1
                excess = reference["duplicate_pair_occurrence_excess"]
                vectors = reference["duplicate_vector_count"]
                excess_histogram[excess] += 1
                vector_count_histogram[vectors] += 1
                if failure is not None:
                    first_failure_distance_histogram[failure["distance"]] += 1
                if closest is None or (excess, vectors, alpha, beta, orientation) < (
                    closest["duplicate_pair_occurrence_excess"],
                    closest["duplicate_vector_count"],
                    closest["alpha"],
                    closest["beta"],
                    closest["orientation"],
                ):
                    closest = {
                        "alpha": alpha,
                        "beta": beta,
                        "orientation": orientation,
                        "base": base,
                        "extension": extension,
                        "duplicate_pair_occurrence_excess": excess,
                        "duplicate_vector_count": vectors,
                        "first_collision": reference["duplicate_vectors"][0]
                        if reference["duplicate_vectors"]
                        else None,
                        "criterion_first_failure": failure,
                        "reference_is_costas": reference["is_costas"],
                        "independent_is_costas": independent["is_costas"],
                    }
                if reference["is_costas"]:
                    passing.append(
                        {
                            "alpha": alpha,
                            "beta": beta,
                            "orientation": orientation,
                            "permutation": extension,
                            "reference": reference,
                            "independent": independent,
                        }
                    )

    return {
        "field": {
            "size": 32,
            "representation": "GF(2)[x]/(x^5+x^2+1)",
            "modulus_bits": GF32_MODULUS,
            "primitive_elements": primitives,
        },
        "parameter_pairs": len(primitives) ** 2,
        "distinct_g2_base_permutations": len(bases),
        "extensions_checked": extension_count,
        "orientations": ["[1,pi+1,32]", "[32,pi+1,1]"],
        "passing_extensions": passing,
        "duplicate_excess_histogram": dict(sorted(excess_histogram.items())),
        "duplicate_vector_count_histogram": dict(sorted(vector_count_histogram.items())),
        "criterion_first_failure_distance_histogram": dict(
            sorted(first_failure_distance_histogram.items())
        ),
        "closest_extension": closest,
    }


def prime_factors(number: int) -> list[int]:
    factors = []
    divisor = 2
    while divisor * divisor <= number:
        if number % divisor == 0:
            factors.append(divisor)
            while number % divisor == 0:
                number //= divisor
        divisor += 1
    if number > 1:
        factors.append(number)
    return factors


def primitive_roots_prime(prime: int) -> list[int]:
    order = prime - 1
    factors = prime_factors(order)
    return [
        candidate
        for candidate in range(2, prime)
        if all(pow(candidate, order // factor, prime) != 1 for factor in factors)
    ]


def run_w1_crops() -> dict[str, Any]:
    prime = 37
    roots = primitive_roots_prime(prime)
    checks = 0
    hits: list[dict[str, Any]] = []
    overlap_histogram: Counter[int] = Counter()
    closest: list[dict[str, Any]] = []
    best_overlap = -1

    for root in roots:
        for shift in range(prime - 1):
            source = [pow(root, index + shift, prime) for index in range(prime - 1)]
            source_reference, _ = cross_verify(source)
            if not source_reference["is_costas"]:
                raise AssertionError((root, shift, "W1 source failed"))
            for column_offset in range(5):
                retained = source[column_offset : column_offset + 32]
                retained_set = set(retained)
                for row_offset in range(5):
                    row_interval = set(range(row_offset + 1, row_offset + 33))
                    overlap = len(retained_set & row_interval)
                    overlap_histogram[overlap] += 1
                    checks += 1
                    record = {
                        "primitive_root": root,
                        "shift_c": shift,
                        "column_offset": column_offset,
                        "row_offset": row_offset,
                        "overlap": overlap,
                        "retained_values": retained,
                        "missing_from_row_interval": sorted(row_interval - retained_set),
                        "outside_row_interval": sorted(retained_set - row_interval),
                    }
                    if overlap > best_overlap:
                        best_overlap = overlap
                        closest = [record]
                    elif overlap == best_overlap and len(closest) < 8:
                        closest.append(record)
                    if retained_set == row_interval:
                        cropped = [value - row_offset for value in retained]
                        reference, independent = cross_verify(cropped)
                        hits.append(
                            {
                                **record,
                                "permutation": cropped,
                                "reference": reference,
                                "independent": independent,
                            }
                        )

    return {
        "source_family": "W1(p=37)",
        "primitive_roots": roots,
        "shifts": list(range(36)),
        "column_offsets": list(range(5)),
        "row_offsets": list(range(5)),
        "parameter_tuples_checked": checks,
        "passing_crops": hits,
        "best_overlap_out_of_32": best_overlap,
        "closest_examples": closest,
        "overlap_histogram": dict(sorted(overlap_histogram.items())),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    result = {
        "marker": "COSTAS32_ROLE1_ALGEBRAIC_ADJACENT_FAMILIES_V1",
        "indexing": "1-based",
        "uploaded_verifier_hashes": {
            str(REFERENCE_PATH.relative_to(ROOT)): file_hash(REFERENCE_PATH),
            str(INDEPENDENT_PATH.relative_to(ROOT)): file_hash(INDEPENDENT_PATH),
        },
        "g2_g0_gf32": run_g2_g0(),
        "w1_p37_boundary_crops": run_w1_crops(),
    }
    result["result_sha256_without_this_field"] = compact_hash(result)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "output": str(args.output),
        "result_sha256_without_this_field": result["result_sha256_without_this_field"],
        "g0_extensions_checked": result["g2_g0_gf32"]["extensions_checked"],
        "g0_passing": len(result["g2_g0_gf32"]["passing_extensions"]),
        "w1_crop_tuples_checked": result["w1_p37_boundary_crops"]["parameter_tuples_checked"],
        "w1_crop_passing": len(result["w1_p37_boundary_crops"]["passing_crops"]),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
