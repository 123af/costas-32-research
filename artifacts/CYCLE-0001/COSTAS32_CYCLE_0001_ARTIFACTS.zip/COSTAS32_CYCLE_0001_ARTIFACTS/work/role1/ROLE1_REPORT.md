# 역할 1 첫 연구 파동 보고서 — 차수 32에 인접한 두 대수 계열의 완전 소진

## 실행 장부

- 역할: 에이전트 1 — 기존 대수적 구성의 일반화
- 인덱싱: 모든 순열 위치와 값은 1-based
- 읽은 프로젝트 자료: `WORK_ORCHESTRATOR_PROMPT(1).md`, `AGENT_ROLES(1).md`, `RESEARCH_CONTEXT(1).md`, `known_arrays(1).json`, `test_cases(1).json`, `reference_verifier(1).py`, `independent_verifier(1).py`, `test_verifiers(1).py` 전부
- Python: 3.12.13
- 이번 역할 실행에서 재실행한 자체 시험:
  - `python upload/'reference_verifier(1).py' --self-test`: PASS
  - `python upload/'independent_verifier(1).py' --self-test`: PASS
- 연구 실행 명령:

```text
python work/role1/algebraic_adjacent_families.py \
  --output work/role1/algebraic_adjacent_families_result.json
```

- 동일 명령을 다른 출력명으로 한 번 더 실행했으며 두 JSON 파일의 바이트가 일치했다.
- 코드 SHA-256: `651718cac3dd328cc3338b3d3e970e25958a1411a55929a63758bbfae9c1aced`
- 결과 JSON SHA-256: `edefc71875c43199dd3ecced289aa96d095cce876c54d736cec3aee3bf740bf3`
- 결과 내용 자체의 정규 JSON SHA-256(해시 필드 삽입 전): `cb25bda63ae8c782d13b8a4bb60b53701b8ca965b452867ddc3df8cd24a32f50`
- 업로드된 두 검증기의 해시는 결과 JSON에 기록했다.

아래 두 결과는 제안 에이전트의 자체 판정일 뿐이다. 최종 `verified` 또는 `proved` 판정을 하지 않는다.

---

## 산출물 1 — GF(32) G2 배열의 모든 두 대각 모서리 G0 확장 소진

### 정확한 일반 명제(증명 초안)

차수 `n`의 코스타스 순열을

\[
p=[p_1,\ldots,p_n]
\]

이라 하자. 두 대각 모서리를 붙인 상승형 확장을

\[
E^+(p)=[1,p_1+1,\ldots,p_n+1,n+2]
\]

로 정의한다. 그러면 `E⁺(p)`가 코스타스일 필요충분조건은 모든
\(d=1,\ldots,n\)에 대해 다음 세 조건이 동시에 성립하는 것이다.

\[
p_d\notin T_d(p),
\]

\[
n+1-p_{n+1-d}\notin T_d(p),
\]

\[
p_d\ne n+1-p_{n+1-d}.
\]

여기서

\[
T_d(p)=\{p_{i+d}-p_i:1\le i\le n-d\}
\]

이며 `d=n`일 때 이 집합은 공집합이다.

하강형 확장

\[
E^-(p)=[n+2,p_1+1,\ldots,p_n+1,1]
\]

은 `p`를 수직 반사한 순열 `n+1-p`에 같은 조건을 적용한 것과 동치다.

### 증명된 부분

상승형의 거리 `d` 차분 행은 정확히

\[
T_d(E^+(p))=
[p_d]\,\mathbin\Vert\,T_d(p)\,\mathbin\Vert\,
[n+1-p_{n+1-d}]
\]

이다. 거리 `n+1` 차분 행에는 `(n+1)` 하나만 있다. `p`가 이미 코스타스이므로 각 `T_d(p)`의 내부 중복은 없다. 따라서 새로 붙은 두 값이 기존 행과 서로에 대해 모두 달라야 하고, 이것으로 충분하다. 하강형은 완성 배열의 수직 반사가 상승형이 되는 데서 따른다.

이 논증은 일반 정리 초안이다. 적대적 심사를 아직 통과하지 않았다.

### 차수 32의 기계적 영역

유한체를

\[
\mathbb F_{32}=\mathbb F_2[x]/(x^5+x^2+1)
\]

로 구현했다. 곱셈군의 크기가 소수 `31`이므로 `1`이 아닌 비영 원소 30개는 전부 원시원이다. 프로그램은 각 원소의 31개 거듭제곱이 정확히 모든 비영 원소를 순회하는지 별도로 확인했다.

모든 원시원 쌍

\[
(\alpha,\beta)\in(\mathbb F_{32}^{\times}\setminus\{1\})^2
\]

900개에 대해 G2 순열 `p`를

\[
\alpha^{p_i}+\beta^i=1,
\qquad 1\le i\le30
\]

로 생성했다. 각 G2 기저 배열을 두 업로드 검증기로 검사한 뒤 `E⁺(p)`와 `E⁻(p)`를 검사했다.

### 계산 결과(명시적 유한 영역의 완전 검사)

- 원시원 쌍: 900개 전부 처리
- 서로 다른 G2 기저 순열: 180개
- 차수 32 두 모서리 확장: `900 × 2 = 1,800`개 전부 처리
- 두 제공 검증기의 전체 충돌 보고 불일치: 0건
- 위의 독립적인 모서리 조건과 검증기의 `is_costas` 불일치: 0건
- 통과 확장: 0개
- 중복 변위 초과 수 분포:
  - 10: 100개
  - 12: 400개
  - 14: 400개
  - 16: 400개
  - 18: 400개
  - 20: 100개
- 모서리 조건에서 처음 실패한 거리 분포:
  - `d=1`: 1,340개
  - `d=2`: 360개
  - `d=3`: 80개
  - `d=4`: 20개

따라서 검사한 정확한 영역, 즉 **GF(32)의 모든 G2 매개변수 쌍에 표준의 두 대각 모서리를 붙이는 G0형 차수 32 확장**에서는 후보가 없다. 이것은 차수 32 전체의 비존재가 아니다.

### 가장 작은 충돌 수의 실패 사례

최소 중복 변위 초과 수는 10이다. 사전식 타이브레이크로 저장한 사례는 다음과 같다.

- `alpha=2`, `beta=19`, 상승형
- G2 기저:

```json
[30,29,8,27,12,16,28,23,3,24,18,1,10,25,22,15,4,6,14,17,9,5,11,2,7,20,21,19,26,13]
```

- 차수 32 확장:

```json
[1,31,30,9,28,13,17,29,24,4,25,19,2,11,26,23,16,5,7,15,18,10,6,12,3,8,21,22,20,27,14,32]
```

- 저장된 첫 충돌: 벡터 `(2,5)`가 점쌍 `((28,22),(30,27))`와 `((30,27),(32,32))`에서 중복된다.
- 두 제공 검증기 모두 `is_costas=false`.

이는 일반 명제의 “최소 반례”가 아니라, 소진된 실패 영역에서 충돌 수가 최소인 명시적 사례다.

### 기존 계열과의 관계 및 신규성

- 구성 자체는 `RESEARCH_CONTEXT.md`가 이미 차수 32의 가능성으로 명시한 `q=32` G2 → G0 두 점 추가이며 새 계열이 아니다.
- 일반 두 모서리 필요충분조건도 직접 차분 전개로 얻은 초등 조건이다. 기존 문헌과의 신규성 감사는 하지 않았으므로 신규성은 불명이다.
- 이번 산출물의 실질은 이 자연스러운 차수 32 매개변수 영역을 재현 가능하게 전부 소진하고, 두 검사기와 별도 조건 검사까지 일치시킨 데 있다.

### blocker

표준 G0형은 완전히 막혔다. 이 경로를 재개하려면 두 모서리를 고정한 채 매개변수만 다시 바꾸는 것이 아니라, Rickard형 순환 이동, 내부 삽입, 또는 추가 국소 변환처럼 실제로 다른 기제가 필요하다.

### 역할 7에 넘길 기계적 요청

```json
{
  "request_id": "R1-G0-GF32-INDEPENDENT-001",
  "claim_id": "C-R1-G0-GF32-EXHAUSTION",
  "statement": "For every primitive alpha,beta in GF(32), neither [1,G2(alpha,beta)+1,32] nor [32,G2(alpha,beta)+1,1] is Costas.",
  "domain": {
    "field_size": 32,
    "primitive_alpha_count": 30,
    "primitive_beta_count": 30,
    "orientations": 2,
    "total_extensions": 1800
  },
  "symmetry_normalization": "none",
  "wanted": "independent exhausted_in_domain check",
  "implementation_request": "Use a finite-field library or a different irreducible degree-5 polynomial and independently generate all G2 permutations; do not copy the submitted GF multiplication.",
  "expected": {
    "passing_extensions": 0,
    "distinct_g2_base_permutations": 180,
    "duplicate_excess_histogram": {"10":100,"12":400,"14":400,"16":400,"18":400,"20":100}
  },
  "success": "all 1800 handled, no witness, independent checker agreement",
  "failure": "a valid length-32 witness, missing parameter pair, field-model discrepancy, or count mismatch"
}
```

---

## 산출물 2 — W1(p=37)의 모든 32×32 경계 직사각형 crop 소진

### 정확한 일반 명제(증명 초안)

`P`를 차수 `N`의 코스타스 순열이라 하자. 정수 `a,b,n`이

\[
0\le a,b,\qquad a+n\le N,\quad b+n\le N
\]

을 만족하고,

\[
P(\{a+1,\ldots,a+n\})=\{b+1,\ldots,b+n\}
\]

이면

\[
Q(i)=P(a+i)-b,\qquad 1\le i\le n
\]

는 차수 `n`의 코스타스 순열이다.

### 증명된 부분

가정으로 `Q`는 `[n]`의 순열이다. 두 남은 점의 변위는

\[
((a+j)-(a+i),(P(a+j)-b)-(P(a+i)-b))
=(j-i,P(a+j)-P(a+i))
\]

로 원래 `P`에서의 변위와 동일하다. `P`의 서로 다른 점쌍 변위가 모두 다르므로 `Q`도 코스타스다.

이 정리는 내부 좌표 압축이 아니다. 사각형 바깥의 경계 행·열만 버리고 남은 좌표 전체를 평행 이동하므로 안전하다.

### 차수 32의 기계적 영역

가장 가까운 큰 Welch 원천인 차수 36의 모든 W1 배열을 사용했다.

\[
P_{g,c}(i)=g^{i-1+c}\pmod {37},
\]

여기서

- `g`: mod 37 원시근 12개 전부
  `[2,5,13,15,17,18,19,20,22,24,32,35]`
- `c`: `0,...,35` 전부
- 남길 32개 연속 열의 시작 오프셋 `a`: `0,...,4` 전부
- 남길 32개 연속 행 구간의 시작 오프셋 `b`: `0,...,4` 전부

각 매개변수 튜플에서

\[
P_{g,c}(\{a+1,\ldots,a+32\})
=\{b+1,\ldots,b+32\}
\]

인지 검사했다.

### 계산 결과(명시적 유한 영역의 완전 검사)

- 검사 튜플 수: `12 × 36 × 5 × 5 = 10,800`
- crop 조건을 만족한 튜플: 0개
- 32개 목표 행 중 일치한 값의 최대 수: 31
- 겹침 수 분포:
  - 28: 6,680개
  - 29: 3,480개
  - 30: 600개
  - 31: 40개

따라서 **모든 W1(p=37) 배열을 경계에서만 잘라 얻는 모든 32×32 연속 정사각형 crop**에서는 차수 32 후보가 없다. 더 큰 소수의 W1 배열, 비연속 삭제, 내부 압축, 다른 Welch 파생은 검사하지 않았다.

### 첫 번째 최대 겹침 실패 사례

- `g=2`, `c=0`, `a=3`, `b=4`
- 남은 값 32개:

```json
[8,16,32,27,17,34,31,25,13,26,15,30,23,9,18,36,35,33,29,21,5,10,20,3,6,12,24,11,22,7,14,28]
```

- 목표 행 구간: `{5,...,36}`
- 목표에서 빠진 값: `19`
- 목표 밖에 남은 값: `3`

이것은 조건을 거의 만족하지만 내부 행 `3`을 삭제하고 `19`를 삽입하는 압축은 위 정리의 범위를 벗어나며 코스타스 보존이 자동으로 따르지 않는다.

### 기존 계열과의 관계 및 신규성

- 원천은 기존 W1이고, 변환은 변위를 보존하는 경계 crop이다.
- W2/W3처럼 특정 첫 점들을 삭제하는 구성의 직사각형 일반화지만 새로운 무한 계열을 얻지는 못했다.
- 전치(로그형)와 정사각형 대칭은 crop 존재성을 보존하므로 별도 새 영역으로 세지 않았다.
- 일반 crop 정리의 문헌 신규성은 감사하지 않았으며 새 정리라고 주장하지 않는다.

### blocker

`p=37`의 W1 경계 crop은 완전히 막혔다. 가장 가까운 40개 경우도 값 하나가 행 구간 밖에 있다. 그 값을 내부 행 삭제/삽입으로 교체하려면 기존 점쌍 변위 변화까지 다루는 별도의 새로운 정리가 필요하다.

### 역할 7에 넘길 기계적 요청

```json
{
  "request_id": "R1-W1-P37-CROP-INDEPENDENT-002",
  "claim_id": "C-R1-W1-P37-CROP-EXHAUSTION",
  "statement": "No W1(p=37) permutation has a contiguous 32-column interval whose values are a contiguous 32-row interval.",
  "domain": {
    "primitive_roots_mod_37": 12,
    "shifts_c": [0,35],
    "column_offsets": [0,4],
    "row_offsets": [0,4],
    "total_tuples": 10800
  },
  "symmetry_normalization": "none; all parameter tuples are explicitly included",
  "wanted": "independent exhausted_in_domain check",
  "implementation_request": "Independently enumerate primitive roots and compare retained sets; do not reuse the submitted routine.",
  "expected": {
    "passing_crops": 0,
    "best_overlap_out_of_32": 31,
    "overlap_histogram": {"28":6680,"29":3480,"30":600,"31":40}
  },
  "success": "all 10800 tuples handled with the expected zero-hit result",
  "failure": "a valid crop witness, an omitted primitive root/shift/offset, or a count mismatch"
}
```

---

## 차수 32에 대한 정확한 의미와 남는 한계

1. 완전한 차수 32 순열 후보는 발견되지 않았다.
2. 차수 32의 존재 또는 비존재는 해결되지 않았다.
3. 다만 프로젝트 문맥이 직접 지목한 `q=32` G0 가능성 전체와 가장 가까운 큰 W1(p=37)의 안전한 4행·4열 경계 crop 전체를 재현 가능하게 소진했다.
4. 두 결과 모두 명시된 제한 영역 밖으로 일반화해서는 안 된다.
5. 다음 유망한 대수 방향은 같은 매개변수 반복이 아니라 (a) G2의 Rickard형 순환 이동 후 점 추가, 또는 (b) W1(p=37)의 31/32 근접 crop에서 한 내부 값 교체가 만드는 모든 변위 변화를 정확히 분류하는 것이다.

