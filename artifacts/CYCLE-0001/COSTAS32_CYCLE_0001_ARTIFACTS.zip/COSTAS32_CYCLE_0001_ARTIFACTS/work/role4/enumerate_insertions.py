#!/usr/bin/env python3
"""Exact finite insertion enumerations for Costas arrays (role 4).

All coordinates are 1-based.  The script deliberately performs a complete
difference-triangle check on every generated permutation, including old-old
pairs whose displacement changes across an inserted row or column.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import platform
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable


def compact_sha256(obj: object) -> str:
    raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def is_costas(permutation: list[int]) -> bool:
    """Difference-triangle test with immediate rejection."""
    n = len(permutation)
    for distance in range(1, n):
        used: set[int] = set()
        for start in range(n - distance):
            difference = permutation[start + distance] - permutation[start]
            if difference in used:
                return False
            used.add(difference)
    return True


def collision_groups(permutation: list[int]) -> list[dict[str, object]]:
    """Return every repeated displacement and every realizing point-pair."""
    by_vector: dict[tuple[int, int], list[list[list[int]]]] = defaultdict(list)
    n = len(permutation)
    for left in range(n):
        for right in range(left + 1, n):
            vector = (right - left, permutation[right] - permutation[left])
            by_vector[vector].append(
                [[left + 1, permutation[left]], [right + 1, permutation[right]]]
            )
    return [
        {
            "vector": list(vector),
            "multiplicity": len(pairs),
            "point_pairs": pairs,
        }
        for vector, pairs in sorted(by_vector.items())
        if len(pairs) > 1
    ]


def insert_one(permutation: list[int], column: int, row: int) -> list[int]:
    """Insert one column/row and their intersection point (column,row)."""
    n = len(permutation)
    if not (1 <= column <= n + 1 and 1 <= row <= n + 1):
        raise ValueError("one-point insertion position out of range")
    result = [0] * (n + 1)
    result[column - 1] = row
    for old_column, old_row in enumerate(permutation, start=1):
        new_column = old_column + (old_column >= column)
        new_row = old_row + (old_row >= row)
        result[new_column - 1] = new_row
    assert sorted(result) == list(range(1, n + 2))
    return result


def insert_two(
    permutation: list[int],
    new_columns: tuple[int, int],
    new_rows: tuple[int, int],
    crossed: bool,
) -> list[int]:
    """Insert two rows/columns and match them in parallel or crossed order."""
    target = len(permutation) + 2
    a1, a2 = new_columns
    b1, b2 = new_rows
    if not (1 <= a1 < a2 <= target and 1 <= b1 < b2 <= target):
        raise ValueError("two-point insertion positions out of range")

    old_columns = [x for x in range(1, target + 1) if x not in new_columns]
    old_rows = [y for y in range(1, target + 1) if y not in new_rows]
    result = [0] * target
    for old_column, old_row in enumerate(permutation, start=1):
        result[old_columns[old_column - 1] - 1] = old_rows[old_row - 1]
    if crossed:
        result[a1 - 1], result[a2 - 1] = b2, b1
    else:
        result[a1 - 1], result[a2 - 1] = b1, b2
    assert sorted(result) == list(range(1, target + 1))
    return result


def one_category(n: int, column: int, row: int) -> str:
    boundary_column = column in (1, n + 1)
    boundary_row = row in (1, n + 1)
    if boundary_column and boundary_row:
        return "external_corner"
    if boundary_column or boundary_row:
        return "mixed_boundary_internal"
    return "strict_internal"


def enumerate_one(permutation: list[int]) -> dict[str, object]:
    n = len(permutation)
    started = time.perf_counter()
    counts: Counter[str] = Counter()
    valid_by_category: Counter[str] = Counter()
    valid: list[dict[str, object]] = []
    best_failure: dict[str, object] | None = None
    best_collision_count: int | None = None

    for column in range(1, n + 2):
        for row in range(1, n + 2):
            category = one_category(n, column, row)
            counts[category] += 1
            candidate = insert_one(permutation, column, row)
            if is_costas(candidate):
                valid_by_category[category] += 1
                valid.append(
                    {
                        "column": column,
                        "row": row,
                        "category": category,
                        "permutation": candidate,
                        "permutation_sha256": compact_sha256(candidate),
                    }
                )
                continue
            collisions = collision_groups(candidate)
            collision_count = len(collisions)
            if best_collision_count is None or collision_count < best_collision_count:
                best_collision_count = collision_count
                best_failure = {
                    "column": column,
                    "row": row,
                    "category": category,
                    "permutation": candidate,
                    "duplicate_vector_count": collision_count,
                    "duplicate_pair_occurrence_excess": sum(
                        int(item["multiplicity"]) - 1 for item in collisions
                    ),
                    "first_collision": collisions[0],
                }

    elapsed = time.perf_counter() - started
    return {
        "source_order": n,
        "target_order": n + 1,
        "domain_definition": "all (a,b) in [n+1]^2",
        "total_cases": (n + 1) ** 2,
        "cases_by_category": dict(counts),
        "valid_cases": len(valid),
        "valid_cases_by_category": dict(valid_by_category),
        "valid_witnesses": valid,
        "best_failure": best_failure,
        "elapsed_seconds": elapsed,
    }


def enumerate_two(permutation: list[int]) -> dict[str, object]:
    n = len(permutation)
    target = n + 2
    started = time.perf_counter()
    total = 0
    valid: list[dict[str, object]] = []
    first_collision_vectors: Counter[str] = Counter()
    progress_mark = 100_000

    for columns in itertools.combinations(range(1, target + 1), 2):
        for rows in itertools.combinations(range(1, target + 1), 2):
            for crossed in (False, True):
                total += 1
                candidate = insert_two(permutation, columns, rows, crossed)
                if is_costas(candidate):
                    valid.append(
                        {
                            "new_columns": list(columns),
                            "new_rows": list(rows),
                            "crossed": crossed,
                            "new_points": [
                                [columns[0], rows[1 if crossed else 0]],
                                [columns[1], rows[0 if crossed else 1]],
                            ],
                            "permutation": candidate,
                            "permutation_sha256": compact_sha256(candidate),
                        }
                    )
                else:
                    # Record the first difference-triangle collision cheaply.
                    found = False
                    for distance in range(1, target):
                        seen: set[int] = set()
                        for start in range(target - distance):
                            diff = candidate[start + distance] - candidate[start]
                            if diff in seen:
                                first_collision_vectors[f"{distance},{diff}"] += 1
                                found = True
                                break
                            seen.add(diff)
                        if found:
                            break
                if total == progress_mark:
                    print(
                        json.dumps(
                            {
                                "progress": total,
                                "valid_so_far": len(valid),
                                "elapsed_seconds": time.perf_counter() - started,
                            }
                        ),
                        file=sys.stderr,
                        flush=True,
                    )
                    progress_mark += 100_000

    expected = len(list(itertools.combinations(range(1, target + 1), 2))) ** 2 * 2
    assert total == expected
    elapsed = time.perf_counter() - started
    return {
        "source_order": n,
        "target_order": target,
        "domain_definition": (
            "all A,B subsets of [n+2] with |A|=|B|=2 and both bijections A->B"
        ),
        "total_cases": total,
        "valid_cases": len(valid),
        "valid_witnesses": valid,
        "first_collision_vector_histogram": dict(
            sorted(first_collision_vectors.items())
        ),
        "elapsed_seconds": elapsed,
    }


def pair_origins_one(n: int, column: int, pair: list[list[int]]) -> str:
    """Classify a pair in the post-insertion array as old-old or new-old."""
    return "new-old" if any(point[0] == column for point in pair) else "old-old"


def minimal_old_old_only_failure(max_source_order: int) -> dict[str, object] | None:
    """Find the first insertion failure whose collisions are all old-old.

    This is a minimal counterexample to checking only pairs incident with the
    inserted point.  Source permutations are exhaustively enumerated in
    increasing order and lexicographic order.
    """
    for n in range(1, max_source_order + 1):
        for values in itertools.permutations(range(1, n + 1)):
            permutation = list(values)
            if not is_costas(permutation):
                continue
            for column in range(1, n + 2):
                for row in range(1, n + 2):
                    candidate = insert_one(permutation, column, row)
                    collisions = collision_groups(candidate)
                    if not collisions:
                        continue
                    origins = {
                        pair_origins_one(n, column, pair)
                        for item in collisions
                        for pair in item["point_pairs"]  # type: ignore[index]
                    }
                    if origins == {"old-old"}:
                        return {
                            "source_order": n,
                            "source_permutation": permutation,
                            "inserted_column": column,
                            "inserted_row": row,
                            "target_permutation": candidate,
                            "collisions": collisions,
                            "meaning": (
                                "Every collision is between transformed old-old pairs; "
                                "a check restricted to new-old pairs accepts falsely."
                            ),
                        }
    return None


def load_record(path: Path, record_id: str) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as stream:
        document = json.load(stream)
    for record in document["records"]:
        if record["id"] == record_id:
            return record
    raise KeyError(record_id)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--known", type=Path, required=True)
    parser.add_argument("--mode", choices=("one", "two", "small"), required=True)
    parser.add_argument("--record-id")
    parser.add_argument("--max-source-order", type=int, default=7)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    envelope: dict[str, object] = {
        "script": str(Path(__file__).resolve()),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "argv": sys.argv,
    }
    if args.mode == "small":
        envelope["result"] = minimal_old_old_only_failure(args.max_source_order)
    else:
        if not args.record_id:
            parser.error("--record-id is required for one/two mode")
        record = load_record(args.known, args.record_id)
        permutation = record["permutation"]
        assert isinstance(permutation, list)
        envelope["input"] = {
            "record_id": record["id"],
            "order": record["order"],
            "permutation": permutation,
            "permutation_sha256": compact_sha256(permutation),
        }
        envelope["result"] = (
            enumerate_one(permutation)
            if args.mode == "one"
            else enumerate_two(permutation)
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as stream:
        json.dump(envelope, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"output": str(args.output), "sha256": compact_sha256(envelope)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
