#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

using Perm30 = std::array<std::uint8_t, 30>;
using Perm32 = std::array<std::uint8_t, 32>;

static int mod_pow(int base, int exponent) {
    int result = 1;
    while (exponent--) result = (result * base) % 31;
    return result;
}

static std::vector<Perm30> make_w1_bases(int& primitive_root_count) {
    std::set<Perm30> unique;
    primitive_root_count = 0;
    for (int root = 2; root < 31; ++root) {
        std::set<int> powers;
        for (int exponent = 0; exponent < 30; ++exponent) powers.insert(mod_pow(root, exponent));
        if (powers.size() != 30) continue;
        ++primitive_root_count;
        for (int shift = 0; shift < 30; ++shift) {
            Perm30 permutation{};
            for (int i = 0; i < 30; ++i) {
                permutation[static_cast<std::size_t>(i)] =
                    static_cast<std::uint8_t>(mod_pow(root, i + shift));
            }
            unique.insert(permutation);
        }
    }
    return std::vector<Perm30>(unique.begin(), unique.end());
}

static bool is_costas(const Perm32& permutation) {
    for (int distance = 1; distance < 32; ++distance) {
        std::uint64_t used = 0;
        for (int start = 0; start + distance < 32; ++start) {
            const int difference = static_cast<int>(permutation[start + distance]) - permutation[start];
            const std::uint64_t bit = UINT64_C(1) << static_cast<unsigned>(difference + 31);
            if (used & bit) return false;
            used |= bit;
        }
    }
    return true;
}

struct CollisionSummary {
    int excess_capped_at_two = 0;
    std::array<int, 4> first_collision_columns{};
};

static CollisionSummary collision_summary(const Perm32& permutation) {
    CollisionSummary result;
    for (int distance = 1; distance < 32; ++distance) {
        std::array<int, 63> first_start{};
        first_start.fill(-1);
        for (int start = 0; start + distance < 32; ++start) {
            const int difference = static_cast<int>(permutation[start + distance]) - permutation[start];
            const int index = difference + 31;
            if (first_start[index] < 0) {
                first_start[index] = start;
                continue;
            }
            ++result.excess_capped_at_two;
            if (result.excess_capped_at_two == 1) {
                result.first_collision_columns = {
                    first_start[index], first_start[index] + distance,
                    start, start + distance
                };
            }
            if (result.excess_capped_at_two >= 2) return result;
        }
    }
    return result;
}

static std::vector<std::array<int, 2>> all_pairs() {
    std::vector<std::array<int, 2>> result;
    result.reserve(496);
    for (int first = 0; first < 32; ++first) {
        for (int second = first + 1; second < 32; ++second) result.push_back({first, second});
    }
    return result;
}

static std::array<std::uint8_t, 30> complement(const std::array<int, 2>& omitted) {
    std::array<std::uint8_t, 30> result{};
    int index = 0;
    for (int value = 0; value < 32; ++value) {
        if (value != omitted[0] && value != omitted[1]) result[static_cast<std::size_t>(index++)] = value + 1;
    }
    return result;
}

static void write_permutation(std::ostream& output, const Perm32& permutation) {
    output << '[';
    for (std::size_t i = 0; i < permutation.size(); ++i) {
        if (i) output << ',';
        output << static_cast<int>(permutation[i]);
    }
    output << ']';
}

int main(int argc, char** argv) {
    const std::string output_path = argc > 1 ? argv[1] : "result.json";
    const auto started = std::chrono::steady_clock::now();
    int root_count = 0;
    const auto bases = make_w1_bases(root_count);
    const auto pairs = all_pairs();
    std::vector<std::array<std::uint8_t, 30>> maps;
    for (const auto& pair : pairs) maps.push_back(complement(pair));

    std::uint64_t checked = 0;
    std::uint64_t witness_count = 0;
    std::uint64_t one_collision_cases = 0;
    std::uint64_t repair_witness_count = 0;
    Perm32 first_witness{};
    std::size_t first_base = 0;
    std::array<int, 2> first_columns{};
    std::array<int, 2> first_rows{};
    int first_matching = -1;
    Perm32 first_repair_witness{};
    std::array<int, 2> first_repair_swap{};

    for (std::size_t base_index = 0; base_index < bases.size(); ++base_index) {
        const auto& base = bases[base_index];
        for (std::size_t ci = 0; ci < pairs.size(); ++ci) {
            for (std::size_t ri = 0; ri < pairs.size(); ++ri) {
                Perm32 candidate{};
                for (int old_column = 0; old_column < 30; ++old_column) {
                    candidate[maps[ci][old_column] - 1] = maps[ri][base[old_column] - 1];
                }
                for (int matching = 0; matching < 2; ++matching) {
                    candidate[pairs[ci][0]] = pairs[ri][matching] + 1;
                    candidate[pairs[ci][1]] = pairs[ri][1 - matching] + 1;
                    ++checked;
                    const CollisionSummary collisions = collision_summary(candidate);
                    if (collisions.excess_capped_at_two == 0) {
                        ++witness_count;
                        if (witness_count == 1) {
                            first_witness = candidate;
                            first_base = base_index;
                            first_columns = pairs[ci];
                            first_rows = pairs[ri];
                            first_matching = matching;
                        }
                    } else if (collisions.excess_capped_at_two == 1) {
                        ++one_collision_cases;
                        std::set<std::array<int, 2>> eligible_swaps;
                        for (int collision_column : collisions.first_collision_columns) {
                            for (int other = 0; other < 32; ++other) {
                                if (other == collision_column) continue;
                                eligible_swaps.insert({std::min(other, collision_column), std::max(other, collision_column)});
                            }
                        }
                        for (const auto& swap_pair : eligible_swaps) {
                            Perm32 repaired = candidate;
                            std::swap(repaired[swap_pair[0]], repaired[swap_pair[1]]);
                            if (!is_costas(repaired)) continue;
                            ++repair_witness_count;
                            if (repair_witness_count == 1) {
                                first_repair_witness = repaired;
                                first_repair_swap = swap_pair;
                            }
                        }
                    }
                }
            }
        }
        if ((base_index + 1) % 20 == 0 || base_index + 1 == bases.size()) {
            std::cerr << "bases " << base_index + 1 << '/' << bases.size()
                      << " checked " << checked << " witnesses " << witness_count
                      << " one_collision " << one_collision_cases
                      << " repair_witnesses " << repair_witness_count << '\n';
        }
    }

    const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
    std::ofstream output(output_path);
    output << "{\n  \"marker\": \"COSTAS_WAVE2_W1P31_TWO_INSERTIONS_V1\",\n"
           << "  \"prime\": 31,\n  \"primitive_roots\": " << root_count
           << ",\n  \"shifts_per_root\": 30,\n  \"distinct_w1_bases\": " << bases.size()
           << ",\n  \"cases_per_base\": 492032,\n  \"checked_cases\": " << checked
           << ",\n  \"witness_count\": " << witness_count
           << ",\n  \"one_collision_parameter_cases\": " << one_collision_cases
           << ",\n  \"repair_witness_count\": " << repair_witness_count
           << ",\n  \"status\": \"" << ((witness_count || repair_witness_count) ? "witness_found" : "exhausted_in_domain")
           << "\",\n  \"elapsed_seconds\": " << seconds << ",\n  \"first_witness\": ";
    if (witness_count) {
        write_permutation(output, first_witness);
        output << ",\n  \"first_witness_parameters\": {\"base_index\": " << first_base
               << ", \"columns_1_based\": [" << first_columns[0] + 1 << ',' << first_columns[1] + 1
               << "], \"rows_1_based\": [" << first_rows[0] + 1 << ',' << first_rows[1] + 1
               << "], \"matching\": " << first_matching << "},\n";
    } else {
        output << "null,\n";
    }
    output << "  \"first_repair_witness\": ";
    if (repair_witness_count) {
        write_permutation(output, first_repair_witness);
        output << ",\n  \"first_repair_swap_columns_1_based\": ["
               << first_repair_swap[0] + 1 << ',' << first_repair_swap[1] + 1 << "]\n";
    } else {
        output << "null\n";
    }
    output << "}\n";
    std::cerr << "completed in " << seconds << " seconds\n";
}
