#!/usr/bin/env python3
"""Boundary-sum/subset-sum pruning experiments for Costas prefix search.

This is intentionally independent of the earlier Hall-SDR experiment.  It uses
the telescoping sum of an entire difference-triangle row and an exact subset-sum
relaxation of the still-unrealized differences.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import time
from dataclasses import asdict, dataclass
from functools import lru_cache

from independent_verifier import verify_permutation as verify_independent
from reference_verifier import verify_permutation as verify_reference


@dataclass
class Metrics:
    order: int
    use_boundary_sum: bool
    nodes: int
    locally_consistent_children: int
    boundary_checks: int
    boundary_prunes: int
    solutions: int
    solution_sha256: str
    elapsed_seconds: float


def extend_used(
    prefix: list[int], used: list[set[int]], value: int
) -> list[tuple[int, int]] | None:
    new_index = len(prefix)
    inserted: list[tuple[int, int]] = []
    for old_index, old_value in enumerate(prefix):
        distance = new_index - old_index
        difference = value - old_value
        if difference in used[distance]:
            return None
        inserted.append((distance, difference))
    return inserted


@lru_cache(maxsize=None)
def _choose_distinct_sums(pool: tuple[int, ...], choose: int) -> frozenset[int]:
    """All sums of exactly `choose` distinct members of `pool`."""
    if choose < 0 or choose > len(pool):
        return frozenset()
    reachable: list[set[int]] = [set() for _ in range(choose + 1)]
    reachable[0].add(0)
    seen = 0
    for value in pool:
        seen += 1
        for count in range(min(choose, seen), 0, -1):
            reachable[count].update(total + value for total in reachable[count - 1])
    return frozenset(reachable[choose])


@lru_cache(maxsize=None)
def _signed_boundary_sums(
    remaining: tuple[int, ...], plus_count: int, minus_count: int
) -> frozenset[int]:
    """All sum(P)-sum(M) for disjoint subsets of the requested sizes."""
    states: dict[tuple[int, int], set[int]] = {(0, 0): {0}}
    for value in remaining:
        next_states = {key: set(sums) for key, sums in states.items()}
        for (plus_used, minus_used), sums in states.items():
            if plus_used < plus_count:
                target = (plus_used + 1, minus_used)
                next_states.setdefault(target, set()).update(total + value for total in sums)
            if minus_used < minus_count:
                target = (plus_used, minus_used + 1)
                next_states.setdefault(target, set()).update(total - value for total in sums)
        states = next_states
    return frozenset(states.get((plus_count, minus_count), set()))


def boundary_sum_feasible(prefix: list[int], order: int) -> tuple[bool, dict | None]:
    """Apply the exact boundary target vs. relaxed distinct-difference sum test."""
    length = len(prefix)
    assigned = set(prefix)
    remaining = tuple(value for value in range(1, order + 1) if value not in assigned)

    for distance in range(1, order):
        realized_count = max(0, length - distance)
        used: set[int] = set()
        for start in range(realized_count):
            difference = prefix[start + distance] - prefix[start]
            if difference in used:
                return False, {
                    "kind": "already_realized_collision",
                    "distance": distance,
                    "difference": difference,
                }
            used.add(difference)

        open_count = order - distance - realized_count
        difference_pool = tuple(
            value
            for value in range(-(order - 1), order)
            if value != 0 and value not in used
        )
        open_difference_sums = _choose_distinct_sums(difference_pool, open_count)

        fixed_boundary = 0
        unassigned_plus = 0
        unassigned_minus = 0
        coefficients: list[int] = []
        for position in range(order):
            coefficient = 0
            if position < distance:
                coefficient -= 1
            if position >= order - distance:
                coefficient += 1
            coefficients.append(coefficient)
            if position < length:
                fixed_boundary += coefficient * prefix[position]
            elif coefficient == 1:
                unassigned_plus += 1
            elif coefficient == -1:
                unassigned_minus += 1

        boundary_offsets = _signed_boundary_sums(
            remaining, unassigned_plus, unassigned_minus
        )
        realized_sum = sum(used)
        possible_required_open_sums = {
            fixed_boundary + offset - realized_sum for offset in boundary_offsets
        }
        if open_difference_sums.isdisjoint(possible_required_open_sums):
            return False, {
                "kind": "boundary_sum_disjoint",
                "distance": distance,
                "used_differences": sorted(used),
                "realized_difference_sum": realized_sum,
                "open_slot_count": open_count,
                "difference_pool": list(difference_pool),
                "open_difference_sums": sorted(open_difference_sums),
                "boundary_coefficients": coefficients,
                "fixed_boundary_contribution": fixed_boundary,
                "unassigned_plus_positions": unassigned_plus,
                "unassigned_minus_positions": unassigned_minus,
                "boundary_offsets": sorted(boundary_offsets),
                "required_open_difference_sums": sorted(possible_required_open_sums),
            }
    return True, None


def enumerate_costas(order: int, use_boundary_sum: bool) -> tuple[Metrics, list[tuple[int, ...]]]:
    prefix: list[int] = []
    available = [True] * (order + 1)
    used = [set() for _ in range(order)]
    solutions: list[tuple[int, ...]] = []
    nodes = 0
    locally_consistent_children = 0
    boundary_checks = 0
    boundary_prunes = 0
    started = time.perf_counter()

    def visit() -> None:
        nonlocal nodes, locally_consistent_children, boundary_checks, boundary_prunes
        nodes += 1
        if use_boundary_sum:
            boundary_checks += 1
            feasible, _ = boundary_sum_feasible(prefix, order)
            if not feasible:
                boundary_prunes += 1
                return
        if len(prefix) == order:
            solutions.append(tuple(prefix))
            return
        for value in range(1, order + 1):
            if not available[value]:
                continue
            inserted = extend_used(prefix, used, value)
            if inserted is None:
                continue
            locally_consistent_children += 1
            prefix.append(value)
            available[value] = False
            for distance, difference in inserted:
                used[distance].add(difference)
            visit()
            for distance, difference in inserted:
                used[distance].remove(difference)
            available[value] = True
            prefix.pop()

    visit()
    encoded = json.dumps(sorted(solutions), separators=(",", ":")).encode("utf-8")
    return (
        Metrics(
            order=order,
            use_boundary_sum=use_boundary_sum,
            nodes=nodes,
            locally_consistent_children=locally_consistent_children,
            boundary_checks=boundary_checks,
            boundary_prunes=boundary_prunes,
            solutions=len(solutions),
            solution_sha256=hashlib.sha256(encoded).hexdigest(),
            elapsed_seconds=time.perf_counter() - started,
        ),
        solutions,
    )


def locally_costas(prefix: tuple[int, ...]) -> bool:
    for distance in range(1, len(prefix)):
        row = [
            prefix[start + distance] - prefix[start]
            for start in range(len(prefix) - distance)
        ]
        if len(row) != len(set(row)):
            return False
    return True


def find_strict_prune_witness(max_order: int) -> dict | None:
    """First pruned prefix that still has a baseline-consistent child."""
    for order in range(1, max_order + 1):
        for length in range(order):
            for prefix in itertools.permutations(range(1, order + 1), length):
                if not locally_costas(prefix):
                    continue
                feasible, certificate = boundary_sum_feasible(list(prefix), order)
                if feasible:
                    continue
                children = [
                    value
                    for value in range(1, order + 1)
                    if value not in prefix and locally_costas(prefix + (value,))
                ]
                if children:
                    return {
                        "order": order,
                        "prefix": list(prefix),
                        "locally_consistent_child_values": children,
                        "certificate": certificate,
                    }
    return None


def find_minimal_sufficiency_failure(max_order: int) -> dict | None:
    for order in range(1, max_order + 1):
        _, solutions = enumerate_costas(order, use_boundary_sum=False)
        live = {
            solution[:length]
            for solution in solutions
            for length in range(order + 1)
        }
        for length in range(order):
            for prefix in itertools.permutations(range(1, order + 1), length):
                if not locally_costas(prefix):
                    continue
                feasible, _ = boundary_sum_feasible(list(prefix), order)
                if feasible and prefix not in live:
                    return {
                        "order": order,
                        "prefix": list(prefix),
                        "locally_costas": True,
                        "boundary_sum_feasible_at_every_distance": True,
                        "has_costas_completion": False,
                    }
    return None


def direct_bruteforce_counts(max_order: int) -> dict[str, int]:
    counts: dict[str, int] = {}
    for order in range(1, max_order + 1):
        count = 0
        for permutation in itertools.permutations(range(1, order + 1)):
            if verify_independent(list(permutation))["is_costas"]:
                count += 1
        counts[str(order)] = count
    return counts


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-order", type=int, default=9)
    parser.add_argument("--bruteforce-max-order", type=int, default=8)
    parser.add_argument("--witness-max-order", type=int, default=8)
    args = parser.parse_args()

    metrics: list[dict] = []
    solution_sets_equal = True
    verifier_disagreements: list[dict] = []
    for order in range(1, args.max_order + 1):
        baseline, baseline_solutions = enumerate_costas(order, False)
        boundary, boundary_solutions = enumerate_costas(order, True)
        solution_sets_equal &= set(baseline_solutions) == set(boundary_solutions)
        for solution in boundary_solutions:
            reference = verify_reference(list(solution))
            independent = verify_independent(list(solution))
            if (
                not reference["is_costas"]
                or not independent["is_costas"]
                or reference["permutation_sha256"]
                != independent["permutation_sha256"]
            ):
                verifier_disagreements.append(
                    {"order": order, "permutation": list(solution)}
                )
        metrics.extend((asdict(baseline), asdict(boundary)))

    report = {
        "marker": "COSTAS_ROLE5_WAVE2_BOUNDARY_SUM_V1",
        "indexing": "1-based",
        "metrics": metrics,
        "paired_solution_sets_equal": solution_sets_equal,
        "direct_bruteforce_counts": direct_bruteforce_counts(
            args.bruteforce_max_order
        ),
        "verifier_disagreements": verifier_disagreements,
        "strict_prune_witness": find_strict_prune_witness(args.witness_max_order),
        "minimal_sufficiency_failure": find_minimal_sufficiency_failure(
            args.witness_max_order
        ),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
