#!/usr/bin/env python3
"""Role-2 structural analysis of the curated Costas seed data.

The script deliberately distinguishes:

* the 15-record, incomplete, family-biased curated seed set;
* newly generated complete Costas sets for explicitly bounded small orders; and
* the finite one-point insertion domain around the single curated order-31 seed.

All externally reported permutations and coordinates are 1-based.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import platform
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any, Callable, Iterator


ROOT = Path(__file__).resolve().parents[2]
UPLOAD = ROOT / "upload"
KNOWN = UPLOAD / "known_arrays(1).json"
REFERENCE = UPLOAD / "reference_verifier(1).py"
INDEPENDENT = UPLOAD / "independent_verifier(1).py"


def load_verifier(path: Path, module_name: str) -> Callable[[Any], dict[str, Any]]:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify_permutation


verify_reference = load_verifier(REFERENCE, "role2_reference_verifier")
verify_independent = load_verifier(INDEPENDENT, "role2_independent_verifier")


def compact_hash(permutation: list[int]) -> str:
    encoded = json.dumps(permutation, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def inverse(p: tuple[int, ...]) -> tuple[int, ...]:
    q = [0] * len(p)
    for i, value in enumerate(p, start=1):
        q[value - 1] = i
    return tuple(q)


def d4_orbit(p: tuple[int, ...]) -> tuple[tuple[int, ...], ...]:
    """Return the distinct D4 images of a permutation."""
    n = len(p)
    base = (
        p,
        tuple(n + 1 - value for value in p),
        tuple(reversed(p)),
        tuple(n + 1 - value for value in reversed(p)),
    )
    return tuple(sorted(set(base + tuple(inverse(q) for q in base))))


def canonical(p: tuple[int, ...]) -> tuple[int, ...]:
    return min(d4_orbit(p))


def is_costas_triangle(p: tuple[int, ...] | list[int]) -> bool:
    """A third, compact difference-triangle predicate for internal checks."""
    n = len(p)
    for distance in range(1, n):
        row = [p[i + distance] - p[i] for i in range(n - distance)]
        if len(row) != len(set(row)):
            return False
    return True


def enumerate_costas(n: int) -> Iterator[tuple[int, ...]]:
    """Enumerate every order-n Costas permutation by prefix backtracking."""
    prefix: list[int] = []
    used_values = [False] * (n + 1)
    used_differences = [set() for _ in range(n)]

    def visit() -> Iterator[tuple[int, ...]]:
        column = len(prefix)
        if column == n:
            yield tuple(prefix)
            return

        for value in range(1, n + 1):
            if used_values[value]:
                continue
            additions: list[tuple[int, int]] = []
            allowed = True
            for old_column, old_value in enumerate(prefix):
                distance = column - old_column
                difference = value - old_value
                if difference in used_differences[distance]:
                    allowed = False
                    break
                additions.append((distance, difference))
            if not allowed:
                continue

            prefix.append(value)
            used_values[value] = True
            for distance, difference in additions:
                used_differences[distance].add(difference)
            yield from visit()
            for distance, difference in additions:
                used_differences[distance].remove(difference)
            used_values[value] = False
            prefix.pop()

    yield from visit()


def delete_point(p: tuple[int, ...], column: int) -> tuple[int, ...]:
    """Delete a point and compress its row and column; column is 0-based internally."""
    removed_value = p[column]
    return tuple(
        value - (value > removed_value)
        for i, value in enumerate(p)
        if i != column
    )


def deletion_profile(p: tuple[int, ...]) -> dict[str, Any]:
    n = len(p)
    deletable = [
        column + 1
        for column in range(n)
        if is_costas_triangle(delete_point(p, column))
    ]
    boundary = [
        column
        for column in deletable
        if column in (1, n) or p[column - 1] in (1, n)
    ]
    corners = [
        column
        for column in deletable
        if column in (1, n) and p[column - 1] in (1, n)
    ]
    return {
        "deletable_columns_1_based": deletable,
        "deletable_count": len(deletable),
        "boundary_deletable_columns_1_based": boundary,
        "boundary_deletable_count": len(boundary),
        "corner_deletable_columns_1_based": corners,
        "corner_deletable_count": len(corners),
    }


def insert_point(p: tuple[int, ...], column: int, row: int) -> tuple[int, ...]:
    """Insert one row, one column, and their intersection point.

    column and row use 1-based coordinates in the enlarged (n+1)-square.
    """
    n = len(p)
    if not (1 <= column <= n + 1 and 1 <= row <= n + 1):
        raise ValueError("insertion coordinate out of range")
    result: list[int] = []
    old_column = 0
    for new_column in range(1, n + 2):
        if new_column == column:
            result.append(row)
        else:
            value = p[old_column]
            result.append(value + (value >= row))
            old_column += 1
    return tuple(result)


def collision_signature(report: dict[str, Any]) -> list[dict[str, Any]]:
    """Compact but exact collision information."""
    return [
        {
            "vector": item["vector"],
            "multiplicity": item["multiplicity"],
            "point_pairs": item["point_pairs"],
        }
        for item in report["duplicate_vectors"]
    ]


def exhaustive_small_orders(max_order: int) -> dict[str, Any]:
    by_order: dict[str, Any] = {}
    first_no_deletion: dict[str, Any] | None = None
    total_arrays = 0

    for n in range(1, max_order + 1):
        start = time.perf_counter()
        arrays = list(enumerate_costas(n))
        elapsed = time.perf_counter() - start

        # Cross-check every generated result through three logically distinct views.
        cross_failures = []
        deletion_histogram: Counter[int] = Counter()
        boundary_deletion_histogram: Counter[int] = Counter()
        orbit_representatives: set[tuple[int, ...]] = set()
        no_deletion: list[tuple[int, ...]] = []
        no_boundary_deletion: list[tuple[int, ...]] = []

        for p in arrays:
            ref = verify_reference(list(p))
            ind = verify_independent(list(p))
            tri = is_costas_triangle(p)
            if not (ref["is_costas"] and ind["is_costas"] and tri):
                cross_failures.append(list(p))
            profile = deletion_profile(p)
            deletion_histogram[profile["deletable_count"]] += 1
            boundary_deletion_histogram[profile["boundary_deletable_count"]] += 1
            if profile["deletable_count"] == 0:
                no_deletion.append(p)
            if profile["boundary_deletable_count"] == 0:
                no_boundary_deletion.append(p)
            orbit_representatives.add(canonical(p))

        total_arrays += len(arrays)
        record = {
            "order": n,
            "costas_count": len(arrays),
            "d4_class_count": len(orbit_representatives),
            "deletable_count_histogram": dict(sorted(deletion_histogram.items())),
            "boundary_deletable_count_histogram": dict(
                sorted(boundary_deletion_histogram.items())
            ),
            "arrays_with_no_deletable_point": len(no_deletion),
            "d4_classes_with_no_deletable_point": len(
                {canonical(p) for p in no_deletion}
            ),
            "arrays_with_no_boundary_deletable_point": len(no_boundary_deletion),
            "d4_classes_with_no_boundary_deletable_point": len(
                {canonical(p) for p in no_boundary_deletion}
            ),
            "canonical_no_deletion_examples": [
                list(p) for p in sorted({canonical(p) for p in no_deletion})[:10]
            ],
            "canonical_no_boundary_deletion_examples": [
                list(p)
                for p in sorted({canonical(p) for p in no_boundary_deletion})[:10]
            ],
            "cross_check_failures": cross_failures,
            "elapsed_seconds": elapsed,
        }
        by_order[str(n)] = record

        if first_no_deletion is None and no_deletion:
            witness = min(canonical(p) for p in no_deletion)
            first_no_deletion = {
                "order": n,
                "canonical_permutation": list(witness),
                "orbit_size": len(d4_orbit(witness)),
                "deletion_attempts": [
                    {
                        "deleted_point": [column + 1, witness[column]],
                        "compressed_permutation": list(delete_point(witness, column)),
                        "reference_report": collision_signature(
                            verify_reference(list(delete_point(witness, column)))
                        ),
                        "independent_report": collision_signature(
                            verify_independent(list(delete_point(witness, column)))
                        ),
                    }
                    for column in range(n)
                ],
            }

    return {
        "domain": f"all permutations of each order 1..{max_order}, pruned only after an already-forced Costas collision",
        "total_costas_arrays": total_arrays,
        "orders": by_order,
        "first_array_with_no_deletable_point": first_no_deletion,
    }


def curated_seed_analysis(document: dict[str, Any]) -> dict[str, Any]:
    records = document["records"]
    canonical_records = []
    classes = set()
    family_counter: Counter[str] = Counter()

    for record in records:
        p = tuple(record["permutation"])
        canon = canonical(p)
        classes.add((len(p), canon))
        family = record["construction"]["family"]
        family_counter[family] += 1
        profile = deletion_profile(p)

        insertion_hits = []
        corner_attempts = []
        n = len(p)
        corners = ((1, 1), (1, n + 1), (n + 1, 1), (n + 1, n + 1))
        for column, row in corners:
            candidate = list(insert_point(p, column, row))
            ref = verify_reference(candidate)
            ind = verify_independent(candidate)
            if ref["is_costas"] != ind["is_costas"]:
                raise RuntimeError("verifier disagreement on corner insertion")
            if ref["is_costas"]:
                insertion_hits.append({"column": column, "row": row})
            corner_attempts.append(
                {
                    "column": column,
                    "row": row,
                    "is_costas": ref["is_costas"],
                    "duplicate_vector_count": ref["duplicate_vector_count"],
                    "duplicate_pair_occurrence_excess": ref[
                        "duplicate_pair_occurrence_excess"
                    ],
                    "first_collision": (
                        ref["duplicate_vectors"][0] if ref["duplicate_vectors"] else None
                    ),
                }
            )

        canonical_records.append(
            {
                "id": record["id"],
                "order": len(p),
                "family": family,
                "canonical_permutation": list(canon),
                "d4_orbit_size": len(d4_orbit(p)),
                "deletion_profile": profile,
                "corner_insertion_successes": insertion_hits,
                "corner_attempts": corner_attempts,
            }
        )

    return {
        "scope_warning": document["dataset_scope"]["warning"],
        "record_count": len(records),
        "unique_order_and_d4_class_count": len(classes),
        "family_counts": dict(sorted(family_counter.items())),
        "records": canonical_records,
    }


def all_insertions_from_order31(document: dict[str, Any]) -> dict[str, Any]:
    records = [record for record in document["records"] if record["order"] == 31]
    if len(records) != 1:
        raise RuntimeError(f"expected one curated order-31 record, got {len(records)}")

    record = records[0]
    p = tuple(record["permutation"])
    attempts = 0
    verifier_disagreements = []
    valid_candidates = []
    best_excess: int | None = None
    best_vector_count: int | None = None
    best_attempts: list[dict[str, Any]] = []
    excess_histogram: Counter[int] = Counter()
    vector_count_histogram: Counter[int] = Counter()
    unique_candidates: set[tuple[int, ...]] = set()
    canonical_candidates: set[tuple[int, ...]] = set()

    for column in range(1, 33):
        for row in range(1, 33):
            attempts += 1
            candidate = list(insert_point(p, column, row))
            unique_candidates.add(tuple(candidate))
            canonical_candidates.add(canonical(tuple(candidate)))
            ref = verify_reference(candidate)
            ind = verify_independent(candidate)
            comparable = (
                ref["valid_input"] == ind["valid_input"]
                and ref["is_permutation"] == ind["is_permutation"]
                and ref["is_costas"] == ind["is_costas"]
                and ref["duplicate_vector_count"]
                == ind["duplicate_vector_count"]
                and ref["duplicate_pair_occurrence_excess"]
                == ind["duplicate_pair_occurrence_excess"]
                and ref["duplicate_vectors"] == ind["duplicate_vectors"]
                and ref["permutation_sha256"] == ind["permutation_sha256"]
            )
            if not comparable:
                verifier_disagreements.append({"column": column, "row": row})

            if ref["is_costas"]:
                valid_candidates.append(
                    {
                        "column": column,
                        "row": row,
                        "permutation": candidate,
                        "sha256": ref["permutation_sha256"],
                    }
                )

            excess = ref["duplicate_pair_occurrence_excess"]
            vector_count = ref["duplicate_vector_count"]
            excess_histogram[excess] += 1
            vector_count_histogram[vector_count] += 1
            if best_excess is None or (excess, vector_count) < (
                best_excess,
                best_vector_count,
            ):
                best_excess = excess
                best_vector_count = vector_count
                best_attempts = []
            if (excess, vector_count) == (best_excess, best_vector_count):
                best_attempts.append(
                    {
                        "column": column,
                        "row": row,
                        "candidate": candidate,
                        "permutation_sha256": ref["permutation_sha256"],
                        "collisions": collision_signature(ref),
                    }
                )

    return {
        "source_record": record["id"],
        "source_permutation": list(p),
        "domain": "all 32 choices of inserted column times all 32 choices of inserted row",
        "attempt_count": attempts,
        "unique_candidate_count": len(unique_candidates),
        "unique_d4_class_count": len(canonical_candidates),
        "valid_order32_candidates": valid_candidates,
        "verifier_disagreements": verifier_disagreements,
        "minimum_duplicate_pair_occurrence_excess": best_excess,
        "minimum_duplicate_vector_count_at_that_excess": best_vector_count,
        "best_attempts": best_attempts,
        "duplicate_pair_occurrence_excess_histogram": dict(
            sorted(excess_histogram.items())
        ),
        "duplicate_vector_count_histogram": dict(sorted(vector_count_histogram.items())),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--small-max-order", type=int, default=10)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    started = time.time()
    with KNOWN.open("r", encoding="utf-8") as stream:
        document = json.load(stream)

    report = {
        "marker": "COSTAS_ROLE2_STRUCTURE_ANALYSIS_V1",
        "timestamp_unix": started,
        "environment": {
            "python": sys.version,
            "platform": platform.platform(),
        },
        "input_files": {
            "known_arrays": str(KNOWN),
            "known_arrays_sha256": hashlib.sha256(KNOWN.read_bytes()).hexdigest(),
            "reference_verifier": str(REFERENCE),
            "reference_verifier_sha256": hashlib.sha256(REFERENCE.read_bytes()).hexdigest(),
            "independent_verifier": str(INDEPENDENT),
            "independent_verifier_sha256": hashlib.sha256(
                INDEPENDENT.read_bytes()
            ).hexdigest(),
        },
        "normalization": {
            "group": "D4 square symmetries",
            "representative": "lexicographically least of the distinct eight-or-fewer D4 images",
            "evidence_unit": "(order, D4 canonical representative)",
        },
        "curated_seed_analysis": curated_seed_analysis(document),
        "small_order_complete_enumeration": exhaustive_small_orders(
            args.small_max_order
        ),
        "order31_one_point_insertion_exhaustion": all_insertions_from_order31(
            document
        ),
    }
    report["elapsed_seconds"] = time.time() - started

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "status": "PASS",
                "output": str(args.output),
                "elapsed_seconds": report["elapsed_seconds"],
                "small_total": report["small_order_complete_enumeration"][
                    "total_costas_arrays"
                ],
                "first_no_deletion": report["small_order_complete_enumeration"][
                    "first_array_with_no_deletable_point"
                ]["order"],
                "order32_candidates": len(
                    report["order31_one_point_insertion_exhaustion"][
                        "valid_order32_candidates"
                    ]
                ),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
