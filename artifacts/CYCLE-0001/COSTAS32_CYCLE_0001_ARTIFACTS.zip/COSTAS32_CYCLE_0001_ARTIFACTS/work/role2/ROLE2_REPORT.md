# 역할 2 — 알려진 배열 데이터의 구조 발굴: 첫 파동 보고

## 판정 주의

이 보고서의 두 산출물은 역할 2의 독립 계산 결과다. 역할 7의 독립 정확 탐색과 역할 8의 적대적 심사를 아직 거치지 않았으므로, 여기서는 어느 주장도 `proved` 또는 `verified`로 판정하지 않는다.

## 데이터 범위와 편향

* `known_arrays(1).json`: 15개 레코드, 각 레코드는 `(order, D4 canonical representative)` 기준으로 서로 다르다.
* 구성 계열: `W1` 10개, `W2` 3개, `W0` 1개, `trivial` 1개.
* 차수 27, 28, 29, 30, 31에는 각각 대표 하나뿐이다.
* 모두 대수적 또는 파생 계열이며 sporadic/비정형 표본은 없다. 따라서 공식 구성과 비정형 구성의 통계적 차이는 이 파일로 평가할 수 없다.
* 이 자료는 불완전한 대표 시드이며, 특히 30차와 31차의 전체 배열 집합이 아니다.
* 별도 생성한 작은 차수 자료: 차수 1~12의 Costas 배열 15,959개. 접두 백트래킹은 이미 생긴 동일 수평거리 차분 충돌만 가지치기했다. 각 산출 배열을 제공된 두 검증기와 별도의 차분삼각형 조건으로 교차검사했으며 불일치는 없었다. 차수별 개수는 프로젝트의 완전 열거값과 모두 일치했다. 이 완전성 주장은 역할 7 감사 전에는 `awaiting_exact_check`다.

## 대칭 정규화

순열의 수평 반사, 수직 반사, 180도 회전 및 이 네 순열의 역순열로 이루어진 서로 다른 최대 8개 `D4` 상을 만들고, 사전식 최소 순열을 정규 대표로 삼았다. 통계적 증거 단위는 배열 복제본이 아니라 `(order, canonical representative)`다.

---

## 산출물 R2-C1 — 1점 삭제 유전성 가설의 최소 반례 후보

### 특징 정의

차수 `n` 순열 `p`와 열 `k`에 대해 점 `(k,p[k])`, 그 행, 그 열을 삭제하고 좌표를 압축한 차수 `n-1` 순열을 `D_k(p)`라 한다. `D_k(p)`가 Costas이면 그 점을 **삭제 가능**하다고 한다.

1-based로 정확히 쓰면

\[
D_k(p)_i=
\begin{cases}
p_i-\mathbf 1[p_i>p_k],&i<k,\\
p_{i+1}-\mathbf 1[p_{i+1}>p_k],&i\ge k.
\end{cases}
\]

### 기각할 정확한 명제

> 모든 `n>=2` Costas 순열 `p`에는 `D_k(p)`가 Costas인 `k`가 적어도 하나 존재한다.

이 명제가 참이면 모든 고차 배열을 바로 아래 차수 배열의 1점 삽입으로 얻을 수 있어 차수 32 탐색을 31차 배열의 삽입으로 환원할 수 있다.

### 최소 반례 후보

차수 7의 D4 정규형

```text
[2,1,5,7,3,6,4]
```

은 Costas이지만 일곱 점 중 어느 점도 삭제 가능하지 않았다. 각 삭제 결과와 중복 변위는 다음과 같다. 두 제공 검증기가 모두 같은 충돌 전체를 보고했다.

| 삭제 점 | 압축 순열 | 중복 벡터 |
|---|---|---|
| `(1,2)` | `[1,4,6,2,5,3]` | `(1,3)`, `(3,1)` |
| `(2,1)` | `[1,4,6,2,5,3]` | `(1,3)`, `(3,1)` |
| `(3,5)` | `[2,1,6,3,5,4]` | `(1,-1)`, `(4,3)` |
| `(4,7)` | `[2,1,5,3,6,4]` | `(1,-2)`, `(2,1)` |
| `(5,3)` | `[2,1,4,6,5,3]` | `(1,-1)`, `(3,4)` |
| `(6,6)` | `[2,1,5,6,3,4]` | `(1,1)`, `(2,-2)` |
| `(7,4)` | `[2,1,4,6,3,5]` | `(1,2)`, `(2,-1)` |

### 최소성 및 지지/위반 수

* 차수 2~6의 전체 Costas 배열 174개에는 모두 삭제 가능한 점이 있었다.
* 차수 7의 200개 중 8개, D4 정규화 후 30개 류 중 2개 류가 삭제 불가능했다.
* 따라서 위 명제의 최소 반례 차수는 이 계산 범위 안에서 7이다.

### 학습/검증 분리

* 동기/학습 범위: 구성 계열 편향이 강한 15개 시드와 차수 2~6 전체 자료. 차수 2~6의 174개는 명제를 지지했다.
* 첫 반례/최소성 범위: 차수 7 전체 자료.
* 후속 검증 범위: 차수 8~12는 최소 반례 탐색과 분리하여 장애의 재현성을 보았다.

| 차수 | 전체 D4류 | 삭제불가 D4류 |
|---:|---:|---:|
| 8 | 60 | 16 |
| 9 | 100 | 46 |
| 10 | 277 | 177 |
| 11 | 555 | 378 |
| 12 | 990 | 749 |

따라서 삭제 불가능성은 최소 반례 하나의 우연한 특징이 아니라, 이 완전 소차수 자료에서 빠르게 흔해지는 구조다. 이 빈도는 일반 정리가 아니라 명시된 범위의 계산 관찰이다.

### 차수 32 연결

차수 32 배열이 존재하더라도 한 점을 삭제해 차수 31 Costas 배열을 얻는다는 보장은 없다. 그러므로 모든 알려진 31차 배열의 모든 1점 삽입을 소진해도 차수 32 전체 비존재를 결론낼 수 없다. 반대로 31차 확장 검색은 존재 증인을 찾는 제한된 구성 경로로는 여전히 유효하다.

### 역할 7 요청 `R2-REQ-001`

```json
{
  "request_id": "R2-REQ-001",
  "claim_id": "R2-C1",
  "task": "independently find the minimum-order Costas permutation with no deletable point",
  "orders": [2,3,4,5,6,7],
  "definition": "delete point (k,p_k), delete its row and column, compress both coordinates, and test the resulting permutation",
  "symmetry": "no symmetry pruning is required; use D4 only to canonicalize reported witnesses",
  "wanted": "counterexample plus complete exhaustion of all lower orders",
  "success": "orders 2..6 exhausted with no counterexample and an order-7 counterexample independently verified",
  "candidate": [2,1,5,7,3,6,4],
  "expected_status": "counterexample_found together with exhausted_in_domain for orders 2..6"
}
```

---

## 산출물 R2-C2 — 고정된 31차 시드의 모든 1점 삽입 소진 후보

### 특징 정의

차수 `n` 순열 `p`, 새 열 `c in [n+1]`, 새 행 `r in [n+1]`에 대해 `I_{c,r}(p)`는 열 `c`와 행 `r`을 삽입하고 교점 `(c,r)`에 새 점을 둔 순열이다. 기존 점 `(i,p_i)`는

\[
(i+\mathbf 1[i\ge c],\ p_i+\mathbf 1[p_i\ge r])
\]

로 이동한다.

### 정확한 제한 영역 명제

고정된 시드

```text
KA-015-N31-W0-P31-G3-C3-LOWERLEFT
[1,28,20,27,17,18,21,30,26,14,9,25,11,31,29,23,5,13,6,16,15,12,3,7,19,24,8,22,2,4,10]
```

에 대해 모든 `(c,r) in [32] x [32]`의 `I_{c,r}(p)`를 검사했다.

### 계산 결과

* 삽입 연산: 1,024개 전부 처리.
* 서로 다른 결과 순열: 962개.
* 이 결과 집합 안의 서로 다른 D4 정규형: 962개.
* Costas 후보: 0개.
* 두 제공 검증기의 결과/충돌 보고 불일치: 0개.
* 최소 `duplicate_pair_occurrence_excess`: 2.
* 그때 최소 `duplicate_vector_count`: 2.

최소 충돌 후보는 `(c,r)=(1,1)`과 `(2,2)`가 동일하게 만드는 다음 순열이다.

```text
[1,2,29,21,28,18,19,22,31,27,15,10,26,12,32,30,24,6,14,7,17,16,13,4,8,20,25,9,23,3,5,11]
```

중복은 정확히 다음 두 벡터에서 검출되었다.

* `(1,1)`: 점쌍 `((1,1),(2,2))`, `((6,18),(7,19))`
* `(5,17)`: 점쌍 `((1,1),(6,18))`, `((2,2),(7,19))`

### 학습/검증 분리

이 산출물은 학습된 규칙이 아니라 하나의 명시적 유한 영역 소진이다. 시드 선택은 `known_arrays`에 저장된 유일한 31차 레코드라는 이유로 고정했으며, 1,024개 삽입 위치를 후보 선택이나 조기 중단 없이 모두 검사했다.

### 차수 32 연결과 한계

이 계산은 **이 한 시드에서 한 점을 삽입하는 경로**로는 차수 32를 얻지 못한다는 것만 말한다. 31차 알려진 집합은 불완전하고, R2-C1 때문에 임의의 32차 배열이 어떤 31차 배열의 1점 삽입이어야 할 이유도 없다. 따라서 차수 32 비존재의 근거가 아니다.

### 역할 7 요청 `R2-REQ-002`

```json
{
  "request_id": "R2-REQ-002",
  "claim_id": "R2-C2",
  "source_id": "KA-015-N31-W0-P31-G3-C3-LOWERLEFT",
  "source_sha256": "074c392ed4aa4228a073ea576bd4d2980999ad6e696244838e633666250c351b",
  "source_permutation": [1,28,20,27,17,18,21,30,26,14,9,25,11,31,29,23,5,13,6,16,15,12,3,7,19,24,8,22,2,4,10],
  "domain": {"inserted_column": [1,32], "inserted_row": [1,32]},
  "symmetry": "none used to omit cases; enumerate all 1024 coordinate pairs",
  "wanted": "a valid order-32 witness or independent confirmation that the entire fixed-source domain contains none",
  "success": "all 1024 operations processed, no verifier disagreement, zero valid candidates",
  "expected_unique_permutations": 962,
  "expected_status": "exhausted_in_domain"
}
```

## Blocker

`known_arrays`에는 고차 비정형 배열과 30·31차의 완전 데이터가 없으므로 계열 불변 특징과 전체 Costas 필요조건을 구별할 수 없다. 다음 파동에서 이 경로를 넓히려면 독립 출처의 대칭류별 29차 완전 자료 또는 더 많은 독립 31차 대표가 필요하다. 그 전에는 본 결과를 전체 고차 배열로 일반화하지 않아야 한다.

## 재현 자료

* `work/role2/analyze_structures.py` — SHA-256 `00a8032cd32a889074a208f66cd2d10d3d82722beef7b1a942f338da43e716da`
* `work/role2/analysis_n12.json` — SHA-256 `73afd274451c5574f138d39bcd520ddc3761907c216eabfdb39de54b4995c77f`
* 실행: `python work/role2/analyze_structures.py --small-max-order 12 --output work/role2/analysis_n12.json`
* Python: 3.12.13
